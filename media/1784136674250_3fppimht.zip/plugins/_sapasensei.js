let handler = m => m

handler.before = async function (m) {

    if (m.chat.endsWith('broadcast')) return
    if (m.fromMe) return
    if (!m.isGroup) return
    
    if (m.isGroup) {
       if (m.sender === '6283854025278@s.whatsapp.net') {
       let user = global.db.data.users[m.sender]
       let username = this.getName(m.sender) 
       let _timie = (new Date - (user.pc * 1)) * 1
       if (_timie < 1000000) return
    
    let halo = `${pickRandom(['Alow sensei (๑˃ᴗ˂)ﻭ','Selamat datang kembali sensei (๑˃̵ᴗ˂̵)✨'])}`

    await m.reply(halo)
    user.pc = new Date * 1
        }
     }
  }

export default handler

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}