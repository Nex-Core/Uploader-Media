// Penyimpanan akun pengguna dalam global.db
// Inisialisasi objek untuk melacak pengguna yang sedang berinvestasi
let isInvesting = {}; 

let handler = async (m, { text, command, usedPrefix }) => {
    const userId = m.sender;
    const tag = '@' + m.sender.split`@`[0];

    // Ambil data pengguna dari global.db atau inisialisasi pengguna baru jika tidak ada
    let user = global.db.data.users[userId] || {
        eris: 0,
        cooldown: 0
    };

    // Cek apakah pengguna sedang berinvestasi
    if (isInvesting[userId]) {
        return m.reply(`🚫 ${tag}, Anda sedang berinvestasi. Selesaikan investasi saat ini sebelum memulai yang baru.`);
    }

    // Cek apakah pengguna sedang cooldown
    const cooldownTime = 20 * 60 * 1000;
    const timeLeft = cooldownTime - (Date.now() - user.cooldown);
    if (user.cooldown && timeLeft > 0) {
        const remainingMinutes = Math.ceil(timeLeft / 1000 / 60);
        return m.reply(`⏳ ${tag}, harap tunggu ${remainingMinutes} menit sebelum memulai investasi lagi.`);
    }

    // Validasi input: nominal atau 'all'
    if (!text || (isNaN(text) && text.toLowerCase() !== 'all')) {
        return m.reply(`⚠️ ${tag}, gunakan format ${usedPrefix}${command} <nominal> atau ${usedPrefix}${command} all.\n\nDisclaimer investasi ini menggunakan money kamu, jika kamu rugi money kamu akan hilang!`);
    }

    // Tentukan nominal investasi
    let nominal = text.toLowerCase() === 'all' ? user.eris : parseInt(text);
    if (nominal <= 0 || nominal > user.eris) {
        return m.reply(`❌ ${tag}, nominal tidak valid atau melebihi saldo Anda. Saldo Anda: ${user.eris.toLocaleString()}.`);
    }

    // Mulai investasi
    isInvesting[userId] = true;
    user.eris -= nominal;
    await global.db.write();

    m.reply(`💰 ${tag}, Anda telah menginvestasikan ${nominal.toLocaleString()}. Hasil akan tersedia dalam 20 menit.`);

    setTimeout(async () => {
        // Proses hasil investasi
        let changePercent = Math.random() < 0.39 ? -100 : Math.floor(Math.random() * 21 + 5);
        const profit = Math.floor(nominal * (changePercent / 100));
        const total = nominal + profit;

        if (changePercent > 0) {
            user.eris += total;
            m.reply(`📈 ${tag}, investasi Anda berhasil! Keuntungan: ${profit.toLocaleString()}. Total: ${total.toLocaleString()}.`);
        } else {
            m.reply(`📉 ${tag}, investasi Anda gagal dan seluruh uang hilang.`);
        }

        // Set cooldown, simpan data, dan izinkan investasi baru setelah cooldown
        user.cooldown = Date.now();
        isInvesting[userId] = false;
        await global.db.write();

        setTimeout(() => {
            m.reply(`✅ ${tag}, Anda dapat berinvestasi lagi. Gunakan ${usedPrefix}${command} <nominal> untuk memulai.`);
        }, cooldownTime);
    }, cooldownTime);
};

handler.help = ['investasi <nominal>'];
handler.tags = ['rpg'];
handler.command = /^investasi$/i;

export default handler;