const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = (await import('baileys')).default;

let handler = async (m, { conn }) => {
    let caption = `🌸 *ᴡᴇʟᴄᴏᴍᴇ ᴛᴏ ᴋᴇɴᴄᴀɴ ᴀɴɪᴍᴇ* 🌸\n\n` +
                  `💌 *ᴘɪʟɪʜ ᴋᴀʀᴀᴋᴛᴇʀ ʏᴀɴɢ ɪɴɢɪɴ ᴋᴀᴍᴜ ᴀᴊᴀᴋ ᴋᴇɴᴄᴀɴ.*\n💰 *ʙɪᴀʏᴀ ᴋᴇɴᴄᴀɴ: 1.000.000 ᴍᴏɴᴇʏ*\n` +
                  `❤️ *ᴘᴀꜱᴛɪᴋᴀɴ ꜱᴀʟᴅᴏ ᴋᴀᴍᴜ ᴄᴜᴋᴜᴘ!*`;

    let characters = [
        'Sakura', 'Asuna', 'Mikasa', 'Kagome', 'Saber', 'Rei', 'Rem', 'Mio',
        'Erza', 'Haruhi', 'Lucy', 'Nami', 'Hinata', 'Rias', 'Rukia', 'Inori',
        'Zero Two', 'Nanami', 'Nezuko', 'Holo', 'Radit', 'Naruto', 'Luffy',
        'Goku', 'Ichigo', 'Natsu', 'Kirito', 'Shinobu', 'Yuno', 'Kaneki',
        'Aqua', 'Chitoge', 'Megumin', 'Yukino', 'Emilia', 'Tohru', 'Albedo',
        'Shiro', 'Makoto', 'Kaguya', 'Mai', 'Senjougahara', 'Tsukasa',
        'Yuuki', 'Homura', 'Rin', 'Taiga', 'C.C.', 'Kurisu', 'Yukari'
    ];

    let sections = [{
        title: "💖 *ᴘɪʟɪʜ ᴋᴀʀᴀᴋᴛᴇʀ*",
        rows: characters.map(name => ({
            title: `✨ ${name}`,
            id: `.date ${name}`,
            description: "Ajak dia kencan sekarang!"
        }))
    }];

    let listMessage = { title: "🌟 ᴘɪʟɪʜ ᴋᴀʀᴀᴋᴛᴇʀ ᴋᴇɴᴄᴀɴ", sections };

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
                    footer: proto.Message.InteractiveMessage.Footer.create({ text: "💫 ɴɪꜱʜɪᴋɪɢɪ ᴄʜɪꜱᴀᴛᴏ || ᴀʀ ꜱᴇɴꜱᴇɪ" }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        title: "",
                        hasMediaAttachment: true,
                        ...(await prepareWAMessageMedia({ image: { url: "https://files.catbox.moe/77zmr2.jpg" } }, { upload: conn.waUploadToServer }))
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [{ name: "single_select", buttonParamsJson: JSON.stringify(listMessage) }]
                    })
                })
            }
        }
    }, {});

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
};

handler.help = ["kencan"];
handler.tags = ["rpg"];
handler.command = /^(kencan)$/i;

export default handler;