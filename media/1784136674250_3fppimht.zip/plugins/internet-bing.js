import axios from 'axios'
import cheerio from 'cheerio'
const { proto } = (await import('baileys')).default

const config = {
  author: 'Nishi chi',
}

async function BingImages(query) {
  const searchUrl = `https://www.bing.com/images/search?q=${encodeURIComponent(query)}&form=HDRSC2&first=1&tsc=ImageBasicHover`
  const { data } = await axios.get(searchUrl)
  const $ = cheerio.load(data)
  const imageUrls = []

  $('a.iusc').each((i, el) => {
    const m = $(el).attr('m')
    if (m) {
      const match = m.match(/"murl":"(.*?)"/)
      if (match && match[1]) {
        imageUrls.push(match[1])
      }
    }
  })

  return {
    author: config.author,
    result: imageUrls
  }
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Masukkan query pencarian gambar\nContoh: ${usedPrefix + command} kucing`

  const res = await BingImages(text)

  if (!res.result.length) throw 'Gambar tidak ditemukan'

  const randomImg = res.result[Math.floor(Math.random() * res.result.length)]

  const buttons = [
    {
      buttonId: `${usedPrefix + command} ${text}`,
      buttonText: { displayText: 'Berikutnya' },
      type: 1
    }
  ]

  const message = {
    image: { url: randomImg },
    caption: `Hasil pencarian Bing untuk *${text}*\n\n© ${res.author}`,
    footer: `Request By ${m.pushName}`,
    buttons: buttons,
    headerType: 1,
    viewOnce: true
  }

  return await conn.sendMessage(m.chat, message, { quoted: m })
}

handler.help = ['bingimg <query>']
handler.tags = ['internet']
handler.command = /^bingimg$/i
handler.register = true;
handler.limit = true;

export default handler