let handler = m => m;

handler.before = async function (m, { conn, isBotAdmin, isAdmin, isOwner }) {
  if ((m.isBaileys && m.fromMe) || m.fromMe || !m.isGroup || isAdmin) return true;

  let chatId = m.chat;
  let groupData = global.db.data.chats[chatId];

  if (!groupData.antispam) return false;

  let sender = m.sender;
  let tag = '@' + sender.split`@`[0];
  const isSticker = (m.mtype === 'stickerMessage');
  const isText = (m.mtype === 'extendedTextMessage');

  if (!groupData.users) groupData.users = {};
  let users = groupData.users;

  if (!users[sender]) users[sender] = { stickerCount: 0, textCount: 0, lastSticker: 0, lastText: 0 };

  if (isSticker) {
    let timeSinceLastSticker = m.messageTimestamp.toNumber() - users[sender].lastSticker;

    if (timeSinceLastSticker <= 10) {
      users[sender].stickerCount += 1;
      if (users[sender].stickerCount > 5) {
        await m.reply(`*「 ANTI SPAM STICKER 」*\n\nDetected *${tag}*, kamu spam stiker lebih dari 5 kali!\n\n> Auto kick dari grup!`);
        if (isBotAdmin && !isOwner) {
          await conn.groupParticipantsUpdate(m.chat, [sender], 'remove');
          users[sender].stickerCount = 0;
        } else if (isOwner) {
          await m.reply("Tolong jangan spam ya ka");
        }
        if (isBotAdmin) await conn.sendMessage(m.chat, { delete: m.key });
      } else {
        await m.reply(`*「 ANTI SPAM STICKER 」*\n\nDetected *${tag}*, kamu mengirim stiker terlalu cepat!\n\nWarn *${users[sender].stickerCount}/5*`);
      }
    } else {
      users[sender].stickerCount = 1;
      users[sender].lastSticker = m.messageTimestamp.toNumber();
    }
  }

  if (isText) {
    let timeSinceLastText = m.messageTimestamp.toNumber() - users[sender].lastText;

    if (timeSinceLastText <= 15) {
      users[sender].textCount += 1;
      if (users[sender].textCount > 10) {
        await m.reply(`*「 ANTI SPAM TEKS 」*\n\nDetected *${tag}*, kamu spam teks lebih dari 10 kali!\n\n> Auto kick dari grup!`);
        if (isBotAdmin && !isOwner) {
          await conn.groupParticipantsUpdate(m.chat, [sender], 'remove');
          users[sender].textCount = 0;
        } else if (isOwner) {
          await m.reply("Tolong jangan spam ya ka");
        }
        if (isBotAdmin) await conn.sendMessage(m.chat, { delete: m.key });
      } else {
        await m.reply(`*「 ANTI SPAM TEKS 」*\n\nDetected *${tag}*, kamu mengirim teks terlalu cepat!\n\nWarn *${users[sender].textCount}/10*`);
      }
    } else {
      users[sender].textCount = 1;
      users[sender].lastText = m.messageTimestamp.toNumber();
    }
  }

  return true;
};

handler.group = true;
handler.botAdmin = true;

export default handler;