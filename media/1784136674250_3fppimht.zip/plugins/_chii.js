const ownerID = '6283854025278@s.whatsapp.net';

let handler = async (m, { conn }) => {
  const randomTexts = [
    'Ada apa manggil manggil?',
    'Hmm??',
    'Nyariin Ya?',
    'Mandi sono lu',
    'Apa coba',
    'Napa butuh bantuan?',
    'Berisik luh',
    'Kenapa dah',
    'sok asyik manggil²',
    'diem suki',
    'ngapa? kangen?',
    'Hah?',
  ];

  const ownerTexts = [
    'Kenapa sayangkuu',
    'Aku di sini sayang',
    'Makan belum Ar?',
    'Aku di sini sensei',
  ];

  const premiumTexts = [
    'Kenapa sayang? mau cium?!',
    'Iyaa kenapa sayangkuu?',
    'Udah makan blom?',
    'Aloww!',
  ];

  const isOwner = m.sender === ownerID;

  const isPremium = global.db.data.users[m.sender]?.premium;

  const randomText = randomTexts[Math.floor(Math.random() * randomTexts.length)];
  const randomOwnerText = ownerTexts[Math.floor(Math.random() * ownerTexts.length)];
  const randomPremiumText = premiumTexts[Math.floor(Math.random() * premiumTexts.length)];

  let replyText = isOwner
    ? randomOwnerText
    : isPremium
    ? randomPremiumText
    : randomText;

  conn.reply(m.chat, replyText, floc);
};

handler.customPrefix = /^(chii|bot|chi|@6283854025278)$/i;
handler.command = new RegExp();

export default handler;