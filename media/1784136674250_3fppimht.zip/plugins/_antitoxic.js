const isToxic = /\b(wa\.me|anjing|anjg|ajg|anj|anjim|anji|lonte|lont|lnt|kontol|kont(?=\W|$)|kntl|kntol|kuntul|memek|memk|mmk|meki|yatim|yatm|ytm|puki|pukimak|puqimak|asu|asw|bajingan|bjngan|bangsat|tempek|ngentot|ngentod|ngntd|ngntot|ngentd|penis|peler|pepek|pelacur|tolol|goblok|gblk|bloon|bencong|banci|jembut|colmek|coli|masturbasi|masturbate|ngewe|bokep|hentai|mesum|porn|porno|desah|tetek|titit|pantat|butt|boobs|dada|birahi|syahwat|cabul|sange|horny|ngaceng|erek|bugil|telanjang)\b/i;

let handler = m => m;

handler.before = async function (m, { conn, isBotAdmin, isAdmin }) {
    if (m.isBaileys && m.fromMe) return true;
    if (!m.isGroup || isAdmin) return true;

    let chatId = m.chat;
    let groupData = global.db.data.chats[chatId] || {};
    let sender = m.sender;
    let name = conn.getName(sender);
    const isAntiToxic = isToxic.exec(m.text);

    if (!groupData.antiToxic || !isAntiToxic) return false;

    if (isBotAdmin) {
        await conn.sendMessage(m.chat, { delete: m.key }).catch(() => {});
        await m.reply(
            `*「 ANTI TOXIC 」*\n\nPesan dari *${name}* telah dihapus karena mengandung kata tidak sopan: "*${isAntiToxic[0]}*"`
        );
    }

    return true;
};

handler.group = true;
handler.botAdmin = true;

export default handler;