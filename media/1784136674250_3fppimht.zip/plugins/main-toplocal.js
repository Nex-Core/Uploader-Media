let handler = async (m, { conn, participants }) => {
    conn.sendMessage(m.chat, {
        react: {
            text: '🕒',
            key: m.key,
        }
    });
    
    let member = participants.map(u => u.id);
    let kontol = {};
    
    // Mengambil data pengguna, kecuali bot dan pengguna itu sendiri
    for (let i = 0; i < member.length; i++) {
        if (typeof global.db.data.users[member[i]] != 'undefined' && member[i] != conn.user.jid && member[i] != conn.user.jid.split('@')[0] + '@s.whatsapp.net') {
            kontol[member[i]] = {
                eris: global.db.data.users[member[i]].eris,
                level: global.db.data.users[member[i]].level,
                limit: global.db.data.users[member[i]].limit
            };
        }
    }

    // Mengurutkan berdasarkan uang (eris) dan limit
    let eris = Object.entries(kontol).sort((a, b) => b[1].eris - a[1].eris);
    let limit = Object.entries(kontol).sort((a, b) => b[1].limit - a[1].limit);
    let rankeris = eris.map(v => v[0]);
    let rankLimit = limit.map(v => v[0]);
    let iseris = Math.min(10, eris.length);
    let isLimit = Math.min(10, limit.length);

    // Menyiapkan pesan dengan data teratas
    let teks = `*[ 🚩 ] T O P - L O C A L*\n`;
    teks += `*[ 🏆 ] You : ${rankeris.indexOf(m.sender) + 1}* of *${member.length}*\n`;
    teks += `*[ 🔥 ] Group :* ${await conn.getName(m.chat)}\n\n`;
    teks += eris.slice(0, iseris).map(([user, data], i) => 
        (i + 1) + '. @' + user.split`@`[0] + '\n   ◦  Money: ' + formatEris(data.eris) + '\n   ◦  *Level️ : ' + data.level + '*'
    ).join('\n');
    teks += `\n\n©Nishikigi Chisato By Rain..`;

    // Mengirim pesan
    m.reply(teks);
};

handler.command = /^toplokal|toplocal$/i;
handler.tags = ["main"];
handler.help = ["toplocal"];
handler.register = true;
handler.group = true;

export default handler;

// Fungsi untuk memformat angka besar menjadi format yang lebih mudah dibaca
function formatEris(amount) {
    if (amount >= 1e63) return (amount / 1e63).toFixed(2).replace(/\.00$/, '') + " vigintiliun";
    if (amount >= 1e60) return (amount / 1e60).toFixed(2).replace(/\.00$/, '') + " novemdesiliun";
    if (amount >= 1e57) return (amount / 1e57).toFixed(2).replace(/\.00$/, '') + " octodesiliun";
    if (amount >= 1e54) return (amount / 1e54).toFixed(2).replace(/\.00$/, '') + " septendesiliun";
    if (amount >= 1e51) return (amount / 1e51).toFixed(2).replace(/\.00$/, '') + " sexdesiliun";
    if (amount >= 1e48) return (amount / 1e48).toFixed(2).replace(/\.00$/, '') + " quindesiliun";
    if (amount >= 1e45) return (amount / 1e45).toFixed(2).replace(/\.00$/, '') + " kvatradesiliun";
    if (amount >= 1e42) return (amount / 1e42).toFixed(2).replace(/\.00$/, '') + " tredesiliun";
    if (amount >= 1e39) return (amount / 1e39).toFixed(2).replace(/\.00$/, '') + " dodesiliun";
    if (amount >= 1e36) return (amount / 1e36).toFixed(2).replace(/\.00$/, '') + " undesiliun";
    if (amount >= 1e33) return (amount / 1e33).toFixed(2).replace(/\.00$/, '') + " desiliun";
    if (amount >= 1e30) return (amount / 1e30).toFixed(2).replace(/\.00$/, '') + " noniliun";
    if (amount >= 1e27) return (amount / 1e27).toFixed(2).replace(/\.00$/, '') + " oktiliun";
    if (amount >= 1e24) return (amount / 1e24).toFixed(2).replace(/\.00$/, '') + " septiliun";
    if (amount >= 1e21) return (amount / 1e21).toFixed(2).replace(/\.00$/, '') + " sekstiliun";
    if (amount >= 1e18) return (amount / 1e18).toFixed(2).replace(/\.00$/, '') + " quintiliun";
    if (amount >= 1e15) return (amount / 1e15).toFixed(2).replace(/\.00$/, '') + " quadriliun";
    if (amount >= 1e12) return (amount / 1e12).toFixed(2).replace(/\.00$/, '') + " triliun";
    if (amount >= 1e9) return (amount / 1e9).toFixed(2).replace(/\.00$/, '') + " miliar";
    if (amount >= 1e6) return (amount / 1e6).toFixed(2).replace(/\.00$/, '') + " juta";
    if (amount >= 1e3) return (amount / 1e3).toFixed(2).replace(/\.00$/, '') + " ribu";
    if (amount >= 1) return amount.toFixed(2).replace(/\.00$/, '') + " p"; // Puluhan
    return amount.toString(); // Angka kecil tetap apa adanya
}