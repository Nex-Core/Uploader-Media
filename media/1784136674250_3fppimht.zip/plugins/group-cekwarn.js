let handler = async (m, { conn, args }) => {
    // Check if a user is mentioned
    let mention = m.mentionedJid && m.mentionedJid[0] || conn.parseMention(args[0]);

    // If no user is mentioned, default to checking the sender
    if (!mention) {
        mention = m.sender; // Default to the sender if no mention is provided
    }

    // Check if the user exists in the database
    if (!(mention in global.db.data.users)) {
        return m.reply('Tag salah satu yg sudah terdaftar ke dalam database!');
    }

    let user = global.db.data.users[mention];

    // Initialize warn2 if it's not set
    if (!user.warn2) user.warn2 = 0;

    // Determine if the mention is the sender
    let isSelf = mention === m.sender;
    let username = isSelf ? 'Kamu' : `@${mention.split('@')[0]}`;

    // Reply with the warning count
    m.reply(`${username} memiliki *${user.warn2}/3* warn.`, null, { mentions: [mention] });
}

handler.help = ['cekwarn @mention']
handler.tags = ['group']
handler.command = /^cekwarn$/i
handler.group = true

export default handler;