import FormData from "form-data";
import axios from "axios";

let handler = m => m;

handler.before = async function (m, { conn, isBotAdmin, isAdmin }) {
  if ((m.isBaileys && m.fromMe) || m.fromMe || !m.isGroup || isAdmin) return true;

  const chatId = m.chat;
  const groupData = global.db.data.chats[chatId] || {};
  if (!groupData.antiPornStatus) return false;

  const q = m.quoted ? m.quoted : m;
  const mime = (q.msg || q).mimetype || "";
  if (!/^image|sticker/.test(mime)) return true;

  try {
    if (!isBotAdmin) return;

    const media = await q.download();
    if (!media) return;

    const form = new FormData();
    form.append("file", media, {
      filename: `upload_${Date.now()}.jpg`,
      contentType: mime.startsWith("image/") ? mime : "image/jpeg"
    });

    const nyckelURL = "https://www.nyckel.com/v1/functions/o2f0jzcdyut2qxhu/invoke";
    const response = await axios.post(nyckelURL, form, { headers: form.getHeaders() });
    const result = response.data;

    const label = result?.labelName || "Unknown";
    const confidence = result?.confidence || 0;

    if (label === "Porn" && confidence >= 0.40) {
      const sender = m.sender;
      const tag = "@" + sender.split("@")[0];

      await conn.sendMessage(m.chat, {
        text: `*「 ANTI PORN 」*\n\nTerdeteksi *${tag}* mengirim konten pornografi! Pesan telah dihapus.\n\nConfidence: ${(confidence * 100).toFixed(2)}%`,
        mentions: [sender]
      });

      const keyToDelete = m.quoted ? m.quoted.key : m.key;
      await conn.sendMessage(m.chat, { delete: keyToDelete });
    }
  } catch {}

  return true;
};

handler.group = true;
handler.botAdmin = true;

export default handler;