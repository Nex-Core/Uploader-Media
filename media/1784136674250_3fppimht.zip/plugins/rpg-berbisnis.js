import { areJidsSameUser } from 'baileys'

function resolveJid(input, participants = []) {
    const found = participants.find(p =>
        areJidsSameUser(p?.id, input) ||
        areJidsSameUser(p?.lid, input) ||
        areJidsSameUser(p?.jid, input)
    )
    return found?.jid || input
}

let activeBusinesses = {}

let handler = async (m, { conn, text, participants }) => {
    function no(number) {
        return number.replace(/\s/g, '').replace(/([@+-])/g, '')
    }

    let users = global.db.data.users
    let user = users[m.sender] || (users[m.sender] = { eris: 0, exp: 0, lastBisnis: 0 })

    if (activeBusinesses[m.chat]) {
        throw `⚠️ *Ada bisnis yang sedang berjalan di grup ini! Tunggu hingga selesai (3 menit).*`
    }

    let cooldownTime = 600000
    let remaining = cooldownTime - (Date.now() - user.lastBisnis)

    if (remaining > 0) {
        let remainingMinutes = Math.floor(remaining / 60000)
        let remainingSeconds = Math.floor((remaining % 60000) / 1000)
        throw `⏰ *Kamu harus menunggu ${remainingMinutes} menit ${remainingSeconds} detik sebelum berbisnis lagi!*`
    }

    let args = text.trim().split(/\s+/)
    let modal = parseInt(args[0])

    if (!args[0] || isNaN(modal)) {
        return conn.reply(m.chat, 
            `📖 *Tutorial Berbisnis* 📖\n\n` +
            `Bisnis adalah permainan RPG di grup untuk mencari keuntungan atau rugi bersama!\n\n` +
            `🔹 *Cara Pakai*: .berbisnis [modal] @tag1 @tag2 @tag3\n` +
            `   - *Modal*: Masukkan jumlah antara 100 Ribu - 100 Juta (contoh: 500000 untuk 500 Ribu).\n` +
            `   - *Tag*: Mention 2-4 orang di grup (kamu otomatis jadi peserta).\n` +
            `   - Contoh: .berbisnis 500000 @user1 @user2 @user3\n\n` +
            `🔹 *Aturan*:\n` +
            `   - Semua peserta harus punya cukup uang (eris) sesuai modal.\n` +
            `   - Bisnis langsung mulai, tunggu 3 menit untuk hasil.\n` +
            `   - Hasil bisa rugi (0-100%) atau untung (1-10x modal), dengan peluang 10% bonus keberuntungan (3x lipat).\n` +
            `   - Cooldown: 10 menit setelah memulai bisnis.\n\n` +
            `💡 *Tips*: Pilih modal yang aman dan ajak teman terpercaya!`, 
            m
        )
    }

    if (modal < 100000 || modal > 100000000) 
        throw `💰 *Modal minimal adalah 100 Ribu dan maksimal 100 Juta!*`

    let targetUsers = []
    
    for (let i = 1; i < args.length; i++) {
        let targetText = no(args[i])
        let targetUser

        if (targetText.startsWith('@')) {
            targetUser = targetText.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
        } else if (targetText.includes('@s.whatsapp.net') || targetText.includes('@lid')) {
            targetUser = targetText
        } else {
            targetUser = targetText.replace(/\D/g, '') + '@s.whatsapp.net'
        }

        if (m.isGroup) {
            targetUser = resolveJid(targetUser, participants)
        }

        if (targetUser && targetUser !== m.sender) {
            targetUsers.push(targetUser)
        }
    }

    if (targetUsers.length === 0 && m.mentionedJid && m.mentionedJid.length > 0) {
        targetUsers = m.mentionedJid.filter(jid => jid !== m.sender)
        if (m.isGroup) {
            targetUsers = targetUsers.map(jid => resolveJid(jid, participants))
        }
    }

    if (targetUsers.length < 2 || targetUsers.length > 4) 
        throw `⚠️ *Minimal tag 2 orang dan maksimal 4 orang (kamu otomatis jadi peserta)!*`

    for (let targetUser of targetUsers) {
        if (!users[targetUser]) {
            users[targetUser] = { eris: 0, exp: 0 }
        }
        
        if (users[targetUser].eris < modal) {
            let targetName = '@' + targetUser.split('@')[0]
            throw `💸 *${targetName} tidak memiliki cukup uang untuk modal! Minimal modal 100 Ribu*`
        }
        
        if (targetUser === conn.user.jid) 
            throw `❌ *Kamu tidak bisa ajak bot berbisnis!*`
    }

    if (user.eris < modal)
        throw `💸 *Kamu tidak memiliki cukup modal! Minimal modal 100 Ribu*`

    let participantsList = [m.sender, ...targetUsers]

    user.lastBisnis = Date.now()
    activeBusinesses[m.chat] = true

    startBusiness(m, conn, modal, participantsList)
}

function formatNumber(num) {
    if (num >= 1000000) return (num / 1000000).toFixed(1).replace(/\.0$/, '') + ' Juta'
    if (num >= 1000) return (num / 1000).toFixed(1).replace(/\.0$/, '') + ' Ribu'
    return num.toString()
}

function startBusiness(m, conn, modal, participants) {
    let users = global.db.data.users

    participants.forEach(id => {
        users[id].eris -= modal
    })

    conn.reply(
        m.chat,
        `📝 *[Berbisnis Dimulai]*\n\n💼 Modal masing-masing: *${formatNumber(modal)}*\n\n⏳ Tunggu 3 menit untuk hasilnya...\n\n*Peserta Bisnis:*\n${participants.map(id => '🔹 @' + id.split('@')[0]).join('\n')}`,
        m, { mentions: participants }
    )

    setTimeout(() => {
        let result = Math.random()
        let multiplier
        let outcome
        let bonusLuck = Math.random() < 0.1

        if (result < 0.1) {
            multiplier = Math.random() * 0.3
            outcome = "🚨 Rugi Besar! Bangkrut Total!"
        } else if (result < 0.3) {
            multiplier = Math.random() * 0.7 + 0.3
            outcome = "📉 Rugi Sedikit!"
        } else if (result < 0.5) {
            multiplier = Math.random() * 2 + 1
            outcome = "💵 Untung Kecil!"
        } else if (result < 0.8) {
            multiplier = Math.random() * 3 + 2
            outcome = "💰 Untung Besar!"
        } else {
            multiplier = Math.random() * 5 + 5
            outcome = "🎉 Jackpot! Untung Sangat Besar!"
        }

        if (bonusLuck) {
            multiplier *= 3
            outcome += `\n🍀 *Bonus Keberuntungan!* 🎲`
        }

        let reward = Math.floor(modal * multiplier)

        participants.forEach(id => {
            users[id].eris += reward
        })

        conn.reply(
            m.chat,
            `🏅 *[Hasil Bisnis]*\n\n${outcome}\n\n🎁 Kalian mendapatkan: *${formatNumber(reward)}* dari modal *${formatNumber(modal)}*\n\n*Peserta Mendapat:*\n${participants.map(id => `🔹 @${id.split('@')[0]}: *+${formatNumber(reward)}*`).join('\n')}\n\n💼 *Sampai Jumpa di Bisnis Berikutnya!*`,
            m, { mentions: participants }
        )

        delete activeBusinesses[m.chat]
    }, 180000)
}

handler.help = ['berbisnis [modal] @user1 @user2']
handler.tags = ['rpg']
handler.command = /^berbisnis$/i
handler.limit = true
handler.group = true
handler.register = true

export default handler