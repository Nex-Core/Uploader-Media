import axios from "axios";
import crypto from "crypto";
import { FormData, Blob } from "formdata-node";
import { fileTypeFromBuffer } from "file-type";
import fakeUserAgent from "fake-useragent";

const handler = async (m, { conn, usedPrefix, command }) => {
  const q = m.quoted ? m.quoted : m;
  const mime = (q.msg || q).mimetype || "";

  if (!/image/.test(mime))
    return conn.sendMessage(
      m.chat,
      { text: `Balas gambar dengan caption ${usedPrefix + command}` },
      { quoted: floc }
    );

  const prompt = "hitamkan kulitnya";

  await conn.sendMessage(m.chat, { react: { text: "✨", key: m.key } });

  try {
    const buffer = await q.download();
    const { ext } = (await fileTypeFromBuffer(buffer)) || { ext: "jpg" };
    const formData = new FormData();
    const randomName = crypto.randomBytes(5).toString("hex");

    formData.append(
      "file",
      new Blob([buffer], { type: "application/octet-stream" }),
      `${randomName}.${ext}`
    );

    const uploadRes = await axios.post(
      "https://tmpfiles.org/api/v1/upload",
      formData,
      { headers: { "User-Agent": fakeUserAgent() } }
    );

    const match = /https?:\/\/tmpfiles.org\/(.*)/.exec(
      uploadRes.data.data.url
    );
    const imageUrl = `https://tmpfiles.org/dl/${match[1]}`;

    const apiUrl = `https://api-faa.my.id/faa/editfoto?url=${encodeURIComponent(
      imageUrl
    )}&prompt=${encodeURIComponent(prompt)}`;

    const res = await axios.get(apiUrl, { responseType: "arraybuffer" });

    await conn.sendMessage(
      m.chat,
      {
        image: Buffer.from(res.data),
        caption: `✨ *Berhasil dihytamkan!*`
      },
      { quoted: floc }
    );
  } catch (e) {
    await conn.sendMessage(
      m.chat,
      { text: "Gagal menghytamkan gambar." },
      { quoted: floc }
    );
  } finally {
    await conn.sendMessage(m.chat, { react: { text: "", key: m.key } });
  }
};

handler.help = ["hytamkan"].map(v => v + " <reply image>");
handler.tags = ["ephoto"];
handler.command = /^hytamkan$/i;
handler.register = true;
handler.limit = true;

export default handler;