import PhoneNumber from 'awesome-phonenumber';
import { areJidsSameUser } from 'baileys';

function resolveJid(input, participants = []) {
    const found = participants.find(p =>
        areJidsSameUser(p?.id, input) ||
        areJidsSameUser(p?.lid, input) ||
        areJidsSameUser(p?.jid, input)
    );
    return found?.jid || input;
}

function no(number) {
    return number.replace(/\s/g, '').replace(/([@+-])/g, '');
}

let handler = async (m, { conn, text, participants, usedPrefix }) => {
    if (!text) {
        return conn.reply(m.chat, `Masukkan nomor, tag, atau balas pesan target`, m);
    }

    let who;
    let amount;

    const args = text.trim().split(/\s+/);
    const target = args[0];
    amount = args[1];

    if (!amount || isNaN(amount)) {
        return conn.reply(m.chat, `Masukkan jumlah balance yang valid (angka)`, m);
    }

    let poin = parseInt(amount);
    if (poin < 1) {
        return conn.reply(m.chat, `Minimal balance yang ditambahkan adalah 1`, m);
    }

    text = no(target);

    if (m.quoted) {
        who = m.quoted.sender;
    } else if (m.mentionedJid?.length) {
        who = m.mentionedJid[0];
    } else if (text) {
        if (target.startsWith('@')) {
            who = target.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        } else if (target.includes('@s.whatsapp.net') || target.includes('@lid')) {
            who = target;
        } else {
            who = target.replace(/\D/g, '') + '@s.whatsapp.net';
        }
    }

    if (m.isGroup) {
        who = resolveJid(who, participants);
    }

    if (!who) {
        return conn.reply(m.chat, `Target atau nomor tidak ditemukan, mungkin sudah keluar atau bukan anggota grup ini`, m);
    }

    let users = global.db.data.users;
    if (!users[who]) {
        return conn.reply(m.chat, `User tidak ditemukan di database`, m);
    }

    users[who].balance += poin;

    conn.reply(m.chat, `Selamat Kak @${who.split`@`[0]}. Kamu mendapatkan balance dari Owner sebanyak +${poin} balance!`, m, { mentions: [who] });
};

handler.help = ['addbalance @tag|+phone <amount>'];
handler.tags = ['owner'];
handler.command = /^addbalance$/i;
handler.owner = true;

export default handler;