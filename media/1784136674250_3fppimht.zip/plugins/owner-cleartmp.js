import cp from 'child_process';
import { promisify } from 'util';

const exec = promisify(cp.exec).bind(cp);

const handler = async (m) => {
    try {
        // Get the total size of the files in the tmp directory
        const sizeOutput = await exec('du -sh tmp/* 2>/dev/null | awk \'{sum+=$1} END {print sum}\' || echo "0B"');
        const sizeBefore = sizeOutput.stdout.trim() || '0B'; // Handle if there are no files

        // Count the number of files in the tmp directory
        const countOutput = await exec('find tmp -type f | wc -l');
        const fileCountBefore = parseInt(countOutput.stdout.trim(), 10);

        // Remove the tmp directory and recreate it
        await exec('rm -rf tmp && mkdir tmp');

        // The size of the tmp directory after cleanup is now 0
        const sizeAfter = '0B';
        const totalDeleted = fileCountBefore;

        // Send the info about the deleted size and the number of files
        await conn.reply(m.chat, `Deleted:\n- Size of files before: ${sizeBefore}\n- Total files deleted: ${totalDeleted}\n- Size after: ${sizeAfter}\nDone`, m);
    } catch (error) {
        await conn.reply(m.chat, `An error occurred: ${error.message}`, m);
    }
};

handler.help = ['cleartmp'];
handler.tags = ['owner'];
handler.command = /^(cleartmp|deltmp)$/i;
handler.rowner = true;

export default handler;