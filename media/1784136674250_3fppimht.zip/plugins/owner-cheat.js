const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = (await import('baileys')).default;
import fs from 'fs';

let handler = async (m, { conn, command }) => {
    let user = global.db.data.users[m.sender];

    switch (command) {
        case 'cheatall':
            user.legendary = 500000;
            user.health = 99999999;
            user.cupon = 50000;
            user.eris = Infinity;
            user.limit = Infinity;
            user.balance = 50000;
            user.uncommon = 2000000;
            user.common = 2000000;
            user.mythic = 2000000;
            user.legendary = 2000000;
            user.superior = 2000000;
            user.level = 12345;
            user.exp = 999999999;
            user.stamina = 999999999;
            sendCheatMessage(m, conn, '*Succes Cheat Semua Item!*');
            break;

        case 'cheatlegendary':
            user.legendary = 500000;
            sendCheatMessage(m, conn, '*Succes Cheat Legendary!*');
            break;

        case 'cheatdarah':
            user.health = 99999999;
            sendCheatMessage(m, conn, '*Succes Cheat Darah Sampai 99999999!*');
            break;

        case 'cheatcupon':
            user.cupon = 50000;
            sendCheatMessage(m, conn, '*Succes Cheat Cupon!*');
            break;

        case 'minggirlumiskin':
            user.eris = Infinity;
            sendCheatMessage(m, conn, '*Succes Cheat Money!*');
            break;

        case 'cheatlimit':
            user.limit = Infinity;
            sendCheatMessage(m, conn, '*Succes Cheat Limit!*');
            break;

        case 'cheatbalance':
            user.balance = 50000;
            sendCheatMessage(m, conn, '*Succes Cheat Balance!*');
            break;

        case 'cheatcrate':
            user.cupon = 2000000;
            user.uncommon = 2000000;
            user.common = 2000000;
            user.mythic = 2000000;
            user.legendary = 2000000;
            user.superior = 2000000;
            sendCheatMessage(m, conn, '*Succes Cheat Crate!*');
            break;

        case 'cheatlevel':
            user.level = 12345;
            sendCheatMessage(m, conn, '*Succes Cheat Level Sampai 12345!*');
            break;

        case 'cheatexp':
            user.exp = 999999999;
            sendCheatMessage(m, conn, '*Succes Cheat Exp!*');
            break;

        case 'cheatstamina':
            user.stamina = 999999999;
            sendCheatMessage(m, conn, '*Succes Cheat Stamina!*');
            break;

        case 'cheat':
            sendCheatMenu(m, conn);
            break;

        default:
            return;
    }
};

function sendCheatMessage(m, conn, text) {
    let buttons = [
        { buttonId: '.cheat', buttonText: { displayText: 'Kembali ke Menu Cheat' }, type: 1 }
    ];
    
    let buttonMessage = {
        text,
        footer: 'Hanya untuk Owner!',
        buttons,
        headerType: 1
    };

    conn.sendMessage(m.chat, buttonMessage);
}

function sendCheatMenu(m, conn) {
    const cheatMenu = {
        title: "Menu Cheat",
        sections: [
            {
                title: "Cheat Khusus Owner",
                rows: [
                    { title: "Cheat All", description: "Gunakan cheat ini untuk semua item", id: '.cheatall' },
                    { title: "Cheat Legendary", description: "Menambahkan 500000 legendary", id: '.cheatlegendary' },
                    { title: "Cheat Darah", description: "Mengatur darah menjadi 99999999", id: '.cheatdarah' },
                    { title: "Cheat Cupon", description: "Menambahkan 50000 cupon", id: '.cheatcupon' },
                    { title: "Cheat Money", description: "Menambahkan uang tanpa batas", id: '.minggirlumiskin' },
                    { title: "Cheat Limit", description: "Menambahkan limit tanpa batas", id: '.cheatlimit' },
                    { title: "Cheat Balance", description: "Menambahkan 50000 balance", id: '.cheatbalance' },
                    { title: "Cheat Crate", description: "Menambahkan berbagai jenis crate", id: '.cheatcrate' },
                    { title: "Cheat Level", description: "Mengatur level ke 12345", id: '.cheatlevel' },
                    { title: "Cheat Exp", description: "Menambahkan 999999999 exp", id: '.cheatexp' },
                    { title: "Cheat Stamina", description: "Menambahkan 999999999 stamina", id: '.cheatstamina' }
                ]
            }
        ]
    };

    let message = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: `_*Menu Cheat Khusus Arull Tersayang*_\n\nPilih cheat yang ingin digunakan:`
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: 'Hanya untuk Owner!'
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [{
                            "name": "single_select",
                            "buttonParamsJson": JSON.stringify(cheatMenu)
                        }]
                    })
                })
            }
        }
    }, {});

    conn.relayMessage(m.chat, message.message, {});
}

handler.help = ['cheat']
handler.tags = ['owner']
handler.rowner = true
handler.command = /^(cheat|cheatall|cheatlegendary|cheatdarah|cheatcupon|minggirlumiskin|cheatlimit|cheatbalance|cheatcrate|cheatlevel|cheatexp|cheatstamina)$/i;

export default handler;