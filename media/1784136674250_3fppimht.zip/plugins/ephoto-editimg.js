import axios from "axios";
import crypto from "crypto";
import { FormData, Blob } from "formdata-node";
import { fileTypeFromBuffer } from "file-type";
import fakeUserAgent from "fake-useragent";

const handler = async (m, { conn, text, usedPrefix, command }) => {
  const q = m.quoted ? m.quoted : m;
  const mime = (q.msg || q).mimetype || "";

  if (!/image/.test(mime))
    return conn.sendMessage(
      m.chat,
      { text: `Balas gambar dengan caption ${usedPrefix + command} <prompt>` },
      { quoted: floc }
    );

  if (!text)
    return conn.sendMessage(
      m.chat,
      { text: "Masukkan prompt untuk edit gambar!" },
      { quoted: floc }
    );

  await conn.sendMessage(m.chat, { react: { text: "✨", key: m.key } });

  try {
    const img = await q.download();
    const imageUrl = await uploadTmpfiles(img);

    const encodedUrl = encodeURIComponent(imageUrl);
    const encodedPrompt = encodeURIComponent(text);
    
    const apiUrl = `https://api-faa.my.id/faa/editfoto?url=${encodedUrl}&prompt=${encodedPrompt}`;

    const response = await axios.get(apiUrl, {
      responseType: 'arraybuffer'
    });

    if (!response.data) {
      throw new Error("Gagal mendapatkan hasil dari API");
    }

    await conn.sendMessage(
      m.chat,
      {
        image: Buffer.from(response.data),
        caption: `✨ *Edit Image Selesai!*\n\n> Prompt: ${text}`,
      },
      { quoted: floc }
    );
  } catch (e) {
    await conn.sendMessage(m.chat, { text: `Error: ${e.message}` }, { quoted: floc });
  } finally {
    await conn.sendMessage(m.chat, { react: { text: "", key: m.key } });
  }
};

handler.help = ["editimg"].map(a => a + " <reply image>");
handler.tags = ["ephoto"];
handler.command = /^(editimg|editfoto|editimage)$/i;
handler.register = true;
handler.premium = true;

export default handler;

async function uploadTmpfiles(content) {
  const { ext } = (await fileTypeFromBuffer(content)) || { ext: "jpg" };
  const formData = new FormData();
  const randomBytes = crypto.randomBytes(5).toString("hex");
  formData.append(
    "file",
    new Blob([content], { type: "application/octet-stream" }),
    `${randomBytes}.${ext}`
  );
  const response = await axios.post("https://tmpfiles.org/api/v1/upload", formData, {
    headers: { "User-Agent": fakeUserAgent() },
  });
  const result = response.data;
  const match = /https?:\/\/tmpfiles.org\/(.*)/.exec(result.data.url);
  return `https://tmpfiles.org/dl/${match[1]}`;
}