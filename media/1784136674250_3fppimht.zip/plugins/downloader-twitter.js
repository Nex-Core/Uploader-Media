import axios from "axios";
import BodySender from "form-data";
import * as cheerio from "cheerio";

const BASE_URL = "https://savetwitter.net";
const AJAX_URL = "/api/ajaxSearch";

async function savetwitter(url) {
  let d = new BodySender();
  d.append("q", url);
  d.append("lang", "en");
  d.append("cftoken", "");
  let headers = { ...d.getHeaders() };
  let { data: html } = await axios.post(BASE_URL + AJAX_URL, d, { headers });

  const $ = cheerio.load(html.data);

  if ($(".photo-list").length) {
    const images = [];
    $(".photo-list .download-items__thumb img").each((i, el) => {
      images.push({
        type: "image",
        thumb: $(el).attr("src"),
        download: $(el).closest(".download-items").find("a").attr("href"),
      });
    });
    return images;
  }

  if ($(".tw-video").length) {
    const videos = [];
    $(".tw-video .tw-right .dl-action a").each((i, el) => {
      videos.push({
        type: "video",
        quality: $(el).text().trim().replace("Download MP4", "").trim(),
        download: $(el).attr("href"),
      });
    });

    return videos.length ? [videos[0]] : [];
  }

  return { error: "Gak nemu media" };
}

let handler = async (m, { text, conn, usedPrefix, command }) => {
  if (!text) return m.reply(`Masukin link videonya\n\nContoh: ${usedPrefix + command} https://x.com/xxxxxx`);

  conn.sendMessage(m.chat, { react: { text: "🌸", key: m.key } });

  try {
    let media = await savetwitter(text);
    
    if (media.error) throw "Gak nemu media atau link salah";

    if (Array.isArray(media)) {
      for (let item of media) {
        let fileType = item.type === "video" ? "mp4" : "jpg";
        let caption = `Request By ${m.pushName}`;

        await conn.sendFile(m.chat, item.download, `twitter.${fileType}`, caption, m, 0, {
          mimetype: item.type === "video" ? "video/mp4" : "image/jpeg",
          fileName: `twitter.${fileType}`,
        });

        if (item.type === "video") break;
      }
      conn.sendMessage(m.chat, { react: { text: "🍁️", key: m.key } });
    } else {
      throw "Gak nemu media";
    }
  } catch (e) {
    conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    m.reply(typeof e === "string" ? e : "Ada masalah pas ngunduh");
  }
};

handler.help = ['twitter'].map(v => v + ' <url>');
handler.tags = ['downloader'];
handler.command = /^((twt|twitter)(dl)?)$/i;

handler.register = true;
handler.limit = true;

export default handler;