import axios from "axios";
import crypto from "crypto";
import { FormData, Blob } from "formdata-node";
import { fileTypeFromBuffer } from "file-type";
import fakeUserAgent from "fake-useragent";

const handler = async (m, { conn, usedPrefix, command }) => {
  let user = global.db?.data?.users?.[m.sender] || {};
  if (!user.cineUses) user.cineUses = 0;
  if (!user.lastCineReset) user.lastCineReset = 0;

  let now = Date.now();
  if (!user.premium && now - user.lastCineReset > 10 * 60 * 60 * 1000) {
    user.cineUses = 0;
    user.lastCineReset = now;
  }

  if (!user.premium && user.cineUses >= 3) {
    return m.reply(
      `*Limit Cinematic habis* (${user.cineUses}/3)\n` +
      `Tunggu 10 jam untuk reset atau upgrade ke premium.\n\n` +
      `> Ketik: ${usedPrefix}premium`
    );
  }

  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";

  if (!mime) throw `Kirim/Reply gambar dengan caption *${usedPrefix + command}*`;
  if (!/image\/(jpe?g|png)/.test(mime)) throw `Mime ${mime} tidak support`;

  const react = { react: { text: "🎬", key: m.key } };
  const reactdone = { react: { text: "✨", key: m.key } };

  try {
    await conn.sendMessage(m.chat, react);

    const img = await q.download();
    const imageUrl = await uploadTmpfiles(img);

    const api = `https://api.nexray.web.id/ephoto/cinematic?url=${encodeURIComponent(imageUrl)}`;

    const response = await axios.get(api, {
      responseType: "arraybuffer",
      headers: { "User-Agent": fakeUserAgent() }
    });

    const buffer = Buffer.from(response.data);

    let limitInfo = user.premium ? "Unlimited" : `${user.cineUses + 1}/3`;

    await conn.sendMessage(
      m.chat,
      {
        image: buffer,
        caption: `🎬 *Cinematic Style berhasil dibuat*\n\nPenggunaan: ${limitInfo}`,
        mentions: [m.sender]
      },
      { quoted: floc }
    );

    if (!user.premium) user.cineUses += 1;

  } catch (e) {
    let reason = e?.response?.data?.error || e?.message || e.toString();
    await conn.sendMessage(
      m.chat,
      { text: `✦ *Error saat membuat Cinematic Style*\n\n${reason}` },
      { quoted: floc }
    );
  } finally {
    await conn.sendMessage(m.chat, reactdone);
  }
};

handler.command = /^(tocinematic|cinematic)$/i;
handler.help = ["tocinematic"].map(v => v + " <reply image>");
handler.tags = ["ephoto"];
handler.register = true;

export default handler;

async function uploadTmpfiles(content) {
  const { ext } = (await fileTypeFromBuffer(content)) || { ext: "jpg" };

  const formData = new FormData();
  const randomBytes = crypto.randomBytes(5).toString("hex");

  formData.append(
    "file",
    new Blob([content], { type: "application/octet-stream" }),
    `${randomBytes}.${ext}`
  );

  const response = await axios.post(
    "https://tmpfiles.org/api/v1/upload",
    formData,
    { headers: { "User-Agent": fakeUserAgent() } }
  );

  const result = response.data;
  const match = /https?:\/\/tmpfiles.org\/(.*)/.exec(result.data.url);

  if (!match) throw new Error("Invalid tmpfiles URL format");

  return `https://tmpfiles.org/dl/${match[1]}`;
}