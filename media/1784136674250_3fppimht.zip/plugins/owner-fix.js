let handler = async (m, { conn, text }) => {
  let users = global.db.data.users

  var total = 0
  for (let jid in users) {
    if (jid === '6287738628808@s.whatsapp.net') continue

    if (users[jid].limit < 0) {
      users[jid].limit = 0
      total += 1
    }
    if (users[jid].joinlimit < 0) {
      users[jid].joinlimit = 0
      total += 1
    }
    if (users[jid].eris < 0) {
      users[jid].eris = 0
      total += 1
    }
    if (users[jid].healt < 0) {
      users[jid].healt = 0
      total += 1
    }
    if (users[jid].healt > 100) {
      users[jid].healt = 100
      total += 1
    }
    if (users[jid].stamina < 0) {
      users[jid].stamina = 0
      total += 1
    }
    if (users[jid].stamina > 100) {
      users[jid].stamina = 100
      total += 1
    }
    if (users[jid].exp < 0) {
      users[jid].exp = 0
      total += 1
    }
    if (users[jid].levl < 0) {
      users[jid].level = 0
      total += 1
    }
    users[jid].eris = Math.floor(users[jid].eris)
    users[jid].limit = Math.floor(users[jid].limit)
  }
  return conn.reply(m.chat, `*Berhasil Memperbaiki ${total} Error Di Database.*`, m)
}

handler.help = ['fix']
handler.tags = ['owner']
handler.command = /^(fix)$/i
handler.owner = true

export default handler