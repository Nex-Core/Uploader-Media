import { generateWAMessageFromContent } from 'baileys'

let handler = async (m, { conn, isROwner, text }) => {
  const delay = time => new Promise(res => setTimeout(res, time))
  let getGroups = await conn.groupFetchAllParticipating()
  let groups = Object.entries(getGroups).map(entry => entry[1])
  let pesan = m.quoted && m.quoted.text ? m.quoted.text : text
  if (!pesan) throw 'Teksnya mana?'

  m.reply(`Mengirim Broadcast ke ${groups.length} grup...\nEstimasi selesai dalam ${groups.length * 1.5} detik`)

  for (let group of groups) {
    await delay(1500)
    let metadata = await conn.groupMetadata(group.id)
    let participants = metadata.participants.map(p => p.id)

    let msg = generateWAMessageFromContent(group.id, {
      extendedTextMessage: {
        text: pesan,
        contextInfo: {
          mentionedJid: participants,
          externalAdReply: {
            title: wm,
            body: 'ʙʀᴏᴀᴅᴄᴀsᴛ ɢʀᴏᴜᴘs',
            mediaType: 1,
            previewType: 0,
            renderLargerThumbnail: true,
            thumbnailUrl: 'https://files.catbox.moe/rfj8ns.jpg',
            sourceUrl: 'https://whatsapp.com/channel/0029Vaycl600AgW75pWI6M2C',
            showAdAttribution: true
          }
        }
      }
    }, {
      quoted: m,
      userJid: conn.user.id
    })

    conn.relayMessage(group.id, msg.message, { messageId: msg.key.id }).catch(_ => _)
  }

  m.reply(`Broadcast selesai dikirim ke ${groups.length} grup!`)
}

handler.help = ['bcgcall <teks>']
handler.tags = ['owner']
handler.command = /^(bcgcall|broadcastgroupall|bcgc|bcgcallbot)$/i
handler.owner = true

export default handler