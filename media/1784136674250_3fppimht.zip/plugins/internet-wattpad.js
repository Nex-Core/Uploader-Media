import fetch from 'node-fetch'

let handler = async (m, { conn, text }) => {
  if (!text) throw 'Harap masukkan kata kunci cerita.';

  try {
    let res = await fetch(`https://api.agatz.xyz/api/wattpad?message=${encodeURIComponent(text)}`);
    let json = await res.json();

    if (json.status !== 200 || !json.data) {
      throw 'Data tidak ditemukan untuk cerita tersebut.';
    }

    let cerita = json.data[0]; // Mengambil cerita pertama dari array
    let message = `📖 **Judul Cerita:** ${cerita.title}\n` +
                  `📝 **Deskripsi:** ${cerita.desc}\n` +
                  `👁️ **Dibaca:** ${cerita.reads}\n` +
                  `⭐ **Vote:** ${cerita.vote}\n` +
                  `📚 **Jumlah Chapter:** ${cerita.chapter}\n` +
                  `🔗 **[Link Cerita](${cerita.link})**\n` +
                  `🖼️ **Thumbnail:** ![Image](${cerita.thumb})`;

    m.reply(message);
  } catch (e) {
    m.reply(`Terjadi kesalahan: ${e}`);
  }
};

handler.help = ['wattpad'];
handler.tags = ['internet'];
handler.command = /^(wattpad)$/i;
handler.limit = true;

export default handler;