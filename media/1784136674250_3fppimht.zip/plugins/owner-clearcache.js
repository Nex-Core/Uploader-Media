import cp from 'child_process';
import { promisify } from 'util';

let exec = promisify(cp.exec).bind(cp);

let handler = async (m) => {
    await conn.reply(m.chat, "Done", m);
    let o;
    try {
        o = await exec('rm -rf .cache/*'); // Menghapus isi dari folder .cache tanpa menghapus folder itu sendiri
    } catch (e) {
        o = e;
    }
};

handler.help = ['clearcache'];
handler.tags = ['owner'];
handler.command = /^(clearcache|delcache)$/i;
handler.rowner = true;

export default handler;