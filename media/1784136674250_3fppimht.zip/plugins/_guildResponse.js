const { proto, generateWAMessageFromContent } = (await import('baileys')).default;

let handler = async (m, { conn, command }) => {
    let ruang = conn.mabarQuest[m.chat];
    conn.guildQuest = conn.guildQuest || {};
    let room = conn.guildQuest[m.chat];

    if (ruang && ruang.state === 'pilihserver' && m.sender === ruang.master) {
        let user = global.db.data.users[m.sender];
        const questRanks = {
            qf: { rank: 'F', health: 50, monster: ['Goblin', 'Slime', 'Wild Boar'] },
            qe: { rank: 'E', health: 100, monster: ['Orc', 'Wolf', 'Skeleton'] },
            qd: { rank: 'D', health: 200, monster: ['Troll', 'Ghoul', 'Bandit'] },
            qcc: { rank: 'C', health: 300, monster: ['Minotaur', 'Wraith', 'Harpy'] },
            qb: { rank: 'B', health: 400, monster: ['Wyvern', 'Manticore', 'Ogre'] },
            qa: { rank: 'A', health: 600, monster: ['Dragon', 'Lich', 'Dark Knight'] },
            qs: { rank: 'S', health: 800, monster: ['Demon Lord', 'Beholder', 'Abyssal Serpent'] },
            'qs+': { rank: 'S+', health: 1000, monster: ['Chaos God', 'Cosmic Overlord', 'Eternal Dragon'] }
        };

        let rankData = questRanks[command];
        if (!rankData) return m.reply(`Rank quest tidak valid! Gunakan: ${Object.keys(questRanks).map(r => `.${r}`).join(', ')}`);

        // Validasi rank dan health
        if (getRankFromLevel(user.level) !== rankData.rank) return m.reply(`Levelmu tidak sesuai untuk rank ${rankData.rank}!`);
        if (user.health < rankData.health) return m.reply(`Health kurang! Minimal ${rankData.health} ❤️.`);

        // Buat room
        conn.guildQuest[m.chat] = {
            id: Math.floor(Math.random() * 1000000).toString(),
            master: m.sender,
            players: [m.sender],
            rank: rankData.rank,
            monster: pickRandom(rankData.monster),
            health: rankData.health,
            status: 'wait',
            hapus: delete conn.mabarQuest[m.chat]
        };

        room = conn.guildQuest[m.chat];
        let playerList = room.players.map((p, i) => `*${i + 1}.* @${p.replace(/@.+/, '')}`).join('\n');
        let buatRoom = `🛡️ Room dibuat!\n*Quest ID:* ${room.id}\n*Rank:* ${room.rank}\n*Monster:* ${room.monster}\n\nMenunggu pemain join!`;
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: buatRoom }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: "*© Guild Quest*" }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            title: "\t🏅 *GUILD QUEST ROOM* 🏅\n",
                            hasMediaAttachment: false
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                { name: "quick_reply", buttonParamsJson: "{\"display_text\":\"♻️ Join\",\"id\":\"quest_join\"}" },
                                { name: "quick_reply", buttonParamsJson: "{\"display_text\":\"👤 Solo\",\"id\":\"quest_solo\"}" },
                                { name: "quick_reply", buttonParamsJson: "{\"display_text\":\"🚫 Batalkan\",\"id\":\"quest_batal\"}" }
                            ]
                        })
                    })
                }
            }
        }, {});
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    }
};

handler.command = /^(qf|qe|qd|qcc|qb|qa|qs|qs\+)$/i;
handler.group = true;

function getRankFromLevel(level) {
    if (level >= 1 && level <= 19) return 'F';
    if (level >= 20 && level <= 39) return 'E';
    if (level >= 40 && level <= 59) return 'D';
    if (level >= 60 && level <= 79) return 'C';
    if (level >= 80 && level <= 99) return 'B';
    if (level >= 100 && level <= 119) return 'A';
    if (level >= 120 && level <= 139) return 'S';
    if (level >= 140) return 'S+';
    return null;
}

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)];
}

export default handler;