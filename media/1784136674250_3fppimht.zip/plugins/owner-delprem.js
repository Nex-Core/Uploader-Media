import PhoneNumber from 'awesome-phonenumber';
import { areJidsSameUser } from 'baileys';

function resolveJid(input, participants = []) {
    const found = participants.find(p =>
        areJidsSameUser(p?.id, input) ||
        areJidsSameUser(p?.lid, input) ||
        areJidsSameUser(p?.jid, input)
    );
    return found?.jid || input;
}

function no(number) {
    return number.replace(/\s/g, '').replace(/([@+-])/g, '');
}

let handler = async (m, { conn, text, participants }) => {
    if (!text && !m.quoted && !m.mentionedJid?.length) {
        return conn.reply(m.chat, `Masukkan nomor, tag, atau balas pesan target`, m);
    }

    let who;

    // Handle target
    text = no(text);

    if (m.quoted) {
        who = m.quoted.sender;
    } else if (m.mentionedJid?.length) {
        who = m.mentionedJid[0];
    } else if (text) {
        if (text.startsWith('@')) {
            who = text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        } else if (text.includes('@s.whatsapp.net') || text.includes('@lid')) {
            who = text;
        } else {
            who = text.replace(/\D/g, '') + '@s.whatsapp.net';
        }
    }

    if (m.isGroup) {
        who = resolveJid(who, participants);
    }

    if (!who) {
        return conn.reply(m.chat, `Target atau nomor tidak ditemukan, mungkin sudah keluar atau bukan anggota grup ini`, m);
    }

    let users = global.db.data.users;
    if (!users[who]) {
        return conn.reply(m.chat, `User tidak ditemukan di database`, m);
    }

    users[who].premium = false;
    users[who].premiumTime = 0;

    conn.reply(m.chat, `Berhasil menghapus status premium dari @${who.split('@')[0]}`, m, { mentions: [who] });
};

handler.help = ['delprem @tag|+phone'];
handler.tags = ['owner'];
handler.command = /^delprem(user)?$/i;
handler.owner = true;

export default handler;