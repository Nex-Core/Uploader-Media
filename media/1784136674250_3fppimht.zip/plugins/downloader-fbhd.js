import { fbDown } from '../scraper/Ar-fbDown.js';

let handler = async(m, { text, conn, usedPrefix, command }) => {
  if (!text) return m.reply(`EX: ${usedPrefix + command} https://facebook.com/xxxxx`)
  conn.sendMessage(m.chat, {
          react: {
              text: "🚀",
              key: m.key
             }
         })
  let response = await fbDown(text)
  let { vid_HD, durasi } = response
  
  if (vid_HD && durasi) {
     await conn.sendFile(m.chat, vid_HD.links, '', `Request By ${m.pushName}`, m)
      conn.sendMessage(m.chat, {
          react: {
              text: "✅",
              key: m.key
             }
         })
      } else {
       m.reply(eror)
       conn.sendMessage(m.chat, {
          react: {
              text: "❌",
              key: m.key
             }
         })
     }
};

handler.help = ['facebookhd'].map(v => v + ' <url>');
handler.tags = ['downloader'];
handler.command = /^(facebookhd|fbhd)$/i;

export default handler;