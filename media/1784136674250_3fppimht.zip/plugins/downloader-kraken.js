import axios from "axios";
import cheerio from "cheerio";

const krakens = {
   download: async (url) => {
       try {
           let { data } = await axios.get(url);
           let $ = cheerio.load(data);
           
           let videoUrl = $("video source").attr("src");
           let fileName = $(".coin-name h5").text().trim().replace(".mp4", "");
           let thumbnailUrl = $("video").attr("poster");

           if (videoUrl) {
               return {
                   fileName,
                   downloadLink: "https:" + videoUrl,
                   thumbnail: "https:" + thumbnailUrl
               };
           } else {
               return { error: "Link tidak ditemukan." };
           }
       } catch (error) {
           return { error: error.message };
       }
   }
};

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `*🚩 Contoh:* ${usedPrefix}${command} https://krakenfiles.com/view/neTIvR1wIz/file.html`;
    
    await m.reply("🔍 Sedang mengambil data...");

    let result = await krakens.download(text);

    if (result.error) {
        return m.reply(`❌ Error: ${result.error}`);
    }

    let msg = `乂 *K R A K E N  D O W N L O A D E R*\n\n`;
    msg += ` ◦ *📁 Nama:* ${result.fileName}\n`;
    msg += ` ◦ *📥 Download Link:* ${result.downloadLink}`;

    await conn.sendFile(m.chat, result.thumbnail, 'thumbnail.jpg', msg, m);
    await conn.sendMessage(m.chat, { document: { url: result.downloadLink }, fileName: result.fileName + ".mp4", mimetype: "video/mp4" }, { quoted: m });
};

handler.help = ['krakendl'].map(v => v + ' <url>');
handler.tags = ['downloader'];
handler.command = /^(krakendl|krakendownload|kraken)$/i;
handler.limit = true;
handler.register = false;
handler.premium = false;

export default handler;