import axios from "axios";

const sent = new Set();

let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0])
    return m.reply(`• EX:\n${usedPrefix + command} https://open.spotify.com/track/xxxxxx`);

  const spotifyUrl = args[0];
  if (sent.has(m.key.id)) return;
  sent.add(m.key.id);

  try {
    const result = await getSpotifyDownloadUrl(spotifyUrl);

    if (!result.success) throw new Error(result.error || "Failed to fetch track info.");

    await conn.sendMessage(m.chat, {
      audio: { url: result.downloadUrl },
      mimetype: "audio/mpeg",
      fileName: `${result.title}.mp3`,
      contextInfo: {
        externalAdReply: {
          title: result.title,
          body: `${result.author} | ${result.duration}`,
          thumbnailUrl: result.thumbnail,
          mediaType: 2,
          mediaUrl: spotifyUrl,
          sourceUrl: spotifyUrl,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: floc });

  } catch (e) {
    m.reply(`✖ Error: ${e.message}`);
  }

  setTimeout(() => sent.delete(m.key.id), 30000);
};

handler.help = ["spotifydl"].map(v => v + " <url>");
handler.tags = ["downloader"];
handler.command = /^(spotifydl|spotidl)$/i;
handler.limit = 2;
handler.register = true;

export default handler;

async function getNonce() {
  try {
    const response = await axios.get("https://spotify.downloaderize.com/es/", {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36",
        "Accept":
          "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5"
      }
    });

    const html = response.data;
    const nonceMatch = html.match(
      /spotifyDownloader\s*=\s*\{[^}]*"nonce"\s*:\s*"([a-f0-9]+)"/i
    );

    if (nonceMatch && nonceMatch[1]) {
      return nonceMatch[1];
    }

    throw new Error("Nonce not found in HTML");
  } catch (error) {
    throw new Error("Failed to get nonce: " + error.message);
  }
}

async function getSpotifyDownloadUrl(spotifyUrl) {
  try {
    const nonce = await getNonce();

    const response = await axios.post(
      "https://spotify.downloaderize.com/wp-admin/admin-ajax.php",
      new URLSearchParams({
        action: "spotify_downloader_get_info",
        url: spotifyUrl,
        nonce: nonce
      }),
      {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
          "Accept": "application/json, text/javascript, */*; q=0.01",
          "X-Requested-With": "XMLHttpRequest",
          "User-Agent":
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36",
          "Referer": "https://spotify.downloaderize.com/es/",
          "Origin": "https://spotify.downloaderize.com"
        }
      }
    );

    if (response.data.success) {
      const data = response.data.data;
      return {
        success: true,
        title: data.title,
        author: data.author,
        duration: data.duration,
        thumbnail: data.thumbnail,
        downloadUrl: data.medias[0].url,
        quality: data.medias[0].quality,
        extension: data.medias[0].extension
      };
    } else {
      return { success: false, error: "Failed to get track info" };
    }
  } catch (error) {
    return { success: false, error: error.message };
  }
}