import axios from 'axios'
import moment from 'moment-timezone'

let handler = async (m, { conn, usedPrefix, text, command }) => {
  let inputText = text?.trim()
  if (!inputText) {
    return conn.reply(
      m.chat,
      `Format:\n${usedPrefix + command} <teks kamu>\nContoh:\n${usedPrefix + command} chisa cantik`,
      m
    )
  }

  try {
    let now = moment.tz('Asia/Jakarta')
    let jamSekarang = now.format('HH:mm')
    let baterai = '100'
    let provider = 'INDOSAT'

    let url = `https://api.nexray.eu.cc/maker/v1/iqc?text=${encodeURIComponent(
      inputText
    )}&provider=${provider}&jam=${encodeURIComponent(jamSekarang)}&baterai=${baterai}`

    let { data } = await axios.get(url, {
      responseType: 'arraybuffer'
    })

    await conn.sendFile(
      m.chat,
      data,
      'iqc.jpg',
      `⋆｡˚☁︎˚｡⋆\nFake Chat iPhone (NexRay API)\n> Provider: ${provider}\n> Jam: ${jamSekarang} WIB`,
      floc
    )
  } catch (err) {
    console.error(err)
    conn.reply(
      m.chat,
      `✿ Gagal membuat Fake Chat. Pastikan API sedang online ya! ⋆｡˚☽˚｡⋆`,
      floc
    )
  }
}

handler.help = ['iqc'].map(v => v + ' <teks>')
handler.tags = ['maker']
handler.command = ['iqc']
handler.limit = 5
handler.register = true

export default handler