function formateris(eris) {
  const suffixes = ['', 'Ribu', 'Juta', 'Miliar', 'Triliun', 'Quadriliun', 'Kuantiliun', 'Sekstiliun', 'Septiliun', 'Oktiliun', 'Noniliun', 'Desiliun', 'Undeciliun', 'Duodeciliun', 'Tredesiliun', 'Quindesiliun', 'Sexdesiliun', 'Septendesiliun', 'Octodesiliun', 'Novemdesiliun', 'Vigintiliun'];
  
  let suffixIndex = 0;
  let scale = eris;

  // Tentukan skala dan satuan berdasarkan logaritma 10 dari angka
  while (scale >= 1000 && suffixIndex < suffixes.length - 1) {
    scale /= 1000;
    suffixIndex++;
  }

  // Format angka dengan dua desimal dan tambahkan satuan yang sesuai
  return scale.toFixed(2).replace(/\.00$/, '') + ' ' + suffixes[suffixIndex];
}

let handler = async (m, { conn, participants }) => {
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });

  let eris = Object.entries(global.db.data.users).sort((a, b) => b[1].eris - a[1].eris);
  let getUser = eris.map(v => v[0]);
  let show = Math.min(10, eris.length);
  let rankeris = eris.map(([user, data]) => user);

  let teks = `[ 🌐 ] *T O P - G L O B A L*\n`;
  teks += `[ 🏆 ] *You:* *${rankeris.indexOf(m.sender) + 1}* of *${getUser.length}*\n\n`;

  teks += eris
    .slice(0, show)
    .map(([user, data], i) => 
      (i + 1) + '. @' + user.split`@`[0] + '\n' +
      '   ◦ *Money* : *' + formateris(data.eris) + '*\n' +  // Menampilkan angka dengan format satuan
      '   ◦ *Level* : *' + data.level + '*'
    )
    .join('\n');
  
  teks += `\n\n©Nishikigi Chisato By Rain..`;
  m.reply(teks);
};

handler.command = ["topglobal"];
handler.tags = ["main"];
handler.help = ["topglobal"];
handler.register = true;

export default handler;