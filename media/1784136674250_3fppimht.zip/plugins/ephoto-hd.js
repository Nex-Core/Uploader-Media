import axios from 'axios';
import FormData from 'form-data';

const handler = async (m, { conn, usedPrefix, command }) => {
  let user = global.db.data.users[m.sender];
  if (!user.hdUses) user.hdUses = 0;
  if (!user.lastReset2) user.lastReset2 = 0;

  let now = Date.now();
  if (!user.premium && now - user.lastReset2 > 5 * 60 * 60 * 1000) {
    user.hdUses = 0;
    user.lastReset2 = now;
  }

  if (!user.premium && user.hdUses >= 10) {
    return m.reply(`*Limit HD kamu sudah habis (${user.hdUses}/10).* Kamu bisa menunggu 5 jam untuk menggunakan lagi atau upgrade ke premium untuk akses tak terbatas.\n\nGunakan perintah:\n${usedPrefix}premium`);
  }

  switch (command) {
    case "hd":
    case "hdr":
      {
        conn.hdr = conn.hdr || {};
        if (m.sender in conn.hdr)
          throw "Masih ada proses yang belum selesai, silakan tunggu sampai selesai!";

        let q = m.quoted ? m.quoted : m;
        let mime = (q.msg || q).mimetype || q.mediaType || '';
        if (!mime) throw `Fotonya mana?`;
        if (!/image\/(jpe?g|png)/.test(mime)) throw `Format ${mime} tidak didukung!`;

        let method = 1;

        conn.hdr[m.sender] = true;
        m.reply("Proses Kak...");

        let error;
        try {
          let img = await q.download?.();
          let enhancedImg = await ihancer(img, { method, size: 'high' });

          let limitInfo = user.premium ? "Unlimited" : `${user.hdUses + 1}/10`;
          const caption = `
✨ *Gambar Berhasil Diperbaiki!* ✨
📷 _Gambar telah ditingkatkan menggunakan teknologi AI HD._
⬆️ *Sebelum:* Kualitas rendah
⬇️ *Sesudah:* Kualitas HD

💡 *Nikmati peningkatan kualitas gambar!* 💡
🔄 *Penggunaan HD:* ${limitInfo}

> Untuk hasil lebih baik, gunakan fitur "remini" atau "upscale"
`.trim();

          await conn.sendMessage(m.chat, {
            image: enhancedImg,
            caption
          }, { quoted: floc });

          if (!user.premium) user.hdUses += 1;

          await conn.sendMessage(m.chat, {
            react: { text: '✅', key: m.key }
          });

        } catch (er) {
          error = true;
          throw er;
        } finally {
          if (error) m.reply("Proses gagal :(");
          delete conn.hdr[m.sender];
        }
      }
      break;
  }
};

handler.help = ['hd'].map(v => v + ' <reply image>')
handler.tags = ["ephoto"];
handler.command = /^(hd|hdr)$/i;
handler.register = true;

export default handler;

async function ihancer(buffer, { method = 1, size = 'low' } = {}) {
  try {
    const _size = ['low', 'medium', 'high'];
    
    if (!buffer || !Buffer.isBuffer(buffer)) throw new Error('Image buffer is required');
    if (method < 1 || method > 4) throw new Error('Available methods: 1, 2, 3, 4');
    if (!_size.includes(size)) throw new Error(`Available sizes: ${_size.join(', ')}`);
    
    const form = new FormData();
    form.append('method', method.toString());
    form.append('is_pro_version', 'false');
    form.append('is_enhancing_more', 'false');
    form.append('max_image_size', size);
    form.append('file', buffer, `rynn_${Date.now()}.jpg`);
    const { data } = await axios.post('https://ihancer.com/api/enhance', form, {
      headers: {
        ...form.getHeaders(),
        'accept-encoding': 'gzip',
        host: 'ihancer.com',
        'user-agent': 'Dart/3.5 (dart:io)'
      },
      responseType: 'arraybuffer'
    });
    
    return Buffer.from(data);
  } catch (error) {
    throw new Error(error.message);
  }
}