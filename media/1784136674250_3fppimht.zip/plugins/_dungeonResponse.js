const { proto, generateWAMessageFromContent } = (await import('baileys')).default;

let handler = async (m, { conn, command }) => {
    let ruang = conn.mabar[m.chat];
    conn.dungeon = conn.dungeon || {};
    let room = conn.dungeon[m.chat];

    if (ruang && ruang.state === 'pilihserver' && m.sender === ruang.master) {
        let user = global.db.data.users[m.sender];
        let monsters = {
            easy: ['Goblin', 'Giant Rat', 'Skeleton', 'Zombie', 'Slime'],
            normal: ['Orc', 'Hobgoblin', 'Wraith', 'Ghoul', 'Dire Wolf'],
            hard: ['Troll', 'Manticore', 'Wyvern', 'Wight', 'Minotaur'],
            extreme: ['Lich', 'Hydra', 'Beholder', 'Fire Giant', 'Frost Giant'],
            bos: ['Dragon', 'Demon Lord', 'Dark Knight', 'Chaos Beast', 'Ancient Golem'],
            abyss: ['Abyssal Serpent', 'Void Wraith', 'Shadow Dragon', 'Nether Fiend', 'Eldritch Horror'],
            king: ['King of Beasts', 'Storm Titan', 'Celestial Guardian', 'Iron Monarch', 'Sky Emperor'],
            emperor: ['Emperor of Flame', 'Void King', 'Star Devourer', 'Eclipse Lord', 'Abyssal Tyrant'],
            demigod: ['Demigod of War', 'Celestial Judge', 'Eternal Warden', 'Divine Reaper', 'Astral Sovereign'],
            god: ['God of Destruction', 'Primordial Deity', 'Cosmic Overlord', 'Eternal Creator', 'Chaos God']
        };

        const levels = {
            easy: { level: 10, armor: 1, sword: 1, health: 90, adura: 99, sdura: 99, armorName: 'Leather Armor', swordName: 'Wooden Sword' },
            normal: { level: 20, armor: 2, sword: 2, health: 150, adura: 99, sdura: 99, armorName: 'Iron Armor', swordName: 'Iron Sword' },
            hard: { level: 30, armor: 3, sword: 3, health: 300, adura: 99, sdura: 99, armorName: 'Gold Armor', swordName: 'Gold Sword' },
            extreme: { level: 40, armor: 4, sword: 4, health: 350, adura: 99, sdura: 99, armorName: 'Diamond Armor', swordName: 'Diamond Sword' },
            bos: { level: 100, armor: 5, sword: 5, health: 600, adura: 99, sdura: 99, armorName: 'Netherite Armor', swordName: 'Netherite Sword' },
            abyss: { level: 150, armor: 6, sword: 6, health: 800, adura: 99, sdura: 99, armorName: 'Dragonplate Armor', swordName: 'Shadowbane Sword' },
            king: { level: 180, armor: 7, sword: 7, health: 1000, adura: 99, sdura: 99, armorName: 'Celestial Armor', swordName: 'Stormbringer Sword' },
            emperor: { level: 250, armor: 8, sword: 8, health: 1200, adura: 99, sdura: 99, armorName: 'Stormbringer Armor', swordName: 'Excalibur Sword' },
            demigod: { level: 500, armor: 8, sword: 8, health: 1300, adura: 99, sdura: 99, armorName: 'Stormbringer Armor', swordName: 'Excalibur Sword' },
            god: { level: 1000, armor: 8, sword: 8, health: 1400, adura: 99, sdura: 99, armorName: 'Stormbringer Armor', swordName: 'Excalibur Sword' }
        };

        let levelData = levels[command];
        if (!levelData) return m.reply('Server tidak valid!');

        // Validasi persyaratan
        if (user.level < levelData.level) return m.reply(`Kamu membutuhkan *Level ${levelData.level}* untuk bermain di server *${command}*!`);
        if (user.armor < levelData.armor) return m.reply(`Kamu membutuhkan *${levelData.armorName}* untuk bermain di server *${command}*!`);
        if (user.sword < levelData.sword) return m.reply(`Kamu membutuhkan *${levelData.swordName}* untuk bermain di server *${command}*!`);
        if (user.health < levelData.health) return m.reply(`Health kamu kurang dari *${levelData.health} ❤️*!`);
        if (user.armordurability < levelData.adura) return m.reply(`Durability armor kamu kurang dari *${levelData.adura} 🛡️*!`);
        if (user.sworddurability < levelData.sdura) return m.reply(`Durability sword kamu kurang dari *${levelData.sdura} 🛡️*!`);

        // Buat room
        conn.dungeon[m.chat] = {
            id: Math.floor(Math.random() * 100000000).toString(),
            p: m.sender,
            players: [m.sender],
            nameserver: command,
            armor: levelData.armorName,
            sword: levelData.swordName,
            cdserver: 1800000,
            armorserver: levelData.armor,
            swordserver: levelData.sword,
            adura: levelData.adura,
            sdura: levelData.sdura,
            monster: pickRandom(monsters[command]),
            healtserver: levelData.health,
            hapus: delete conn.mabar[m.chat],
            status: 'wait'
        };

        room = conn.dungeon[m.chat];
        let playerList = room.players.map((player, index) => `*${index + 1}.* @${player.replace(/@.+/, '')}`).join('\n');
        let buatRoom = `🔱 Berhasil membuat room\n*Room ID:* ${room.id}\n*Server:* ${command.charAt(0).toUpperCase() + command.slice(1)}\n\n♻️ Menunggu pemain lain untuk join`;
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: buatRoom,
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: "*© Nishi chisato*"
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            title: "\t🏅 *DUNGEON ROOM* 🏅\n",
                            subtitle: "",
                            hasMediaAttachment: false
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: "{\"display_text\":\"♻️ Join\",\"id\":\"join dungeon\"}"
                                },
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: "{\"display_text\":\"👤 Solo\",\"id\":\"dewekan\"}"
                                },
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: "{\"display_text\":\"🚫 Batalkan\",\"id\":\"batall\"}"
                                },
                            ],
                        })
                    })
                },
            }
        }, {});
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    }
};

handler.command = /^(easy|normal|hard|extreme|bos|abyss|king|emperor|demigod|god)$/i;
handler.group = true;

export default handler;

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)];
}