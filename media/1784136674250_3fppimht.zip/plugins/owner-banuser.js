let handler = async (m, { conn, text }) => {
    if (!text) throw 'Masukkan nomor atau tag orang yang ingin diban!'
    
    let who
    if (m.isGroup && m.mentionedJid.length > 0) {
        who = m.mentionedJid[0]
    } else if (/^\d{5,20}$/.test(text)) {
        who = text.replace(/\D/g, '') + '@s.whatsapp.net'
    } else if (text.includes('@s.whatsapp.net')) {
        who = text
    } else {
        throw 'Format tidak valid! Gunakan tag atau masukkan nomor (tanpa + atau spasi).'
    }

    let users = global.db.data.users
    if (!users[who]) throw 'User tidak ditemukan dalam database!'

    users[who].banned = true
    conn.reply(m.chat, `Berhasil banned user: ${who.split('@')[0]}`, m)
}

handler.help = ['ban']
handler.tags = ['owner']
handler.command = /^ban(user)?$/i
handler.rowner = true

export default handler