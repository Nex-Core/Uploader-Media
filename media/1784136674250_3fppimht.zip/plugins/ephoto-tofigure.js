import axios from "axios";
import uploadImage from "../lib/uploadImage.js";

const handler = async (m, { conn, usedPrefix, command }) => {
  let user = global.db?.data?.users?.[m.sender] || {};
  if (!user.figureUses) user.figureUses = 0;
  if (!user.lastFigureReset) user.lastFigureReset = 0;

  let now = Date.now();
  if (!user.premium && now - user.lastFigureReset > 10 * 60 * 60 * 1000) {
    user.figureUses = 0;
    user.lastFigureReset = now;
  }

  if (!user.premium && user.figureUses >= 3) {
    return m.reply(
      `*Limit Figurine habis* (${user.figureUses}/3)\n` +
      `Tunggu 10 jam untuk reset atau upgrade ke premium biar unlimited.\n\n` +
      `> Ketik: ${usedPrefix}premium`
    );
  }

  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  if (!mime) throw `Kirim/Reply gambar dengan caption *${usedPrefix + command}*`;
  if (!/image\/(jpe?g|png)/.test(mime)) throw `Mime ${mime} tidak support`;

  const react = { react: { text: "🍁", key: m.key } };
  const reactdone = { react: { text: "🌸", key: m.key } };

  try {
    await conn.sendMessage(m.chat, react);

    const img = await q.download();
    const imageUrl = await uploadImage(img);

    const prompt = `a commercial 1/7 scale figurine of the character in the picture was created, depicting a realistic style and a realistic environment. The figurine is placed on a computer desk with a round transparent acrylic base. There is no text on the base. The computer screen shows the Zbrush modeling process of the figurine. Next to the computer screen is a BANDAI-style toy box with the original painting printed on it.`;

    const api = new NanoBananaAPI();
    const result = await api.generate(imageUrl, prompt, {
      styleId: 'realistic',
      numImages: 1,
      outputFormat: 'png'
    });

    const imageResponse = await axios.get(result.imageUrl, {
      responseType: 'arraybuffer'
    });

    if (!imageResponse.data) {
      throw new Error("Gagal mendapatkan hasil dari API");
    }

    let limitInfo = user.premium ? "Unlimited" : `${user.figureUses + 1}/3`;
    await conn.sendMessage(
      m.chat,
      {
        image: Buffer.from(imageResponse.data),
        caption: `✨ *Figurine berhasil dibuat!*\n\n🔄 *Penggunaan Figurine:* ${limitInfo}\n\n> Powered by NanoBanana AI`,
        mentions: [m.sender],
      },
      { quoted: floc }
    );

    if (!user.premium) user.figureUses += 1;

  } catch (e) {
    let reason = e?.response?.data?.error || 
                 e?.response?.data?.message || 
                 e?.message || 
                 e.toString();
    await conn.sendMessage(
      m.chat, 
      { text: `Error saat membuat figurine:\n\n${reason}` }, 
      { quoted: floc }
    );
  } finally {
    await conn.sendMessage(m.chat, reactdone);
  }
};

handler.command = /^(tofigure|figurine)$/i;
handler.help = ["tofigure"].map((a) => a + " <reply image>");
handler.tags = ["ephoto"];
handler.register = true;
handler.limit = false;

export default handler;

class NanoBananaAPI {
  constructor() {
    this.baseURL = 'https://imgeditor.co/api';
  }

  async generateImage(prompt, imageUrl, options = {}) {
    const payload = {
      prompt,
      styleId: options.styleId,
      mode: options.mode,
      imageUrl,
      imageUrls: [imageUrl],
      numImages: options.numImages,
      outputFormat: options.outputFormat,
      model: 'nano-banana'
    };

    const response = await axios.post(`${this.baseURL}/generate-image`, payload, {
      headers: { 'Content-Type': 'application/json' }
    });

    return response.data;
  }

  async checkStatus(taskId) {
    const response = await axios.get(`${this.baseURL}/generate-image/status`, {
      params: { taskId }
    });

    return response.data;
  }

  async waitForCompletion(taskId, maxWaitTime = 300000) {
    const startTime = Date.now();
    
    while (Date.now() - startTime < maxWaitTime) {
      const status = await this.checkStatus(taskId);
      
      if (status.status === 'completed') {
        return status;
      }

      if (status.status === 'failed') {
        throw new Error('Image generation failed');
      }

      await new Promise(resolve => setTimeout(resolve, 5000));
    }

    throw new Error('Timeout waiting for image generation');
  }

  async generate(imageUrl, prompt, options = {}) {
    const generateData = await this.generateImage(prompt, imageUrl, options);
    const result = await this.waitForCompletion(generateData.taskId);
    
    return {
      imageUrl: result.imageUrl,
      taskId: result.taskId
    };
  }
}