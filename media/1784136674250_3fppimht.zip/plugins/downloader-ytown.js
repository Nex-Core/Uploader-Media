import axios from 'axios'

const sent = new Set()

let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) return m.reply(`EX:\n${usedPrefix + command} https://youtu.be/xxxxxxx`)

  const url = args[0]
  const ytId = url.match(/(?:youtube\.com\/(?:watch\?v=|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/)?.[1]
  if (!ytId) return m.reply('Link YouTube tidak valid')

  if (sent.has(m.key.id)) return
  sent.add(m.key.id)

  await conn.sendMessage(m.chat, { react: { text: '☆', key: m.key } })

  try {
    const downloader = new YTDownloader()
    const video = await downloader.download(url)

    await conn.sendMessage(m.chat, {
      video: { url: video.downloadUrl },
      mimetype: 'video/mp4',
      fileName: `${video.title}.mp4`,
      caption: `${video.title}`
    }, { quoted: floc })

    await conn.sendMessage(m.chat, { react: { text: '✓', key: m.key } })

  } catch (e) {
    await conn.sendMessage(m.chat, { react: { text: '✗', key: m.key } })
    m.reply(`Upss... terjadi kesalahan\n> ${e.message || e}`)
  }

  setTimeout(() => sent.delete(m.key.id), 30000)
}

handler.command = /^ytown$/i

export default handler


class YTDownloader {
  constructor() {
    this.client = axios.create({
      baseURL: 'https://app.ytdown.to',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Referer': 'https://ytdown.to/',
        'Origin': 'https://ytdown.to',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    })
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms))
  }

  async checkCooldown() {
    const { data } = await this.client.post('/cooldown.php', 'action=check', {
      headers: { Accept: 'application/json, text/javascript, */*; q=0.01' }
    })
    return data
  }

  async recordDownload() {
    await this.client.post('/cooldown.php', 'action=record', {
      headers: { Accept: 'application/json, text/javascript, */*; q=0.01' }
    })
  }

  async getVideoInfo(youtubeUrl) {
    const { data } = await this.client.post('/proxy.php', `url=${encodeURIComponent(youtubeUrl)}`, {
      headers: { Accept: '*/*' }
    })
    return data
  }

  async pollUntilDone(mediaUrl) {
    for (let i = 0; i < 60; i++) {
      await this.sleep(3000)
      const { data } = await this.client.post('/proxy.php', `url=${encodeURIComponent(mediaUrl)}`, {
        headers: { Accept: '*/*' }
      })
      if (data.api?.status === 'completed') return data.api
    }
    throw new Error('Timeout menunggu proses download')
  }

  async download(youtubeUrl, retries = 3) {
    for (let attempt = 1; attempt <= retries; attempt++) {
      try {
        const cooldown = await this.checkCooldown()
        if (!cooldown.can_download) {
          await this.sleep((cooldown.remaining_time || 5) * 1000)
          continue
        }

        const proxyRes = await this.getVideoInfo(youtubeUrl)
        const api = proxyRes.api
        if (api?.status !== 'ok' || !api.mediaItems) throw new Error('Gagal mendapatkan info video')

        const media =
          api.mediaItems.find(item => item.type === 'Video' && item.mediaQuality === 'FHD') ||
          api.mediaItems.find(item => item.type === 'Video' && item.mediaQuality === 'HD')

        if (!media) throw new Error('Resolusi 1080p/720p tidak tersedia')

        await this.recordDownload()

        await this.client.post('/proxy.php', `url=${encodeURIComponent(media.mediaUrl)}`, {
          headers: { Accept: '*/*' }
        })

        const result = await this.pollUntilDone(media.mediaUrl)

        return {
          title: api.title,
          downloadUrl: result.fileUrl
        }

      } catch (e) {
        if (attempt < retries) {
          await this.sleep(Math.pow(2, attempt) * 3000)
          continue
        }
        throw e
      }
    }
  }
}