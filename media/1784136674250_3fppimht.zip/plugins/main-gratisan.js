const user = 500
const limit = 50
const eris = 20000000

let handler = async (m, { conn }) => {
    let userDB = global.db.data.users[m.sender]

    // Cek apakah pengguna adalah premium
    if (!userDB.premium) {
        throw `suki diam !!`
    }

    let now = new Date().getTime()
    let cooldown = 600000 // 10 menit dalam milidetik (600000 ms)

    if (now - userDB.udahklaim < cooldown) {
        let sisaWaktu = msToTime(userDB.udahklaim + cooldown - now)
        throw `Kamu sudah klaim hari ini!\nSilakan tunggu ${sisaWaktu} lagi sebelum klaim ulang.`
    }

    // Tambahkan Eris dan Limit ke pengguna
    userDB.eris += eris
    userDB.limit += limit
    userDB.udahklaim = now

    // Format angka agar lebih mudah dibaca
    let erisFormatted = eris.toLocaleString("id-ID")
    let limitFormatted = limit.toLocaleString("id-ID")

    // Kirim pesan balasan
    conn.reply(m.chat, `🎁 *Bonus Premium dari Owner!* 🎁\n\nKamu mendapatkan:\n+ ${limitFormatted} Limit\n+ ${erisFormatted} Money 💰\n\nTerima kasih telah menjadi pengguna *Premium*!`, m)
}

handler.customPrefix = /^(ar minta duit|ar bagi duit)$/i
handler.command = new RegExp()

export default handler

// Fungsi untuk mengubah milidetik ke format waktu yang lebih mudah dibaca
function msToTime(duration) {
    let seconds = Math.floor((duration / 1000) % 60),
        minutes = Math.floor((duration / (1000 * 60)) % 60),
        hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

    let result = []
    if (hours > 0) result.push(`${hours} Jam`)
    if (minutes > 0) result.push(`${minutes} Menit`)
    if (seconds > 0) result.push(`${seconds} Detik`)

    return result.join(" ")
}