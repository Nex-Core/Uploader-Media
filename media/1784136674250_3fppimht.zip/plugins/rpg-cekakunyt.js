let handler = async (m, { conn, command, args, usedPrefix }) => {
    let user = global.db.data.users[m.sender];
    const tag = '@' + m.sender.split`@`[0];
    let playButton = user.playButton;

    // Gunakan fungsi custom formatNumber untuk format angka
    const formattedSubscribers = formatNumber(user.subscribers);
    const formattedViewers = formatNumber(user.viewers);
    const formattedLike = formatNumber(user.like);

    try {
        if (command === 'akunyt') {
            if (!user.youtube_account) {
                return conn.reply(m.chat, `Hey Kamu Iya Kamu ${tag} Buat akun terlebih dahulu\nKetik: .createakun`, floc);
            } else {
                return conn.reply(m.chat, `*🎧 YOUTUBE STUDIO 🎧*\n
*• 👤 Pemilik:* ${user.registered ? tag : conn.getName(m.sender)}
*• 🏷️ Nama:* ${m.pushName}
*• 🌐 Channel:* ${user.youtube_account}
*• 👥 Subscribers:* ${formattedSubscribers}
*• 👍🏻 Total Like:* ${formattedLike}
*• 🪬 Total Viewers:* ${formattedViewers}

*• ⬜ Silver PlayButton:* ${playButton < 1 ? '❌' : '✅'}
*• 🟧 Gold PlayButton:* ${playButton < 2 ? '❌' : '✅'}
*• 💎 Diamond PlayButton:* ${playButton < 3 ? '❌' : '✅'}`, floc);
            }
        } else if (/live/i.test(command) && args[0] === 'youtuber') {
            // Periksa apakah pengguna memiliki akun YouTube
            if (!user.youtube_account) {
                return conn.reply(m.chat, `Hey Kamu Iya Kamu ${tag} Buat akun terlebih dahulu\nKetik: .createakun`, floc);
            }

            // Kode yang sudah ada untuk perintah 'live youtuber'
            // ...
        } else {
            return await m.reply("Perintah tidak dikenali.\n*.akunyt*\n> ᴜɴᴛᴜᴋ ᴍᴇɴɢᴇᴄᴇᴋ ᴀᴋᴜɴ ʏᴏᴜᴛᴜʙᴇ ᴀɴᴅᴀ\n*.live [judul live]*\n> ᴜɴᴛᴜᴋ ᴍᴇᴀᴋᴛɪᴠɪᴛᴀs ʟɪᴠᴇ sᴛʀᴇᴀᴍɪɴɢ.");
        }
    } catch (err) {
        m.reply("Error\n\n\n" + err.stack);
    }
};

// Fungsi untuk format angka besar (misalnya 1k, 10.0k, 100.0k, 1M, 10.0M, 100.0M, 1B, 10.0B)
function formatNumber(num) {
    if (num >= 1e9) return (num / 1e9).toFixed(1).replace(/\.0$/, '') + 'milliar'; // 1B, 10.0B, 100.0B
    if (num >= 1e6) return (num / 1e6).toFixed(1).replace(/\.0$/, '') + 'juta'; // 1M, 10.0M, 100.0M
    if (num >= 1e3) return (num / 1e3).toFixed(1).replace(/\.0$/, '') + 'ribu'; // 1k, 10.0k, 100.0k
    return num.toString(); // Jika angka kurang dari 1.000, tampilkan apa adanya
}

// Menentukan help, tags, command, dan registrasi untuk handler perintah RPG
handler.help = ['akunyt'];
handler.tags = ['rpg'];
handler.command = /^(akunyt)$/i;
handler.register = true;
handler.group = true;

// Ekspor handler untuk perintah RPG
export default handler;