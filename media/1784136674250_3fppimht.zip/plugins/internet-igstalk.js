import axios from "axios";
import * as cheerio from "cheerio";

let handler = async (m, { text, conn, usedPrefix, command }) => {
  if (!text) throw `✧ Contoh: ${usedPrefix + command} arul_hx`;

  await conn.sendMessage(m.chat, { react: { text: "🌸", key: m.key } });

  try {
    const profileData = await stalkInstaStories(text);

    if (!profileData) throw "❌ Akun tidak ditemukan atau terjadi kesalahan.";

    const caption = `
╰╼ ┈─ ⠁◌ ˚Instagram Profile ⠹ !

⤿ Nama ⠲ ${profileData.full_name || "-"}
⤿ Username ⠲ @${profileData.username || "-"}
⤿ Bio ⠲ ${profileData.bio || "-"}
⤿ Postingan ⠲ ${profileData.posts || 0}
⤿ Followers ⠲ ${profileData.followers || 0}
⤿ Following ⠲ ${profileData.following || 0}
⤿ Link ⠲ instagram.com/${profileData.username || "-"}
`.trim();

    await conn.sendMessage(
      m.chat,
      { text: caption },
      { quoted: m }
    );

  } catch (err) {
    console.error(err);
    throw "❗ Gagal mengambil data, coba lagi nanti atau pastikan username benar.";
  }
};

handler.help = ["igstalk <username>"];
handler.tags = ["internet"];
handler.command = /^(igstalk)$/i;
handler.register = true;
handler.limit = true;

export default handler;

async function stalkInstaStories(username) {
  try {
    const url = `https://insta-stories-viewer.com/${username}/`;
    const { data } = await axios.get(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
        "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
      }
    });

    const $ = cheerio.load(data);

    return {
      username: username,
      full_name: $(".profile__nickname").text().replace("(Anonymous profile view)", "").trim(),
      bio: $(".profile__description").text().trim(),
      posts: $(".profile__stats-posts").text().trim(),
      followers: $(".profile__stats-followers").text().trim(),
      following: $(".profile__stats-follows").text().trim()
    };

  } catch {
    return null;
  }
}