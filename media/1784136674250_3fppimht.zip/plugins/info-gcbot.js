let handler = async (m, { conn, text, command }) =>  
conn.reply(m.chat, `Join Grup Kami Untuk Mendapatkan Info Tentang Bot, Kalau Seakan-akan terkena banned.

Link Grup:   https://chat.whatsapp.com/HIHtBjtNx8n5ebeHvCfonH

Link Grup 2:   https://chat.whatsapp.com/L1h1Lcfn5W9LNbHP4Ql5Of

...`, floc)

handler.help = ['gcbot']
handler.tags = ['info']
handler.command = /^(gcchii|groupbot|grupbot|botgc|botgroup|botgrup|gc\sbot)$/i
export default handler