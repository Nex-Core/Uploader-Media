import { prepareWAMessageMedia } from 'baileys'

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text && !m.quoted) return m.reply(`EX: ${usedPrefix + command} <teks>\natau reply foto/video/audio`)

    try {
        if (text) {
            await conn.relayMessage(m.chat, {
                groupStatusMessageV2: {
                    message: { conversation: text }
                }
            }, {})
            return m.reply("Done")
        }

        if (m.quoted) {
            let mime = m.quoted.mimetype || ''
            let buffer = await m.quoted.download()

            if (!buffer) return m.reply("tidak ada media yg bisa di upload")

            let caption = m.quoted.text || ''
            let media
            if (/image/.test(mime)) {
                media = await prepareWAMessageMedia({
                    image: buffer,
                    caption
                }, { upload: conn.waUploadToServer })
            } else if (/video/.test(mime)) {
                media = await prepareWAMessageMedia({
                    video: buffer,
                    caption
                }, { upload: conn.waUploadToServer })
            } else if (/audio/.test(mime)) {
                media = await prepareWAMessageMedia({
                    audio: buffer,
                    mimetype: 'audio/mpeg',
                    ptt: false
                }, { upload: conn.waUploadToServer })
            } else {
                return m.reply("format media tidak didukung")
            }

            await conn.relayMessage(m.chat, {
                groupStatusMessageV2: {
                    message: media
                }
            }, {})
            return m.reply("Done")
        }
    } catch (e) {
        console.error(e)
        m.reply("gagal upload status")
    }
}

handler.command = /^swgc$/i
handler.owner = true
handler.help = ["swgc"]
handler.tags = ["owner"]

export default handler