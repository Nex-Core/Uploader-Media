const { proto, generateWAMessageFromContent } = (await import('baileys')).default;

let handler = async (m, { conn, command }) => {
    let ruang = conn.mabar_onimusha[m.chat];
    conn.onimusha = conn.onimusha || {};
    let room = conn.onimusha[m.chat];

    if (ruang && ruang.state === 'pilihserver' && m.sender === ruang.master) {
        let user = global.db.data.users[m.sender];
        let enemies = {
            inabayama: ['Genma Soldier', 'Genma Archer', 'Demon Hound', 'Shadow Ninja', 'Oni Beetle'],
            mino: ['Genma Samurai', 'Fire Demon', 'Oni Archer', 'Demon Wolf', 'Poison Genma'],
            gifu: ['Genma Monk', 'Dark Samurai', 'Oni Assassin', 'Demon Rat', 'Genma Guardian'],
            azuchi: ['Genma Elite', 'Demon Swordsman', 'Oni Veteran', 'Dark Guard', 'Chained Demon'],
            demonrealm: ['Genma Warlord', 'Headless Demon', 'Oni Sorcerer', 'Dark Monk', 'Fortinbras']
        };

        const paths = {
            inabayama: { 
                level: 10, 
                health: 100, 
                stamina: 80, 
                katana: 1, 
                katanadura: 50, 
                pathName: 'Inabayama Castle', 
                katanaName: 'Fubuki' // Level 1 katana
            },
            mino: { 
                level: 20, 
                health: 150, 
                stamina: 100, 
                katana: 2, 
                katanadura: 100, 
                pathName: 'Mino Province', 
                katanaName: 'Koyuki' // Level 2 katana
            },
            gifu: { 
                level: 30, 
                health: 200, 
                stamina: 120, 
                katana: 3, 
                katanadura: 150, 
                pathName: 'Gifu Castle', 
                katanaName: 'Mizore' // Level 3 katana
            },
            azuchi: { 
                level: 40, 
                health: 250, 
                stamina: 150, 
                katana: 4, 
                katanadura: 200, 
                pathName: 'Azuchi Castle', 
                katanaName: 'Shigure' // Level 4 katana
            },
            demonrealm: { 
                level: 100, 
                health: 400, 
                stamina: 200, 
                katana: 5, 
                katanadura: 250, 
                pathName: 'Demon Realm', 
                katanaName: 'Yukikaze' // Level 5 katana
            }
        };

        let pathData = paths[command];
        if (!pathData) return m.reply('Jalur tidak valid!');

        if (user.level < pathData.level) return m.reply(`Kamu membutuhkan *Level ${pathData.level}* untuk bertarung di *${pathData.pathName}*!`);
        if (user.health < pathData.health) return m.reply(`Health kamu kurang dari *${pathData.health} ❤️*!`);
        if (user.stamina < pathData.stamina) return m.reply(`Stamina kamu kurang dari *${pathData.stamina} ⚡*!`);
        if (user.katana < pathData.katana) return m.reply(`Kamu membutuhkan *${pathData.katanaName}* untuk bertarung di *${pathData.pathName}*!`);
        if (user.katanadurability < pathData.katanadura) return m.reply(`Durability katana kamu kurang dari *${pathData.katanadura} 🗡️*!`);

        conn.onimusha[m.chat] = {
            id: Math.floor(Math.random() * 100000000).toString(),
            p: m.sender,
            players: [m.sender],
            nameserver: command,
            healtserver: pathData.health,
            staminaserver: pathData.stamina,
            katanaserver: pathData.katana,
            katanadura: pathData.katanadura,
            katanaName: pathData.katanaName,
            cdserver: 1800000,
            enemy: pickRandom(enemies[command]),
            hapus: delete conn.mabar_onimusha[m.chat],
            status: 'wait'
        };

        room = conn.onimusha[m.chat];
        let playerList = room.players.map((player, index) => `*${index + 1}.* @${player.replace(/@.+/, '')}`).join('\n');
        let buatRoom = `⚔️ Berhasil membuat room\n*Room ID:* ${room.id}\n*Path:* ${pathData.pathName}\n\n♻️ Menunggu samurai lain untuk join`;
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: buatRoom,
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: "*© Nishi chisato*"
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            title: "\t🏯 *ONIMUSHA ROOM* 🏯\n",
                            subtitle: "",
                            hasMediaAttachment: false
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: "{\"display_text\":\"♻️ Join\",\"id\":\"onimusha_join\"}"
                                },
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: "{\"display_text\":\"👤 Solo\",\"id\":\"onimusha_solo\"}"
                                },
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: "{\"display_text\":\"🚫 Batalkan\",\"id\":\"onimusha_batall\"}"
                                },
                            ],
                        })
                    })
                },
            }
        }, {});
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    }
};

handler.command = /^(inabayama|mino|gifu|azuchi|demonrealm)$/i;
handler.group = true;

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)];
}

export default handler;