import fs from 'fs';
import archiver from 'archiver';

let handler = async (m, { conn, text }) => {
  if (!text) return m.reply('✿ Mohon berikan nama file/folder yang akan diambil');

  const target = text.trim();
  const outputZip = `${target}.zip`;

  try {
    if (!fs.existsSync(target)) {
      return m.reply(`✿ File atau folder "${target}" tidak ditemukan`);
    }

    const stat = fs.statSync(target);

    if (stat.isFile() && (target.endsWith('.js') || target.endsWith('.json'))) {
      m.reply(wait);
      const output = fs.createWriteStream(outputZip);
      const archive = archiver('zip', { zlib: { level: 9 } });

      archive.pipe(output);
      archive.file(target, { name: target.split('/').pop() });
      await archive.finalize();

      output.on('close', async () => {
        const sesi = await fs.promises.readFile(outputZip);
        await conn.sendMessage(
          m.chat,
          { document: sesi, mimetype: 'application/zip', fileName: outputZip },
          { quoted: m }
        );
        fs.unlinkSync(outputZip);
      });
    } else if (stat.isDirectory()) {
      m.reply('✿ Folder terdeteksi, sedang membuat zip...');
      const output = fs.createWriteStream(outputZip);
      const archive = archiver('zip', { zlib: { level: 9 } });

      archive.pipe(output);
      archive.directory(target, false);
      await archive.finalize();

      output.on('close', async () => {
        const sesi = await fs.promises.readFile(outputZip);
        await conn.sendMessage(
          m.chat,
          { document: sesi, mimetype: 'application/zip', fileName: outputZip },
          { quoted: floc }
        );
        fs.unlinkSync(outputZip);
      });
    } else {
      m.reply('✿ Hanya mendukung folder atau file .js/.json');
    }
  } catch (error) {
    console.error(error);
    m.reply('✿ Terjadi kesalahan dalam mengambil file/folder');
  }
};

handler.help = ['getzip <file.js/file.json/folder>'];
handler.tags = ['owner'];
handler.command = /^(getzip)$/i;
handler.rowner = true;

export default handler;