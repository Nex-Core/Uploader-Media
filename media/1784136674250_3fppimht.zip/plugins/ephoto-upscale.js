import axios from "axios";
import crypto from "crypto";
import { FormData, Blob } from "formdata-node";
import { fileTypeFromBuffer } from "file-type";
import fakeUserAgent from "fake-useragent";

const handler = async (m, { conn, args, usedPrefix, command }) => {
  let user = global.db?.data?.users?.[m.sender] || {};
  if (!user.upscaleUses) user.upscaleUses = 0;
  if (!user.lastUpscaleReset) user.lastUpscaleReset = 0;

  let scale = parseInt(args[0]);
  if (!scale) throw `Contoh:\n${usedPrefix + command} 4 (reply gambar)`;
  if (scale < 1 || scale > 16) throw `Scale hanya 1 - 16`;

  let now = Date.now();

  if (!user.premium && now - user.lastUpscaleReset > 10 * 60 * 60 * 1000) {
    user.upscaleUses = 0;
    user.lastUpscaleReset = now;
  }

  if (!user.premium && scale > 5) {
    return m.reply(
      `Scale *${scale}x* hanya untuk premium.\n\n` +
      `User biasa hanya bisa scale *1-5*.\n\n` +
      `> Ketik ${usedPrefix}premium`
    );
  }

  if (!user.premium && user.upscaleUses >= 3) {
    return m.reply(
      `*Limit Upscale habis* (${user.upscaleUses}/3)\n` +
      `Tunggu 10 jam untuk reset atau upgrade premium.\n\n` +
      `> Ketik ${usedPrefix}premium`
    );
  }

  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";

  if (!mime) throw `Reply gambar dengan caption *${usedPrefix + command} ${scale}*`;
  if (!/image\/(jpe?g|png)/.test(mime)) throw `Mime ${mime} tidak support`;

  const react = { react: { text: "🔍", key: m.key } };
  const reactdone = { react: { text: "✨", key: m.key } };

  try {
    await conn.sendMessage(m.chat, react);

    const img = await q.download();
    const imageUrl = await uploadTmpfiles(img);

    const api = `https://api.nexray.web.id/tools/upscale?url=${encodeURIComponent(imageUrl)}&resolusi=${scale}`;

    const response = await axios.get(api, {
      responseType: "arraybuffer",
      headers: { "User-Agent": fakeUserAgent() }
    });

    const buffer = Buffer.from(response.data);

    let limitInfo = user.premium ? "Unlimited" : `${user.upscaleUses + 1}/3`;

    await conn.sendMessage(
      m.chat,
      {
        image: buffer,
        caption:
          `🖼️ *Upscale berhasil dibuat*\n\n` +
          `Scale: *${scale}x*\n` +
          `Penggunaan: ${limitInfo}`,
        mentions: [m.sender]
      },
      { quoted: floc }
    );

    if (!user.premium) user.upscaleUses += 1;

  } catch (e) {
    let reason = e?.response?.data?.error || e?.message || e.toString();

    await conn.sendMessage(
      m.chat,
      { text: `✦ *Error saat upscale*\n\n${reason}` },
      { quoted: floc }
    );
  } finally {
    await conn.sendMessage(m.chat, reactdone);
  }
};

handler.command = /^(upscale)$/i;
handler.help = ["upscale <1-16>"].map(v => v + " <reply image>");
handler.tags = ["ephoto"];
handler.register = true;

export default handler;

async function uploadTmpfiles(content) {
  const { ext } = (await fileTypeFromBuffer(content)) || { ext: "jpg" };

  const formData = new FormData();
  const randomBytes = crypto.randomBytes(5).toString("hex");

  formData.append(
    "file",
    new Blob([content], { type: "application/octet-stream" }),
    `${randomBytes}.${ext}`
  );

  const response = await axios.post(
    "https://tmpfiles.org/api/v1/upload",
    formData,
    { headers: { "User-Agent": fakeUserAgent() } }
  );

  const result = response.data;
  const match = /https?:\/\/tmpfiles.org\/(.*)/.exec(result.data.url);

  if (!match) throw new Error("Invalid tmpfiles URL format");

  return `https://tmpfiles.org/dl/${match[1]}`;
}