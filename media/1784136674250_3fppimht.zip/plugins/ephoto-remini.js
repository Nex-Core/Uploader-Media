import crypto from 'crypto'
import { FormData, Blob } from 'formdata-node'
import { fileTypeFromBuffer } from 'file-type'
import axios from 'axios'

let handler = async (m, { conn, usedPrefix, command }) => {
  let info = `Kirim atau reply foto dengan caption *${usedPrefix + command}*`
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''
  if (!mime) throw info
  if (!/image\/(jpe?g|png)/.test(mime)) throw `Tipe file ${mime} tidak didukung.`

  let media = await q.download()
  let imageUrl = await uploadTmpfiles(media)

  await conn.sendMessage(m.chat, { react: { text: '🌸', key: m.key } })

  try {
    let resultUrl = await reminiEnhance(imageUrl)
    if (!resultUrl) throw 'Gagal meningkatkan kualitas foto.'

    await conn.sendMessage(m.chat, {
      image: { url: resultUrl },
      caption: `❀ *Foto berhasil diperjelas (HD)* ❀`,
      mentions: [m.sender]
    }, { quoted: floc })
  } catch (e) {
    console.error(e)
    m.reply('Terjadi kesalahan saat memperjelas foto.')
  } finally {
    await conn.sendMessage(m.chat, { react: { text: '💫', key: m.key } })
  }
}

handler.command = /^remini$/i
handler.help = ['remini'].map(v => v + ' <reply image>')
handler.tags = ['ephoto']
handler.premium = true
handler.register = true

export default handler

async function uploadTmpfiles(buffer) {
  const { ext } = (await fileTypeFromBuffer(buffer)) || { ext: 'jpg' }
  const formData = new FormData()
  const name = crypto.randomBytes(6).toString('hex')

  formData.append(
    'file',
    new Blob([buffer], { type: 'application/octet-stream' }),
    `${name}.${ext}`
  )

  const res = await axios.post('https://tmpfiles.org/api/v1/upload', formData)
  const url = res.data?.data?.url
  if (!url) throw 'Upload ke tmpfiles gagal.'

  const match = /https?:\/\/tmpfiles\.org\/(.+)/.exec(url)
  if (!match) throw 'URL tmpfiles tidak valid.'

  return `https://tmpfiles.org/dl/${match[1]}`
}

async function reminiEnhance(imageUrl) {
  try {
    const res = await axios.get('https://api-faa.my.id/faa/hdv4', {
      params: { image: imageUrl }
    })

    if (!res.data?.status || !res.data?.result?.image_upscaled) {
      return null
    }

    return res.data.result.image_upscaled
  } catch (e) {
    console.error(e)
    return null
  }
}