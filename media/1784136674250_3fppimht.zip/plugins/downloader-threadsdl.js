import axios from "axios";
import FormData from "form-data";
import * as cheerio from "cheerio";

const handler = async (m, { conn, args, usedPrefix, command }) => {
  // Validasi input URL
  if (!args[0]) {
    throw `Masukkan URL!\n\ncontoh:\n${usedPrefix + command} https://www.threads.net/t/Cujx6ryoYx6/?igshid=NTc4MTIwNjQ2YQ==`;
  }

  if (!args[0].match(/threads/gi)) {
    throw `URL Tidak Ditemukan! Pastikan URL Threads yang valid.`;
  }

  await m.reply("⏳ Sedang memproses permintaan...");

  try {
    // Menyiapkan FormData untuk permintaan POST
    let formData = new FormData();
    formData.append("url", args[0]);

    let headers = {
      headers: {
        ...formData.getHeaders(),
      },
    };

    // Mengirim permintaan POST ke situs savemythreads
    let { data: html } = await axios.post("https://savemythreads.com/result.php", formData, headers);

    // Parsing HTML menggunakan Cheerio
    let $ = cheerio.load(html);
    let images = [];
    let videos = [];

    // Mendapatkan semua elemen gambar dan video
    $("img").each((_, el) => {
      const src = $(el).attr("src");
      if (src) images.push(src);
    });

    $("video source").each((_, el) => {
      const src = $(el).attr("src");
      if (src) videos.push(src);
    });

    // Memproses hasil
    if (videos.length > 0) {
      await conn.sendFile(m.chat, videos[0], "threads.mp4", "*THREADS DOWNLOADER*\nVideo berhasil diunduh!", m);
    } else if (images.length > 0) {
      await conn.sendFile(m.chat, images[0], "threads.jpeg", "*THREADS DOWNLOADER*\nGambar berhasil diunduh!", m);
    } else {
      throw `Konten tidak ditemukan di URL Threads yang diberikan.`;
    }
  } catch (e) {
    console.error(e.message);
    throw `✖️ Gagal memproses permintaan. Coba lagi nanti.`;
  }
};

// Properti handler
handler.command = ["threadsdl"];
handler.help = ["threadsdl"].map((v) => v + " <url>");
handler.tags = ["downloader"];

handler.limit = true;
handler.register = true;

export default handler;