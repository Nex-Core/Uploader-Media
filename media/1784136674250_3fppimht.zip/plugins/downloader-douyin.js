import cheerio from "cheerio";
import fetch from "node-fetch";

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const Ar = {
    key: {
      participant: "0@s.whatsapp.net",
      remoteJid: "0@s.whatsapp.net",
      fromMe: false,
      id: "Halo",
    },
    message: { conversation: m.text },
  };

  if (!text) {
    return conn.reply(
      m.chat,
      `Link-nya mana?\nEX: ${usedPrefix + command} https://v.douyin.com/xxxxx`,
      Ar
    );
  }

  await conn.sendMessage(m.chat, { react: { text: "🍁", key: m.key } });

  try {
    const result = await douyinDownload(text);

    const video = result.dl.find((x) => /mp4/i.test(x.text));
    const audio = result.dl.find((x) => /audio|mp3/i.test(x.text));

    if (!video) return m.reply("Gagal mendapatkan video.");

    const caption = `\`D O U Y I N   D O W N L O A D E D\`\n\n> Request By ${m.pushName}`;

    await conn.sendFile(m.chat, video.url, "douyin.mp4", caption, Ar);

    if (audio) {
      await conn.sendFile(m.chat, audio.url, "douyin.mp3", null, m, true, {
        mimetype: "audio/mp4",
        ptt: false,
      });
    }

    await conn.sendMessage(m.chat, { react: { text: "🌸", key: m.key } });
  } catch (e) {
    console.error(e);
    m.reply("Gagal mengambil video Douyin. Pastikan link valid dan coba lagi.");
  }
};

handler.help = ['douyin'].map((v) => v + ' <url>');
handler.tags = ["downloader"];
handler.command = /^(douyin)$/i;
handler.register = true;
handler.limit = 2;

export default handler;

async function douyinDownload(url) {
  const apiUrl = "https://lovetik.app/api/ajaxSearch";
  const formBody = new URLSearchParams();
  formBody.append("q", url);
  formBody.append("lang", "id");

  const response = await fetch(apiUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
      Accept: "*/*",
      "X-Requested-With": "XMLHttpRequest",
    },
    body: formBody.toString(),
  });

  const data = await response.json();
  if (data.status !== "ok") throw new Error("Failed to fetch video");

  const $ = cheerio.load(data.data);
  const title = $("h3").text();
  const thumbnail = $(".image-tik img").attr("src");
  const duration = $(".content p").text();
  const dl = [];

  $(".dl-action a").each((i, el) => {
    dl.push({
      text: $(el).text().trim(),
      url: $(el).attr("href"),
    });
  });

  return { title, thumbnail, duration, dl };
}