import { areJidsSameUser } from 'baileys'

function resolveJid(input, participants = []) {
    const found = participants.find(p =>
        areJidsSameUser(p?.id, input) ||
        areJidsSameUser(p?.lid, input) ||
        areJidsSameUser(p?.jid, input)
    )
    return found?.jid || input
}

const delay = time => new Promise(res => setTimeout(res, time))

let handler = async (m, { conn, args }) => {
    try {
        let group = await conn.groupMetadata(m.chat)
        if (!args[0]) return m.reply('Jumlah hari?')

        let jumlahHari = parseInt(args[0])
        if (isNaN(jumlahHari) || jumlahHari < 1) {
            return m.reply('Masukkan jumlah hari yang valid (minimal 1)')
        }

        let users = global.db.data.users
        let pesertaTerdaftar = group.participants.filter(p => {
            let id = resolveJid(p.id, group.participants)
            return users[id]?.registered
        })

        if (!pesertaTerdaftar.length) {
            return m.reply('Tidak ada peserta yang sudah register di database, undian dibatalkan.')
        }

        let peserta = pesertaTerdaftar.getRandom()
        let who = resolveJid(peserta.id, group.participants)

        await m.reply('Mencari pemenang...')
        await delay(10000)

        let now = new Date() * 1
        let durasi = 86400000 * jumlahHari

        if (now < users[who].premiumTime) {
            users[who].premiumTime += durasi
        } else {
            users[who].premiumTime = now + durasi
        }
        users[who].premium = true

        let cap = `Selamat kepada @${who.split('@')[0]} yang terpilih sebagai pemenang giveaway *Premium*.\n- ${jumlahHari} Hari\n> Ketik .cekprem untuk melihat sisa waktu premium kamu!!`

        await conn.reply(m.chat, cap, m, { mentions: [who] })

    } catch (e) {
        console.error(e)
        m.reply('Terjadi kesalahan, silakan coba lagi.')
    }
}

handler.help = ['undiprem <hari>']
handler.tags = ['group']
handler.command = /^undiprem$/i
handler.owner = true
handler.group = true

export default handler