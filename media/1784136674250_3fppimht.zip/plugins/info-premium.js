let handler = async (m, { conn }) => {
  let caption = `👑 𝗟𝗜𝗦𝗧 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 👑

• 📮 1 Bulan = Rp.10.000
   - Free Money 50JT

• 📮 2 Bulan = Rp.20.000
   - Free Money 100JT

• 📮 3 Bulan = Rp.30.000
   - Free Money 150Jt

• 📮 1 Tahun = Rp.100.000
   - Free Money 1M
  
• 📮 Permanent = Rp.150.000
   - Free Money 2M
   
*[ Keuntungan Premium ]*
- Limit unlimited
- WM Sticker
- Remini Unlimited
- HD Unlimited
- TikTok HD
- To Anime
- To Reall
- Ai Claude
- Ai Chi-GPT (Real-Time)
- Nsfw
Dan masih banyak lagi!`;

  await conn.sendMessage(m.chat, { 
    video: { url: "https://files.catbox.moe/edlyc4.mp4" }, 
    gifPlayback: true, // This makes the video play as a GIF
    caption: caption 
  }, { quoted: floc }); // This makes it a reply
};

handler.command = /^(premium|prem)$/i;
handler.tags = ["info"];
handler.help = ['premium'];

export default handler;