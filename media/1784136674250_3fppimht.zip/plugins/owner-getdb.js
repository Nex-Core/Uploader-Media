import fs from 'fs'

let handler = async (m, { conn }) => {
    m.reply('Tunggu Sebentar, Sedang mengambil file Database')

    try {
        let files = [
            { path: './database.json', name: 'database.json' },
            { path: './clan.json', name: 'clan.json' },
            { path: './spy_data.json', name: 'spy_data.json' }
        ]

        for (let file of files) {
            if (fs.existsSync(file.path)) {
                let data = await fs.readFileSync(file.path)
                await conn.sendMessage(m.chat, { document: data, mimetype: 'application/json', fileName: file.name }, { quoted: m })
            } else {
                m.reply(`⚠️ File ${file.name} tidak ditemukan!`)
            }
        }
    } catch (e) {
        console.error(e)
        m.reply('Terjadi kesalahan saat mengambil file!')
    }
}

handler.help = ['getdb']
handler.tags = ['owner']
handler.command = /^(getdb)$/i
handler.owner = true

export default handler