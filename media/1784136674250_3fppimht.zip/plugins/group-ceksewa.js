let handler = async (m, { conn, args }) => {
    if (global.db.data.chats[m.chat].expired < 1) throw 'Group ini tidak di-set sewa!';
    let who = m.isGroup ? (args[1] ? args[1] : m.chat) : args[1];

    let now = new Date().getTime();
    let expiredTimestamp = global.db.data.chats[who].expired;
    let remainingTime = expiredTimestamp - now;

    if (remainingTime <= 0) throw 'Sewa sudah berakhir!';

    let timeLeft = msToTime(remainingTime);

    let expiredDate = new Date(expiredTimestamp).toLocaleDateString('id-ID', {
        day: 'numeric', month: 'long', year: 'numeric'
    });

    let caption = `
⏳ *Sisa Waktu Sewa* ⏳
${padZero(timeLeft.days)} Hari : ${padZero(timeLeft.hours)} Jam : ${padZero(timeLeft.minutes)} Menit

📅 *Expired:* ${expiredDate}
    `.trim();

    await conn.reply(m.chat, caption, floc);
};

function padZero(num) {
    return num < 10 ? '0' + num : num;
}

function msToTime(ms) {
    let days = Math.floor(ms / (24 * 60 * 60 * 1000));
    let hours = Math.floor((ms / (60 * 60 * 1000)) % 24);
    let minutes = Math.floor((ms / (60 * 1000)) % 60);
    return { days, hours, minutes };
}

handler.help = ['ceksewa'];
handler.tags = ['group'];
handler.command = /^(ceksewa)$/i;
handler.group = true;

export default handler;