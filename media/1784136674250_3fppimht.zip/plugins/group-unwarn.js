let handler = async (m, { conn, args }) => {
    let mention;

    if (m.quoted) {
        mention = m.quoted.sender;
    } else if (args[0]) {
        mention = m.mentionedJid && m.mentionedJid[0] || conn.parseMention(args[0]) || (args[0].replace(/[@.+-]/g, '').trim() + '@s.whatsapp.net');
    }

    if (!mention) throw '❔ Tag atau reply salah satu user yang mau dihapus warn-nya.';

    if (!(mention in global.db.data.users)) throw '⚠️ User tidak terdaftar dalam DATABASE!';
    
    let user = global.db.data.users[mention];

    if (!user.warn2 || user.warn2 <= 0) throw '⛔ User tidak memiliki warn untuk dihapus.';

    let count = 1;
    if (args[1] && !isNaN(args[1])) count = parseInt(args[1]);
    if (user.warn2 < count) throw `⚠️ User hanya memiliki *${user.warn2}* warn.`;

    user.warn2 -= count;

    m.reply(`✔️ Berhasil menghapus *${count}* warn dari @${mention.split('@')[0]}. Sekarang memiliki *${user.warn2}* warn.`, null, { mentions: [mention] });
}

handler.help = ['unwarn @mention', 'unwarn (reply)']
handler.tags = ['group']
handler.command = /^unwarn(user)?$/i
handler.group = true
handler.admin = true
handler.botAdmin = true

export default handler;