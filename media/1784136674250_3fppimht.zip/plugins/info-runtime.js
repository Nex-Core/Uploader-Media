let handler = async (m, { conn }) => {
    let _muptime = process.uptime() * 1000;
    let muptime = clockString(_muptime);

    await conn.relayMessage(m.chat, {
        reactionMessage: {
            key: m.key,
            text: '🌸'
        }
    }, { messageId: m.key.id });

    await conn.sendMessage(m.chat, {
        text:
`╭─❏ *『  RUNTIME 』* ❏
│
│ ✨ *Status Bot Aktif*
│
│ ⏱ *Uptime* : ${muptime}
│ 📡 *Kondisi* : Online & Stabil
│ ⚡ *Respon* : Cepat & Siap Pakai
│
╰───────────────❏

Terima kasih telah menggunakan *Nishi chisato*!
_Stay connected with powerful performance._`,
    }, { quoted: floc });
};

handler.help = ['runtime'];
handler.tags = ['info'];
handler.command = ['runtime', 'rt'];

export default handler;

function clockString(ms) {
    if (isNaN(ms)) return '--';
    let d = Math.floor(ms / 86400000);
    let h = Math.floor(ms / 3600000) % 24;
    let m = Math.floor(ms / 60000) % 60;
    let s = Math.floor(ms / 1000) % 60;
    return `${d} Hari ${h} Jam ${m} Menit ${s} Detik`;
}