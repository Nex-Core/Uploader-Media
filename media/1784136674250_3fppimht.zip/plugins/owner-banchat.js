let handler = async (m, { participants }) => {
    // if (participants.map(v=>v.jid).includes(global.conn.user.jid)) {
    global.db.data.chats[m.chat].isBanned = true
    // } else m.reply('Ada nomor host disini...')
    conn.sendMessage(m.chat, {
text: 'Done Mematikan Ruang Sesi Chisato', 
contextInfo: {
externalAdReply: {
title: "Chasato Sedang Offline",
body: 'Request Fitur PM +62 819-9987-1794',
thumbnailUrl: "https://files.catbox.moe/21bt95.jpg",
sourceUrl: "",
mediaType: 1,
renderLargerThumbnail: true
}
}})
}
handler.help = ['banchat']
handler.tags = ['owner']
handler.command = /^(banchat|bnc)$/i

handler.admin = true

export default handler