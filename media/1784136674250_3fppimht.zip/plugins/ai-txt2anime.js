import axios from 'axios';
import crypto from 'crypto';

class Text2AnimeClient {
  constructor() {
    this.baseURL = 'https://anifun.ai/api/v1/generation';
    this.credentials = this.generateCredentials();
    this.headers = {
      'Accept': 'application/json, text/plain, */*',
      'Content-Type': 'application/json',
      'fp': this.credentials.fp,
      'fp1': this.credentials.fp1,
      'x-guide': this.credentials.xGuide
    };
    this.pollInterval = 3000;
    this.maxRetries = 60;
  }

  generateCredentials() {
    const fp = crypto.randomBytes(16).toString('hex');
    const fp1 = crypto.randomBytes(32).toString('base64').replace(/[/+=]/g, '').substring(0, 44);
    const xGuide = crypto.randomBytes(64).toString('base64');
    return { fp, fp1, xGuide };
  }

  refreshCredentials() {
    this.credentials = this.generateCredentials();
    this.headers.fp = this.credentials.fp;
    this.headers.fp1 = this.credentials.fp1;
    this.headers['x-guide'] = this.credentials.xGuide;
  }

  async createGeneration(options = {}) {
    const defaultOptions = {
      prompt: "(masterpiece), best quality, expressive eyes, perfect face",
      negative_prompt: "(worst quality, low quality:1.4), (greyscale, monochrome:1.1), cropped, lowres , username, blurry, trademark, watermark, title, strabismus, worst hand, (ugly face:1.2), extra leg, extra arm, bad foot, text, name, badhandv4, easynegative, EasyNegativeV2, negative_hand, ng_deepnegative_v1_75t",
      steps: 25,
      cfg: 7,
      seed: -1,
      batch_size: 1,
      model: {
        id: 1666,
        name: "WAI-NSFW-illustrious",
        modelType: "SDXL",
        preview: "https://animegenius-global.live3d.io/vtuber/ai_product/anime_genius/images/724d5db87e9a6dabe5a0ded8e1182df8.jpg",
        fileName: "WaiNSFWIllustriousSDXL_v14.safetensors"
      },
      loras: [],
      size: "1:1",
      width: 1024,
      height: 1024
    };

    const requestData = {
      type: 1,
      fn_name: "ai_body",
      input: { ...defaultOptions, ...options }
    };

    try {
      const response = await axios.post(
        `${this.baseURL}/app_create`,
        requestData,
        { headers: this.headers }
      );

      if (response.data.code === 200) {
        return response.data.result;
      } else {
        throw new Error(`API Error: ${response.data.code}`);
      }
    } catch (error) {
      if (error.response && (error.response.status === 401 || error.response.status === 403)) {
        this.refreshCredentials();
        throw new Error(`Authentication failed, credentials refreshed. Please retry.`);
      }
      throw new Error(`Request failed: ${error.message}`);
    }
  }

  async checkTaskStatus(taskId) {
    try {
      const response = await axios.get(
        `${this.baseURL}/app_task_state?task_id=${taskId}`,
        { headers: this.headers }
      );
      return response.data;
    } catch (error) {
      throw new Error(`Status check failed: ${error.message}`);
    }
  }

  async pollForCompletion(taskId) {
    let retries = 0;
    
    while (retries < this.maxRetries) {
      try {
        const status = await this.checkTaskStatus(taskId);
        
        if (status.code === 200) {
          return status.result;
        }
        
        if (status.code === 201) {
          await this.sleep(this.pollInterval);
          retries++;
          continue;
        }
        
        if (status.code === 500) {
          throw new Error(`Server error for task ${taskId}`);
        }
        
        throw new Error(`Unexpected status code: ${status.code}`);
        
      } catch (error) {
        if (error.message.includes('Server error') || error.message.includes('Unexpected status')) {
          throw error;
        }
        await this.sleep(this.pollInterval);
        retries++;
      }
    }
    
    throw new Error(`Task ${taskId} timed out after ${this.maxRetries * this.pollInterval / 1000} seconds`);
  }

  async generateAnime(options = {}) {
    try {
      const createResult = await this.createGeneration(options);
      const taskId = createResult.task_id;
      const result = await this.pollForCompletion(taskId);
      const fullUrls = result.map(path => `https://temp.anifun.ai/${path}`);
      return { urls: fullUrls };
    } catch (error) {
      if (error.message.includes('Authentication failed')) {
        const createResult = await this.createGeneration(options);
        const taskId = createResult.task_id;
        const result = await this.pollForCompletion(taskId);
        const fullUrls = result.map(path => `https://temp.anifun.ai/${path}`);
        return { urls: fullUrls };
      }
      throw new Error(`Generation failed: ${error.message}`);
    }
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

const client = new Text2AnimeClient();

async function scrape(prompt) {
  const result = await client.generateAnime({
    prompt: prompt
  });
  return result.urls;
}

let handler = async (m, { conn, usedPrefix, command, text }) => {
  if (!text) return m.reply(`Promptnya?\n> EX: ${usedPrefix + command} Pink -haired girl posing nungging showing her vagina and ass, naked not wearing any clothes`);

  const react = { react: { text: "🍁", key: m.key } };
  const reactdone = { react: { text: "🌸", key: m.key } };
  conn.sendMessage(m.chat, react);

  try {
    const urls = await scrape(text);
    for (let url of urls) {
      conn.sendMessage(m.chat, { image: { url }, caption: `Nihh kak hasil prompt:\n> ${text}` }, { quoted: floc });
    }
  } catch (e) {
    m.reply('Gagal generate anime: ' + e.message);
  } finally {
    conn.sendMessage(m.chat, reactdone);
  }
};

handler.command = /^(txt2anime)$/i;
handler.help = ['txt2anime'].map(a => a + " <prompt>");
handler.tags = ['ai'];
handler.limit = 10;
handler.register = true;

export default handler;