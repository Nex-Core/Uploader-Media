let handler = async (m, { conn }) => {
  let htjava = '◆'
  let htki = '━━⬣'
  let htka = '⬣━━'

  let pc = Object.entries(await conn.chats)
  let niorg = pc.filter(([jid]) => jid.endsWith('@s.whatsapp.net'))
  let thumbListpc = `https://files.catbox.moe/sz25kv.jpg`
  let txt = ''

  for (let [jid] of niorg)
    txt += `${htjava} ${await conn.getName(jid)}\n@${jid.replace(/@.+/, '')}\n\n`

  return conn.sendMessage(m.chat, {
    image: { url: thumbListpc },
    caption: `${htki} *CHAT PRIVATE* ${htka}\n*Total:* ${niorg.length}\n\n${txt.trim()}`,
    contextInfo: {
      mentionedJid: conn.parseMention(txt)
    }
  }, { quoted: m })
}

handler.help = ['listpc']
handler.tags = ['owner']
handler.command = /^listpc|pclist|daftarpc$/i
handler.owner = true

export default handler