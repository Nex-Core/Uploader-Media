let handler = async (m, { conn }) => {
    let users = global.db.data.users
    let unbannedCount = 0

    for (let userId in users) {
        if (users[userId].banned) {
            users[userId].banned = false
            unbannedCount++
        }
    }
    
    conn.reply(m.chat, `Done! Unbanned ${unbannedCount} users.`, m)
}
handler.help = ['unbanall']
handler.tags = ['owner']
handler.command = /^unban(all)?$/i
handler.rowner = true

export default handler