import fs from 'fs'
import fetch from 'node-fetch'
import moment from 'moment-timezone'

let handler = async (m, { conn, text, usedPrefix, command }) => {
    let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
    let name = await conn.getName(who)
    
    let fitur = Object.values(plugins).filter(v => v.help && !v.disabled).map(v => v.help).flat(1)
    let totalf = Object.values(global.plugins).filter(v => v.help && v.tags).length

    // Menghitung total file dalam folder plugins
    let pluginFiles = fs.readdirSync('./plugins')
    let totalFiles = pluginFiles.length

    let txt = `🚀 *\`BOT FEATURE LIST\`* 🚀\n\n` +
              `* *Total Files:*   _${totalFiles}_\n` + 
              `* *Total Fitur:*   _${fitur.length}_\n` +
              `* *Name Bot:*   _${global.namebot}_\n` + 
              `* *Creator:*   _${global.nameown1}_`

    // Menggunakan m.reply untuk membalas pesan
    conn.reply(m.chat, txt, floc)
}

handler.help = ['totalfitur']
handler.tags = ['info']
handler.command = /^(totalfitur|totalfeature|totalcmd)$/i
export default handler