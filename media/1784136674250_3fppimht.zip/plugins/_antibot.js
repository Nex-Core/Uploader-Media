export async function before(m, { conn, isAdmin, isBotAdmin }) {
  if (!m.isGroup) return;
  if (m.fromMe) return true;
  
  let chat = global.db.data.chats[m.chat];
  
  if (!chat.antiBot) return;
  
  const isSuspiciousBot = 
    (m.id.startsWith('3EB0') && m.id.length === 22) ||
    (m.id.startsWith('BAE5') && m.id.length === 16) ||
    m.key.id?.startsWith('BAES') ||
    false;
  
  if (!isSuspiciousBot) return;
  
  const sender = m.sender;
  
  const metadata = await conn.groupMetadata(m.chat).catch(() => null);
  if (!metadata) return;
  
  const subject = metadata.subject || 'Unknown Group';
  const participants = metadata.participants || [];
  
  const groupAdmins = participants
    .filter(v => v.admin)
    .map(v => v.id);
  
  if (groupAdmins.includes(sender)) return;
  
  const adminList = groupAdmins
    .map(v => `⊹ @${v.split('@')[0]}`)
    .join('\n');
  
  const botTag = `@${sender.split('@')[0]}`;
  const mentions = [...groupAdmins, sender];
  
  const reportText = `╭─୨୧・*SISTEM ANTIBOT TERDETEKSI*・୨୧
│
│ ૮₍ ˶•༝•˶ ₎ა *Bot lain terdeteksi di grup!*
│
│ ✦ *Nama Grup:*
│   ${subject}
│
│ ✦ *Akun Terdeteksi:*
│   ${botTag}
│
│ ✦ *Admin Grup:*
${adminList}
│
│ ✦ *Tindakan:*
│   ⚠️ Akun akan dikeluarkan!
│
╰────────────♡`;

  await conn.sendMessage(
    m.chat,
    { text: reportText, mentions },
    { quoted: m }
  );
  
  await conn.sendMessage(m.chat, { delete: m.key }).catch(() => {});
  
  await conn.delay(1000);
  
  if (isBotAdmin && !groupAdmins.includes(sender)) {
    await conn.groupParticipantsUpdate(m.chat, [sender], 'remove')
      .catch(err => {
        conn.reply(m.chat, `❌ Gagal mengeluarkan bot: ${err.message}`, m);
      });
  } else if (!isBotAdmin) {
    await conn.reply(m.chat, '⚠️ Bot bukan admin, tidak bisa mengeluarkan bot lain!', m);
  }
}