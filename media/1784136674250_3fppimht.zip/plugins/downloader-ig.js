import axios from 'axios'
import * as cheerio from 'cheerio'
import { generateWAMessageFromContent, generateWAMessage } from 'baileys'

async function sendAlbum(conn, jid, medias, options = {}) {
  const userJid = conn.user?.id || conn.authState?.creds?.me?.id
  if (!Array.isArray(medias) || medias.length < 1) {
    throw new Error("Album minimal berisi 1 media (gambar/video).")
  }

  const time = options.delay || 500
  delete options.delay

  const album = await generateWAMessageFromContent(
    jid,
    {
      albumMessage: {
        expectedImageCount: medias.filter(m => m.image).length,
        expectedVideoCount: medias.filter(m => m.video).length
      }
    },
    { userJid, ...options }
  )

  await conn.relayMessage(jid, album.message, { messageId: album.key.id })

  for (const media of medias) {
    if (!(media.image || media.video)) continue

    const msg = await generateWAMessage(
      jid,
      {
        ...(media.image ? { image: media.image } : {}),
        ...(media.video ? { video: media.video } : {}),
        caption: media.caption || "",
        ...options
      },
      {
        userJid,
        upload: async (readStream, opts) => {
          return await conn.waUploadToServer(readStream, opts)
        },
        ...options
      }
    )

    msg.message.messageContextInfo = {
      messageAssociation: {
        associationType: 1,
        parentMessageKey: album.key
      }
    }

    await conn.relayMessage(jid, msg.message, { messageId: msg.key.id })
    await new Promise(res => setTimeout(res, time))
  }

  return album
}

async function igDownloader(url) {
  try {
    const { data } = await axios.post(
      'https://yt1s.io/api/ajaxSearch',
      new URLSearchParams({ p: 'home', q: url, w: '', lang: 'en' }),
      {
        headers: {
          'User-Agent': 'Postify/1.0.0',
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        },
      }
    )

    if (data.status !== 'ok') throw new Error('Tidak ada respons dari API.')

    const $ = cheerio.load(data.data)

    return $('a.abutton.is-success.is-fullwidth.btn-premium')
      .map((_, el) => ({
        title: $(el).attr('title'),
        url: $(el).attr('href'),
      }))
      .get()
  } catch (err) {
    console.error("IG Downloader Error:", err.message)
    throw err
  }
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `EX: ${usedPrefix}${command} https://www.instagram.com/reel/xxxxxx`

  await m.reply(wait)

  try {
    const results = await igDownloader(text)

    if (!results.length) throw new Error("Tidak ada media yang ditemukan.")

    let images = []

    for (let media of results) {
      if (/download video/i.test(media.title)) {
        await conn.sendMessage(m.chat, {
          video: { url: media.url },
          caption: `> Request By ${m.pushName}`,
        })
      } else if (/download image/i.test(media.title)) {
        images.push({
          image: { url: media.url },
          caption: `> Request By ${m.pushName}`,
        })
      }
    }

    if (images.length > 0) {
      if (images.length === 1) {
        await conn.sendMessage(m.chat, images[0], { quoted: m })
      } else {
        await sendAlbum(conn, m.chat, images, { quoted: m })
      }
    }

  } catch (e) {
    m.reply(`Terjadi kesalahan: ${e.message}`)
  }
}

handler.help = ['instagram'].map(v => v + ' <url>')
handler.tags = ['downloader']
handler.command = /^(instagram|ig|igdl)$/i
handler.limit = true
handler.register = true

export default handler