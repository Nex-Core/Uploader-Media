import fs from 'fs';

const TARGET_GROUP_ID = '120363402681140897@g.us'; // Kasih ID grup private

let handler = m => m;

handler.before = async function (m, { conn }) {
  async function sendBackup(chatId) {
    try {
      let files = [
        { path: './database.json', name: 'database.json' },
        { path: './clan.json', name: 'clan.json' },
        { path: './spy_data.json', name: 'spy_data.json' }
      ];

      await conn.sendMessage(chatId, { text: 'Mengirim backup database otomatis...' });

      for (let file of files) {
        if (fs.existsSync(file.path)) {
          let data = await fs.readFileSync(file.path);
          await conn.sendMessage(chatId, { document: data, mimetype: 'application/json', fileName: file.name });
        } else {
          await conn.sendMessage(chatId, { text: `File ${file.name} tidak ditemukan!` });
        }
      }
    } catch (e) {
      console.error(e);
      await conn.sendMessage(chatId, { text: 'Terjadi kesalahan saat mengirim backup database!' });
    }
  }

  let groupData = global.db.data.chats[TARGET_GROUP_ID];
  if (!groupData) groupData = global.db.data.chats[TARGET_GROUP_ID] = {};
  if (!groupData.autoBackup) groupData.autoBackup = false;

  if (groupData.autoBackup && !groupData.backupInterval) {
    groupData.backupInterval = setInterval(() => sendBackup(TARGET_GROUP_ID), 30 * 60 * 1000);
  } else if (!groupData.autoBackup && groupData.backupInterval) {
    clearInterval(groupData.backupInterval);
    groupData.backupInterval = null;
  }

  return true;
};

handler.group = true;

export default handler;