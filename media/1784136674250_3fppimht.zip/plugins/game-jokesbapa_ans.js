import similarity from 'similarity'

const threshold = 0.72 // Tingkat kemiripan jawaban

export async function before(m) {
    this.jokesBapack = this.jokesBapack || {}
    let id = 'jokesbapak_' + m.chat
    
    if (!(id in this.jokesBapack)) return true
    
    let room = this.jokesBapack[id]
    let text = m.text.toLowerCase().replace(/[^\w\s\-]+/g, '').trim()
    let isSurrender = /^(nyerah|give\s?up|surrender)$/i.test(m.text)
    
    if (isSurrender) {
        let answer = `❌ *NYERAH!*

❓ ${room.setup}

💡 Jawabannya: *${room.answer[0]}* xixixi 😂

_Ketik .jokesbapak untuk main lagi!_`
        
        await this.reply(m.chat, answer, m)
        delete this.jokesBapack[id]
        return false
    }
    
    let isCorrect = false
    let maxSimilarity = 0
    
    for (let ans of room.answer) {
        let sim = similarity(ans, text)
        if (sim > maxSimilarity) maxSimilarity = sim
        
        if (text === ans || sim >= threshold) {
            isCorrect = true
            break
        }
    }
    
    if (!isCorrect && maxSimilarity >= 0.5) {
        m.reply('💭 Dikit lagi! Coba lagi...')
        return false
    }
    
    if (!isCorrect) {
        return true
    }
    
    let users = global.db.data.users[m.sender]
    users.eris = (users.eris || 0) + 500000
    
    let success = `✅ *BENAR!*

❓ ${room.setup}

💡 Jawabannya: *${room.answer[0]}* xixixi 😂

💰 +Money 500.000
💵 Money: ${users.eris.toLocaleString('id-ID')}

_Ketik .jokesbapak untuk main lagi!_`
    
    await this.reply(m.chat, success, m)
    delete this.jokesBapack[id]
    
    return false
}