import { family100 } from '@bochilteam/scraper'

const winScore = 500

async function handler(m) {
    this.game = this.game ? this.game : {}
    let id = 'family100_' + m.chat

    if (id in this.game) {
        this.reply(m.chat, '*Masih ada kuis yang belum terjawab di chat ini!*', this.game[id].msg)
        throw false
    }

    const json = await family100()

    let caption = `
╭──────────╮
    𝗙𝗔𝗠𝗜𝗟𝗬 𝟭𝟬𝟬  
╰──────────╯

⨀ *Soal:* ${json.soal}  
⨀ *Jumlah Jawaban:* ${json.jawaban.length}  
⨀ *Reward:* +${winScore} XP per jawaban benar  
${json.jawaban.find(v => v.includes(' ')) ? `⨀ (Beberapa jawaban memiliki spasi)` : ''}

╭─────────────╮
    Ketik jawabanmu!  
╰─────────────╯
    `.trim()

    this.game[id] = {
        id,
        msg: await this.reply(m.chat, caption, m),
        ...json,
        terjawab: Array.from(json.jawaban, () => false),
        winScore,
    }
}

handler.help = ['family100']
handler.tags = ['game']
handler.command = /^family100$/i

export default handler