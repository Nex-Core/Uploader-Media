const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = (await import('baileys')).default;

const handler = async (m, { conn, usedPrefix, command, isOwner, args }) => {
    if (!isOwner) return m.reply('*ᴘᴇʀɪɴᴛᴀʜ ɪɴɪ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪɢᴜɴᴀᴋᴀɴ ᴏʟᴇʜ ᴏᴡɴᴇʀ ʙᴏᴛ.*');

    const groupList = await conn.groupFetchAllParticipating();
    const groups = Object.values(groupList);

    if (groups.length === 0) {
        return m.reply('*ʙᴏᴛ ᴛɪᴅᴀᴋ ᴛᴇʀɢᴀʙᴜɴɢ ᴅᴀʟᴀᴍ ɢʀᴜᴘ ᴀᴘᴀ ᴘᴜɴ.*');
    }

    if (!args[0]) {
        let groupText = '╭──「 *ᴅᴀꜰᴛᴀʀ ɢʀᴜᴘ ʙᴏᴛ* 」\n';
        groups.forEach((group, index) => {
            let chatData = global.db.data.chats[group.id] || {};
            let expiredTimestamp = chatData.expired || 0;
            let now = Date.now();
            let statusSewa;

            if (expiredTimestamp > now) {
                let remainingTime = msToTime(expiredTimestamp - now);
                statusSewa = `⏳ *ꜱɪꜱᴀ ꜱᴇᴡᴀ:* ${remainingTime.days} ʜʀ, ${remainingTime.hours} ᴊᴍ, ${remainingTime.minutes} ᴍɴ`;
            } else if (expiredTimestamp === 0) {
                statusSewa = '❌ *ᴛɪᴅᴀᴋ ᴅɪꜱᴇᴛ ꜱᴇᴡᴀ*';
            } else {
                statusSewa = '⚠️ *ꜱᴜᴅᴀʜ ᴇxᴘɪʀᴇᴅ*';
            }

            groupText += `\n╭───────────────────────\n├ ✦ *${index + 1}.*「 *${group.subject}* 」\n│   👑 *ᴏᴡɴᴇʀ:* wa.me/${group.owner?.split('@')[0] || 'ᴛɪᴅᴀᴋ ᴅɪᴋᴇᴛᴀʜᴜɪ'}\n│   👥 *ᴍᴇᴍʙᴇʀ:* ${group.participants.length}\n│   ${statusSewa}\n╰───────────────────────`;
        });

        let sections = [{
            title: `${global.author}`,
            rows: groups.map((group, index) => ({
                title: `➤ ᴋᴇʟᴜᴀʀ ᴅᴀʀɪ ${group.subject}`,
                description: `👥 ᴛᴏᴛᴀʟ ᴍᴇᴍʙᴇʀ: ${group.participants.length}`,
                id: `${usedPrefix + command} ${index + 1}`
            }))
        }];

        let listMessage = {
            title: 'ᴘɪʟɪʜ ɢʀᴜᴘ',
            sections
        };

        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: groupText,
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            title: 'ᴋᴇʟᴜᴀʀ ᴅᴀʀɪ ɢʀᴜᴘ',
                            hasMediaAttachment: true,
                            ...(await prepareWAMessageMedia({ image: { url: `https://files.catbox.moe/7vgwo5.jpg` } }, { upload: conn.waUploadToServer }))
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [{
                                "name": "single_select",
                                "buttonParamsJson": JSON.stringify(listMessage)
                            }]
                        })
                    })
                }
            }
        }, {});

        return conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    }

    let groupIndex = parseInt(args[0]) - 1;
    if (isNaN(groupIndex) || groupIndex < 0 || groupIndex >= groups.length) {
        return m.reply('*ɴᴏᴍᴏʀ ɢʀᴜᴘ ᴛɪᴅᴀᴋ ᴠᴀʟɪᴅ.*');
    }

    let selectedGroup = groups[groupIndex].id;
    let groupName = groups[groupIndex].subject;

    try {
        await conn.reply(selectedGroup, `*ᴍᴀꜱᴀ ꜱᴇᴡᴀ ᴛᴇʟᴀʜ ʙᴇʀᴀᴋʜɪʀ.*\nᴛᴇʀɪᴍᴀ ᴋᴀsɪʜ ᴛᴇʟᴀʜ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ʟᴀʏᴀɴᴀɴ ɪɴɪ.`, null);
        await conn.groupLeave(selectedGroup);
        m.reply(`✅ *ʙᴇʀʜᴀsɪʟ ᴋᴇʟᴜᴀʀ ᴅᴀʀɪ ɢʀᴜᴘ:* *${groupName}*`);
    } catch (e) {
        m.reply(' *ɢᴀɢᴀʟ ᴋᴇʟᴜᴀʀ ᴅᴀʀɪ ɢʀᴜᴘ.*\nᴍᴜɴɢᴋɪɴ ʙᴏᴛ ʙᴜᴋᴀɴ ᴀᴅᴍɪɴ ᴀᴛᴀᴜ ᴀᴅᴀ ᴋᴇɴᴅᴀʟᴀ ʟᴀɪɴ.');
    }
};

function msToTime(ms) {
    let days = Math.floor(ms / (24 * 60 * 60 * 1000));
    let hours = Math.floor((ms / (60 * 60 * 1000)) % 24);
    let minutes = Math.floor((ms / (60 * 1000)) % 60);
    return { days, hours, minutes };
}

handler.help = ['listsewa'];
handler.tags = ['owner'];
handler.command = ['listsewa'];
handler.rowner = true;

export default handler;