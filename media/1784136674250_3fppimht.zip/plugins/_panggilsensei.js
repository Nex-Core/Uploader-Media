let handler = async (m, { conn, text, command }) => {
    // Memeriksa apakah obrolan berada di grup
    if (!m.isGroup) return; // Jika bukan di grup, keluar dari fungsi

    // Memeriksa apakah pengguna yang mengetik adalah Ponta sendiri
    if (m.sender == '6283854025278@s.whatsapp.net') return;
    
    // Mengirim pesan balasan jika pengguna bukan Ponta dan berada di grup
    conn.reply(m.chat, `@6283854025278 om ada yang nyariin lu nih`, floc);
}

handler.customPrefix = /^(sense|ar|sensei|arul)$/i;
handler.command = new RegExp();
export default handler;