let handler = async (m, { conn }) => {
    let total = Object.keys(global.db.data.sticker).length
    global.db.data.sticker = {}
    conn.reply(m.chat, `Berhasil menghapus semua *${total}* perintah command.`, m)
}

handler.help = ['delallcmd']
handler.tags = ['main']
handler.command = ['delallcmd']
handler.owner = true

export default handler