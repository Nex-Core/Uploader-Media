import { createHash } from 'crypto';

let handler = async function (m, { args }) {
  if (!args[0]) throw 'Masukkan Serial Nomor, kalau tidak tahu ketik .ceksn';

  // Extract SN part from the URL if it matches the pattern
  let snInput = args[0].match(/https:\/\/ar-sensei\.com\/sn\/([a-f0-9]{32})/i);
  if (!snInput) throw 'Format Serial Nomor tidak valid';

  let inputSn = snInput[1]; // Get the SN part from the URL
  let sn = createHash('md5').update(m.sender).digest('hex'); // Generate SN based on the user's ID

  // Check if the input SN matches the generated SN
  if (inputSn !== sn) throw 'Serial Nomor salah';

  // Unregister the user
  let user = global.db.data.users[m.sender];
  user.registered = false;
  m.reply('```Sukses Unreg!```');
};

handler.help = ['unregister'];
handler.tags = ['main'];
handler.command = /^unreg(ister)?$/i;
handler.register = true;

export default handler;