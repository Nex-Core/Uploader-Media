let handler = async (m, { conn, args, usedPrefix, command }) => {
  try {
    if (!m.message) return conn.reply(m.chat, 'Tidak ada pesan yang terdeteksi.', m)

    let msgType = Object.keys(m.message)[0]
    let jsonData = JSON.stringify(m.message, null, 2)

    if (jsonData.length > 4000) {
      return conn.sendFile(m.chat, Buffer.from(jsonData), 'pesan.json', 'Berikut isi pesan lengkap:', m)
    }

    conn.reply(m.chat, `*Tipe Pesan:* ${msgType}\n\n` + '```' + jsonData + '```', m)
  } catch (e) {
    console.error(e)
    conn.reply(m.chat, 'Terjadi error saat memproses pesan.', m)
  }
}

handler.command = /^typechat$/i
handler.help = ['typechat']
handler.tags = ['owner']

export default handler