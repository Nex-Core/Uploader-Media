let handler = async (m, { conn, text, usedPrefix }) => {
    let user = global.db.data.users[m.sender]

    const formatNumber = (number) => {
        if (number >= 1e63) return (number / 1e63).toFixed(2).replace(/\.00$/, '') + " vigintiliun";
        if (number >= 1e60) return (number / 1e60).toFixed(2).replace(/\.00$/, '') + " novemdesiliun";
        if (number >= 1e57) return (number / 1e57).toFixed(2).replace(/\.00$/, '') + " octodesiliun";
        if (number >= 1e54) return (number / 1e54).toFixed(2).replace(/\.00$/, '') + " septendesiliun";
        if (number >= 1e51) return (number / 1e51).toFixed(2).replace(/\.00$/, '') + " sexdesiliun";
        if (number >= 1e48) return (number / 1e48).toFixed(2).replace(/\.00$/, '') + " quindesiliun";
        if (number >= 1e45) return (number / 1e45).toFixed(2).replace(/\.00$/, '') + " kvatradesiliun";
        if (number >= 1e42) return (number / 1e42).toFixed(2).replace(/\.00$/, '') + " tredesiliun";
        if (number >= 1e39) return (number / 1e39).toFixed(2).replace(/\.00$/, '') + " dodesiliun";
        if (number >= 1e36) return (number / 1e36).toFixed(2).replace(/\.00$/, '') + " undesiliun";
        if (number >= 1e33) return (number / 1e33).toFixed(2).replace(/\.00$/, '') + " desiliun";
        if (number >= 1e30) return (number / 1e30).toFixed(2).replace(/\.00$/, '') + " noniliun";
        if (number >= 1e27) return (number / 1e27).toFixed(2).replace(/\.00$/, '') + " oktiliun";
        if (number >= 1e24) return (number / 1e24).toFixed(2).replace(/\.00$/, '') + " septiliun";
        if (number >= 1e21) return (number / 1e21).toFixed(2).replace(/\.00$/, '') + " sekstiliun";
        if (number >= 1e18) return (number / 1e18).toFixed(2).replace(/\.00$/, '') + " quintiliun";
        if (number >= 1e15) return (number / 1e15).toFixed(2).replace(/\.00$/, '') + " quadriliun";
        if (number >= 1e12) return (number / 1e12).toFixed(2).replace(/\.00$/, '') + " triliun";
        if (number >= 1e9) return (number / 1e9).toFixed(2).replace(/\.00$/, '') + " miliar";
        if (number >= 1e6) return (number / 1e6).toFixed(2).replace(/\.00$/, '') + " juta";
        if (number >= 1e3) return (number / 1e3).toFixed(2).replace(/\.00$/, '') + " ribu";
        return number.toString();
    }

    let moneyFormatted = formatNumber(user.eris);
    let bankFormatted = formatNumber(user.bank);
    let balanceFormatted = formatNumber(user.balance);

    conn.sendMessage(m.chat, {
        text: `🏦「 *BANK COIN PLAYER* 」🏦\n
🧑🏻‍💻 *Pemilik:* @${m.sender.split('@')[0]}
👤 *Name:* _${user.registered ? user.name : conn.getName(m.sender)}_
💸 *Money:* _Rp.${moneyFormatted}_
💳 *Bank:* _Rp.${bankFormatted}_
🪙 *Balance:* _Bc.${balanceFormatted}_
🪪 *Status:* _${user.premiumTime > 0 ? 'Premium' : 'Free'}_
📂 *Registered:* _${user.registered ? 'Yes' : 'No'}_\n\n‎*Tutorial Menabung Dan Menarik Uang‎*\n> *Ingin menabung?,* Ketik _.atm <jumlah>_
> *Ingin menarik uang?,* Ketik _.pull <jumlah>_`,
        mentions: [m.sender]
    }, { quoted: floc });
}

handler.help = ['bank']
handler.tags = ['rpg']
handler.command = /^(bank|💳)$/i
handler.register = false
handler.group = true

export default handler;