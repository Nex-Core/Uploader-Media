import axios from 'axios'

const sent = new Set()

const client = axios.create({
  baseURL: 'https://app.ytdown.to',
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'X-Requested-With': 'XMLHttpRequest',
    'Referer': 'https://ytdown.to/',
    'Origin': 'https://ytdown.to',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
  }
})

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms))

async function pollUntilDone(mediaUrl) {
  for (let i = 0; i < 60; i++) {
    await sleep(3000)
    const { data } = await client.post('/proxy.php', `url=${encodeURIComponent(mediaUrl)}`)
    if (data.api?.status === 'completed') return data.api
  }
  throw new Error('Timeout menunggu proses download')
}

let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) return m.reply(`EX:\n${usedPrefix + command} https://youtu.be/xxxxxxx`)

  const url = args[0]
  const ytId = url.match(/(?:youtube\.com\/(?:watch\?v=|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/)?.[1]
  if (!ytId) return m.reply('Link YouTube tidak valid')

  if (sent.has(m.key.id)) return
  sent.add(m.key.id)

  await conn.sendMessage(m.chat, { react: { text: '☆', key: m.key } })

  try {
    const video = await downloadYouTube(url, 'HD')

    const durationParts = video.duration?.split(':') || ['0', '0']
    const duration = durationParts.length === 3
      ? `${durationParts[0]}:${durationParts[1]}:${durationParts[2]}`
      : `${durationParts[0]}:${durationParts[1]}`

    await conn.sendMessage(m.chat, {
      video: { url: video.downloadUrl },
      mimetype: 'video/mp4',
      fileName: `${video.title}.mp4`,
      caption: `✿ ${video.title}\nResolution: ${video.resolution}\nSize: ${video.fileSize}\nDuration: ${duration}\nRequester: ${m.pushName}`
    }, { quoted: floc })

    await conn.sendMessage(m.chat, { react: { text: '✓', key: m.key } })

  } catch (e) {
    await conn.sendMessage(m.chat, { react: { text: '✗', key: m.key } })
    m.reply(`Upss... terjadi kesalahan\n> ${e.message || e}`)
  }

  setTimeout(() => sent.delete(m.key.id), 30000)
}

handler.command = /^(ytmp4|ytv)$/i
handler.tags = ['downloader']
handler.help = ['ytmp4'].map(v => v + ' <url>')
handler.limit = 2
handler.register = true

export default handler

async function downloadYouTube(youtubeUrl, quality = 'HD') {
  const { data: cooldown } = await client.post('/cooldown.php', 'action=check', {
    headers: { Accept: 'application/json, text/javascript, */*; q=0.01' }
  })

  if (!cooldown.can_download) {
    throw new Error(`Tidak bisa download. Tunggu ${cooldown.remaining_time}s`)
  }

  const { data: proxyRes } = await client.post('/proxy.php', `url=${encodeURIComponent(youtubeUrl)}`, {
    headers: { Accept: '*/*' }
  })

  const api = proxyRes.api
  if (api?.status !== 'ok') throw new Error('Gagal mendapatkan info video')

  const media = api.mediaItems.find(item => item.type === 'Video' && item.mediaQuality === quality)
  if (!media) throw new Error(`Resolusi ${quality} tidak tersedia`)

  await client.post('/cooldown.php', 'action=record', {
    headers: { Accept: 'application/json, text/javascript, */*; q=0.01' }
  })

  await client.post('/proxy.php', `url=${encodeURIComponent(media.mediaUrl)}`, {
    headers: { Accept: '*/*' }
  })

  const result = await pollUntilDone(media.mediaUrl)

  return {
    title: api.title,
    thumbnail: api.imagePreviewUrl,
    duration: media.mediaDuration,
    resolution: media.mediaRes,
    quality: media.mediaQuality,
    fileSize: result.fileSize,
    fileName: result.fileName,
    downloadUrl: result.fileUrl
  }
}