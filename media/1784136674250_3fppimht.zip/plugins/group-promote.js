import { areJidsSameUser } from 'baileys'

let handler = async (m, { conn }) => {
    let users = m.mentionedJid.filter(u => !areJidsSameUser(u, conn.user.id))
    let user = users[0]
    if (!user) throw 'Tag dulu orang yang mau dipromote'

    await conn.groupParticipantsUpdate(m.chat, [user], 'promote')
    m.reply('Succes')
}

handler.help = ['promote']
handler.tags = ['group']
handler.command = /^(promote)$/i

handler.admin = true
handler.group = true
handler.botAdmin = true

export default handler