let handler = async (m, { conn, text }) => {
    if (!text) throw 'Siapa yang mau di-unban? Gunakan tag atau nomor. Contoh: .unban @tag atau .unban 628xxxx'

    let who
    if (m.isGroup && m.mentionedJid.length) {
        who = m.mentionedJid[0]
    } else if (text.match(/^\d{5,}$/)) {
        who = text.replace(/\D/g, '') + '@s.whatsapp.net'
    } else {
        throw 'Format tidak valid! Gunakan tag atau nomor WhatsApp.'
    }

    let users = global.db.data.users
    if (!users[who]) throw 'User tidak ditemukan dalam database.'

    users[who].banned = false
    users[who].warning = 0

    conn.reply(m.chat, `Berhasil membuka blokir untuk @${who.split('@')[0]}`, m, {
        mentions: [who]
    })
}

handler.help = ['unban']
handler.tags = ['owner']
handler.command = /^unban(user)?$/i
handler.rowner = true

export default handler