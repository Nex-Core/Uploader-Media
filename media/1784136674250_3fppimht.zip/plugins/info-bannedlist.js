let handler = async (m, { jid, conn, usedPrefix }) => {
    let chats = Object.entries(global.db.data.chats).filter(chat => chat[1].isBanned);
    let users = Object.entries(global.db.data.users).filter(user => user[1].banned);

    let chatList = chats.length ? chats.map(([jid], i) => `
${i + 1}. 💬 ${conn.getName(jid) || 'Unknown'}
📍 ${jid}
`.trim()).join('\n') : 'Tidak ada chat yang di banned.';

    let userList = users.length ? users.map(([jid], i) => `
${i + 1}. 👤 Name: ${conn.getName(jid) || 'Unknown'}
📧 Number: ${jid.replace('@s.whatsapp.net', '')}
`.trim()).join('\n') : 'Tidak ada user yang di banned.';

    m.reply(`
🔒 *Daftar Chat Terbanned*
📊 Total: ${chats.length} Chat
${chatList}
────────────────

🚫 *Daftar User Terbanned*
📊 Total: ${users.length} User
${userList}
────────────────
`.trim());
}
handler.help = ['bannedlist'];
handler.tags = ['info'];
handler.command = /^listban(ned)?|ban(ned)?list|daftarban(ned)?$/i;
export default handler;