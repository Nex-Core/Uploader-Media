let handler = async(m, { text, conn, isOwner, usedPrefix, command }) => {
// if (!isOwner) return m.reply('fitur ini masih dalam proses')
  conn.airdrop = conn.airdrop || {}
  let airdrop = conn.airdrop['120363422904223539@g.us']
  let users = global.db.data.users[m.sender]
  let fkontak = {
	"key": {
    "participants":"0@s.whatsapp.net",
		"remoteJid": "status@broadcast",
		"fromMe": false,
		"id": "Halo"
	},
	"message": {
		"contactMessage": {
			"vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
		}
	},
	"participant": "0@s.whatsapp.net"
}

  if (airdrop) {
     let msg = airdrop.msg
     if (airdrop.users.includes(m.sender)) return m.reply(`❕Kamu sudah mengambil hadiah ini, Tunggu *🎁 AirDrop* Selanjutnya yang akan jatuh`)
     if (airdrop.users.length > 10) return m.reply(`*Yahh Kamu kehabisan AirDrop nya :/*`)
     if (command == 'buka' && !m.quoted || !m.quoted.fromMe || !m.quoted.isBaileys || !m.text || !/Ketik.*buka/i.test(m.quoted.text)) return conn.reply(m.chat, `Balas pesan ini!`, msg, { contextInfo: { mentionedJid: [m.sender] }})
     let eris = Math.floor(Math.random() * 30000000);
     let exp = Math.floor(Math.random() * 130000);
     let dm = Math.floor(Math.random() * 40);
     let boxs = Math.floor(Math.random() * 60);
     let cap = `*[ 🎁🎉 Kamu Telah Membuka AirDrop ]*

\`AirDrop-ID:\` ${airdrop.id}

*Hadiah AirDrop:*
* *💵 Money:* ${eris.toLocaleString()}
* *🧪 Exp:* ${exp.toLocaleString()}
* *💎 Diamond:* ${dm}
* *📦 Boxs:* ${boxs}

\`Setiap user hadiahnya berbeda-beda\``.trim()
     users.eris += eris * 1
     users.exp += exp * 1
     users.diamond += dm * 1
     users.boxs += boxs * 1
     users.rock += 1 *1
     airdrop.users.push(m.sender)
     await conn.sendMessage(m.chat, {
         text: cap,
         contextInfo: {
           mentionedJid: [m.sender],
           externalAdReply: {
             showAdAttribution: false,
             title: `[🎉🎀 Open AirDrop ]`,
             body: '',
             thumbnailUrl: 'https://telegra.ph/file/2481af9d807753ed42fd8.jpg', 
             sourceUrl: '',
             mediaType: 1,
             renderLargerThumbnail: true
             }}}, { quoted: fkontak });
    if (airdrop.users >= 10) {
    conn.sendMessage('120363422904223539@g.us', { delete: { remoteJid: '120363422904223539@g.us', fromMe: true, id: msg.key.id, participant: msg.key.participant }})
    conn.reply(m.chat, `*🎁AirDrop* telah habis, Maksimum 10 player yang mendapatnya`, floc)
         delete conn.airdrop['120363422904223539@g.us']
        }
      }
}
handler.command = /^(buka)/i

export default handler