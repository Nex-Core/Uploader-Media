import YouTubeScraper from '../scraper/savetube.js'
import axios from 'axios'

const sent = new Set()

let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) return m.reply(`EX: \n${usedPrefix + command} https://youtu.be/xxxxxxx`)

  const url = args[0]
  const ytId = url.match(/(?:youtube\.com\/(?:watch\?v=|shorts\/)|youtu\.be\/|music\.youtube\.com\/watch\?v=)([a-zA-Z0-9_-]{11})/)?.[1]
  if (!ytId) return m.reply("Link YouTube tidak valid")

  if (sent.has(m.key.id)) return
  sent.add(m.key.id)

  await conn.sendMessage(m.chat, { react: { text: '☆', key: m.key } })

  try {
    const scraper = new YouTubeScraper()
    const audio = await scraper.download(url, '320', 'audio')

    const title = audio.title

    await conn.sendMessage(m.chat, { react: { text: '🎵', key: m.key } })

    const response = await axios.get(audio.url, { responseType: 'arraybuffer' })
    const audioBuffer = Buffer.from(response.data)

    await conn.sendMessage(m.chat, {
      audio: audioBuffer,
      mimetype: 'audio/mpeg',
      fileName: `${title}.mp3`
    }, { quoted: floc })

  } catch (e) {
    m.reply(`Terjadi kesalahan\n> ${e.message || e}`)
  }

  setTimeout(() => sent.delete(m.key.id), 30000)
}

handler.command = /^(ytmp3|yta)$/i
handler.tags = ['downloader']
handler.help = ['ytmp3'].map(v => v + ' <url>')
handler.limit = 2
handler.register = true

export default handler