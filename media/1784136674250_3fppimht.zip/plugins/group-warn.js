let handler = async (m, { conn, args }) => {
    let mention;

    if (m.quoted) {
        mention = m.quoted.sender;
    } else if (args[0]) {
        mention = m.mentionedJid && m.mentionedJid[0] || conn.parseMention(args[0]) || (args[0].replace(/[@.+-]/g, '').trim() + '@s.whatsapp.net');
    }

    if (!mention) throw '❔ Tag atau reply salah satu user yang mau di-warn.';

    if (!(mention in global.db.data.users)) throw '⚠️ User tidak terdaftar dalam DATABASE!';

    let user = global.db.data.users[mention];

    if (!user.warn2) user.warn2 = 0;

    user.warn2 += 1;

    if (user.warn2 >= 3) {
        m.reply(`⛔ User @${mention.split('@')[0]} sudah menerima 3× warn dan akan dikeluarkan dari grup!`, null, { mentions: [mention] });
        await conn.groupParticipantsUpdate(m.chat, [mention], 'remove');
        user.warn2 = 0;
    } else {
        m.reply(`⚠️ User @${mention.split('@')[0]} telah di-warn. Sekarang memiliki *${user.warn2}/3* warn.`, null, { mentions: [mention] });
    }
}

handler.help = ['warn @mention/reply']
handler.tags = ['group']
handler.command = /^warn(user)?$/i
handler.group = true
handler.admin = true
handler.botAdmin = true

export default handler;