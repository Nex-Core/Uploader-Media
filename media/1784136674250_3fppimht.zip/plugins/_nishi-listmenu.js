const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = (await import('baileys')).default

let handler = async (m, { conn, usedPrefix, command }) => {
    const namae = 'Anu'

    const data = {
        title: "Menu",
        sections: [
            {
                title: "Nishikigi Chisato",
                rows: [{ title: "Lihat semua menu", description: "Klik untuk melihat semua menu yang tersedia", id: '.allmenu' }]
            },
            {
                title: "",
                rows: [{ title: "Hubungi owner bot", description: "Klik untuk nomor owner", id: '.owner' }]
            },
            {
                title: "",
                rows: [{ title: "Harga Sewa", description: "Klik untuk melihat harga sewa Nishikigi Chisato", id: '.sewa' }]
            },
            {
                title: "",
                rows: [{ title: "Peraturan", description: "Klik untuk melihat peraturan kami", id: '.rules' }]
            },
            {
                title: "🗃️ Fitur Tersedia",
                rows: [{ title: "Menu Ai", description: "Klik untuk melihat menu ai", id: '.menuai' }]
            },
            {
                title: "",
                rows: [{ title: "Menu Audio", description: "Klik untuk melihat menu audio", id: '.menuaudio' }]
            },
            {
                title: "",
                rows: [{ title: "Menu Clan", description: "Klik untuk melihat menu clan", id: '.menuclan' }]
            },
            {
                title: "",
                rows: [{ title: "Menu Download", description: "Klik untuk melihat menu download", id: '.menudownloader' }]
            },
            {
                title: "",
                rows: [{ title: "Menu Ephoto", description: "Klik untuk melihat menu ephoto", id: '.menuephoto' }]
            },
            {
                title: "",
                rows: [{ title: "Menu Fun", description: "Klik untuk melihat menu fun", id: '.menufun' }]
            },
            {
                title: "",
                rows: [{ title: "Menu Game", description: "Klik untuk melihat menu game", id: '.menugame' }]
            },
            {
                title: "",
                rows: [{ title: "Menu Group", description: "Klik untuk melihat menu group", id: '.menugroup' }]
            },
            {
                title: "",
                rows: [{ title: "Menu Info", description: "Klik untuk melihat menu info", id: '.menuinfo' }]
            },
            {
                title: "",
                rows: [{ title: "Menu Internet", description: "Klik untuk melihat menu internet", id: '.menuinternet' }]
            },
            {
                title: "",
                rows: [{ title: "Menu Main", description: "Klik untuk melihat menu main", id: '.menumain' }]
            },
            {
                title: "",
                rows: [{ title: "Menu Maker", description: "Klik untuk melihat menu maker", id: '.menumaker' }]
            },
            {
                title: "",
                rows: [{ title: "Menu Nsfw", description: "Klik untuk melihat menu nsfw", id: '.menunsfw' }]
            },
            {
                title: "",
                rows: [{ title: "Menu Owner", description: "*Khusus Rain..*", id: '.menuowner' }]
            },
            {
                title: "",
                rows: [{ title: "Menu Quotes", description: "Klik untuk melihat menu quotes", id: '.menuquotes' }]
            },
            {
                title: "",
                rows: [{ title: "Menu Random", description: "Klik untuk melihat menu random", id: '.menurandom' }]
            },
            {
                title: "",
                rows: [{ title: "Menu RPG", description: "Klik untuk melihat menu RPG", id: '.menurpg' }]
            },
            {
                title: "",
                rows: [{ title: "Menu Search", description: "Klik untuk melihat menu search", id: '.menusearch' }]
            },
            {
                title: "",
                rows: [{ title: "Menu Sticker", description: "Klik untuk melihat menu sticker", id: '.menusticker' }]
            },
            {
                title: "",
                rows: [{ title: "Menu Store", description: "Klik untuk melihat menu store", id: '.menustore' }]
            },
            {
                title: "",
                rows: [{ title: "Menu Tools", description: "Klik untuk melihat menu tools", id: '.menutools' }]
            },
            {
                title: "",
                rows: [{ title: "Menu User", description: "Klik untuk melihat menu user", id: '.menuuser' }]
            },
            {
                title: "",
                rows: [{ title: "Menu Voice", description: "Klik untuk melihat menu voice", id: '.menuvoice' }]
            }
        ]
    };

    let msgs = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                "messageContextInfo": {
                    "deviceListMetadata": {},
                    "deviceListMetadataVersion": 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: `◆────⊚ « _*INFO*_ » ⊚─────
│֎〔 *Nama Bot:* Nishikigi Chisato
│֎〔 *TotalFitur:* 900+
│֎〔 *Lengkapnya:* Cek Profilku
◆──────────────────
◇──⊚ « _*OWNER*_ » ⊚──
│֎〔 *Creator:* Rain...
◇─────────────

*_Hai, Saya Nishikigi Chisato, yang di dirikan oleh Rain.., untuk membantu kesibukan dan kebutuhan anda_*🍂`
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: 'Nishi Chisato'
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        title: 'Nishi Chisato\n',
                        subtitle: "",
                        hasMediaAttachment: false
                    }),
                    contextInfo: {
                        forwardingScore: 9999,
                        isForwarded: false,
                        mentionedJid: conn.parseMention(m.sender)
                    },
                    externalAdReply: {
                        showAdAttribution: true,
                        renderLargerThumbnail: false,
                        mediaType: 1
                    },
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [{
                            "name": "single_select",
                            "buttonParamsJson": JSON.stringify(data)
                        }],
                    })
                })
            }
        }
    }, {})

    conn.relayMessage(m.chat, msgs.message, {})
}

handler.help = ['listmenu']
handler.tags = ['main']
handler.command = /^(listmenu|menulist)$/i
handler.register = true;
handler.exp = 3;
export default handler

/*backup
import { promises } from 'fs'
import { join } from 'path'
import { xpRange } from '../lib/levelling.js'
import moment from 'moment-timezone'
import os from 'os'
import fs from 'fs'
import fetch from 'node-fetch'
const { generateWAMessageFromContent, proto } = (await import('baileys')).default

const defaultMenu = {
  before: `*Konnichiwa %name* (๑>◡<๑)
私は *${global.namebot}* です。ステッカーの作成、コンテンツのダウンロード、AI などをお手伝いする WhatsApp ボットです。🍁

┈──┈─── \`⌜ ${global.namebot} ⌟\` ───┈──┈

\`〔 DASHBOARD 〕\`
> *Name:* %name
> *Mode:* _%mode_
> *User:* %totalreg

\`〔 SOCIAL MEDIA 〕\`
> *WhatsApp:* ${global.pushowner}
> *Creator:* ${global.nameown1}
> *TikTok:* ${global.tt}

\`〔 INFO BOT 〕\`
> *Nama Bot:* ${global.namebot}
> *Baileys:* Baileys-MD
> *Prefix:* [.]
> *Platform:* Linux
> *Versi:* ${global.version}

ご利用いただきありがとうございます *${global.namebot}* Hihihi~! (๑˃̵ᴗ˂̵)و 

*Click Here --->* %readmore
`.trimStart(),
  header: `╔┈┈┈┈ ⌜ _*%category*_ ⌟ ┈┈┈┈┈✧
╎╭─────────────────✧`,
  body: `\r\r\r╎│•ぎ _%cmd_`,
  footer: '╎╰─────────────────✧',
  after: global.wm,
}
let handler = async (m, { conn, usedPrefix: _p, __dirname, args, command}) => {
let tags = {
'nishimenu': 'Chisato Menu',
}
 
  try {
  	// DEFAULT MENU
      let dash = global.dashmenu
  	let m1 = global.dmenut
      let m2 = global.dmenub
      let m3 = global.dmenuf
      let m4 = global.dmenub2
      
      // COMMAND MENU
      let cc = global.cmenut
      let c1 = global.cmenuh
      let c2 = global.cmenub
      let c3 = global.cmenuf
      let c4 = global.cmenua
      
      // LOGO L P
      let lprem = global.lopr
      let llim = global.lolm
      let tag = `@${m.sender.split('@')[0]}`
    
    //-----------TIME---------
    let ucpn = `${ucapan()}`
    let d = new Date(new Date + 3600000)
    let locale = 'id'
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
    let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
    let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
    // d.getTimeZoneOffset()
    // Offset -420 is 18.00
    // Offset    0 is  0.00
    // Offset  420 is  7.00
    let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
    let dateIslamic = Intl.DateTimeFormat(locale + '-TN-u-ca-islamic', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }).format(d)
    let time = d.toLocaleTimeString(locale, {
      hour: 'numeric',
      minute: 'numeric',
      second: 'numeric'
    })
    let _uptime = process.uptime() * 1000
    let _muptime
    if (process.send) {
      process.send('uptime')
      _muptime = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }
    let muptime = clockString(_muptime)
    let uptime = clockString(_uptime)
    let _mpt
    if (process.send) {
      process.send('uptime')
      _mpt = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }
    let mpt = clockString(_mpt)
    let usrs = db.data.users[m.sender]
      
    let wib = moment.tz('Asia/Jakarta').format('HH:mm:ss')
    let wibh = moment.tz('Asia/Jakarta').format('HH')
    let wibm = moment.tz('Asia/Jakarta').format('mm')
    let wibs = moment.tz('Asia/Jakarta').format('ss')
    let wit = moment.tz('Asia/Jayapura').format('HH:mm:ss')
    let wita = moment.tz('Asia/Makassar').format('HH:mm:ss')
    let wktuwib = `${wibh} H ${wibm} M ${wibs} S`
 
    let mode = global.opts['self'] ? 'Private' : 'Publik'
    let _package = JSON.parse(await promises.readFile(join(__dirname, '../package.json')).catch(_ => ({}))) || {}
    let { age, exp, limit, level, role, registered, eris} = global.db.data.users[m.sender]
    let { min, xp, max } = xpRange(level, global.multiplier)
    let name = await conn.getName(m.sender)
    let premium = global.db.data.users[m.sender].premiumTime
    let prems = `${premium > 0 ? 'Premium': 'Free'}`
    let platform = os.platform()
    
    //---------------------
    
    let totalreg = Object.keys(global.db.data.users).length
    let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length
    let help = Object.values(global.plugins).filter(plugin => !plugin.disabled).map(plugin => {
      return {
        help: Array.isArray(plugin.tags) ? plugin.help : [plugin.help],
        tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
        prefix: 'customPrefix' in plugin,
        limit: plugin.limit,
        premium: plugin.premium,
        enabled: !plugin.disabled,
      }
    })
    let groups = {}
    for (let tag in tags) {
      groups[tag] = []
      for (let plugin of help)
        if (plugin.tags && plugin.tags.includes(tag))
          if (plugin.help) groups[tag].push(plugin)
          }
    conn.menu = conn.menu ? conn.menu : {}
    let before = conn.menu.before || defaultMenu.before
    let header = conn.menu.header || defaultMenu.header
    let body = conn.menu.body || defaultMenu.body
    let footer = conn.menu.footer || defaultMenu.footer
    let after = conn.menu.after || (conn.user.jid == global.conn.user.jid ? '' : `Powered by https://wa.me/${global.conn.user.jid.split`@`[0]}`) + defaultMenu.after
    let _text = [
      before,
      ...Object.keys(tags).map(tag => {
        return header.replace(/%category/g, tags[tag]) + '\n' + [
          ...help.filter(menu => menu.tags && menu.tags.includes(tag) && menu.help).map(menu => {
            return menu.help.map(help => {
              return body.replace(/%cmd/g, menu.prefix ? help : '%_p' + help)
                .replace(/%islimit/g, menu.limit ? llim : '')
                .replace(/%isPremium/g, menu.premium ? lprem : '')
                .trim()
            }).join('\n')
          }),
          footer
        ].join('\n')
      }),
      after
    ].join('\n')
    let text = typeof conn.menu == 'string' ? conn.menu : typeof conn.menu == 'object' ? _text : ''
    let replace = {
      '%': '%',
      p: uptime, muptime,
      me: conn.getName(conn.user.jid),
      npmname: _package.name,
      npmdesc: _package.description,
      version: _package.version,
      exp: exp - min,
      maxexp: xp,
      totalexp: exp,
      xp4levelup: max - exp,
      github: _package.homepage ? _package.homepage.url || _package.homepage : '[unknown github url]',
      tag, dash,m1,m2,m3,m4,cc, c1, c2, c3, c4,lprem,llim,
      ucpn,platform, wib, mode, _p, eris, age, tag, name, prems, level, limit, name, weton, week, date, dateIslamic, time, totalreg, rtotalreg, role,
      readmore: readMore
    }
    text = text.replace(new RegExp(`%(${Object.keys(replace).sort((a, b) => b.length - a.length).join`|`})`, 'g'), (_, name) => '' + replace[name])
    
  let fkon = { key: { fromMe: false, participant: `${m.sender.split`@`[0]}@s.whatsapp.net`, ...(m.chat ? { remoteJid: '16504228206@s.whatsapp.net' } : {}) }, message: { contactMessage: { displayName: `${name}`, vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;a,;;;\nFN:${name}\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`}}}

 conn.sendMessage(m.chat, {
  text: text,
  contextInfo: {
  externalAdReply: {
  title: global.namebot,
  body: global.author,
  thumbnailUrl: global.thumb,
  sourceUrl: global.myweb,
  mediaType: 1,
  renderLargerThumbnail: true
  }}}, { quoted: floc })

  } catch (e) {
    conn.reply(m.chat, 'Maaf, menu sedang error', m)
    throw e
  }
}
handler.help = ['listmenu']
handler.tags = ['main']
handler.command = /^(menulist|listmenu|\?)$/i

handler.register = false
handler.exp = 3

export default handler

//----------- FUNCTION -------

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

function clockString(ms) {
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [h, ' H ', m, ' M ', s, ' S '].map(v => v.toString().padStart(2, 0)).join('')
}
function clockStringP(ms) {
  let ye = isNaN(ms) ? '--' : Math.floor(ms / 31104000000) % 10
  let mo = isNaN(ms) ? '--' : Math.floor(ms / 2592000000) % 12
  let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000) % 30
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [ye, ' *Years 🗓️*\n',  mo, ' *Month 🌙*\n', d, ' *Days ☀️*\n', h, ' *Hours 🕐*\n', m, ' *Minute ⏰*\n', s, ' *Second ⏱️*'].map(v => v.toString().padStart(2, 0)).join('')
}
function ucapan() {
  const time = moment.tz('Asia/Jakarta').format('HH')
  let res = "Kok Belum Tidur Kak? 🥱"
  if (time >= 4) {
    res = "Pagi Kak 🌄"
  }
  if (time >= 10) {
    res = "Siang Kak ☀️"
  }
  if (time >= 15) {
    res = "Sore Kak 🌇"
  }
  if (time >= 18) {
    res = "Malam Kak 🌙"
  }
  return res
}*/