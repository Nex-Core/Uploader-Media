let handler = async(m, { text, conn, usedPrefix, command, isOwner, participants }) => {
  conn.airdrop = conn.airdrop || {}
  let airdrop = conn.airdrop['120363422904223539@g.us']
  let users = global.db.data.users[m.sender]
  let allUser = Object.entries(global.db.data.users)
  if (!airdrop) {
     let id = Math.floor(Math.random() * 80000000000);
     let capOwn = `Sukses Menurunkan *🎁Airdrop*`
     conn.reply(m.chat, capOwn, floc, { contextInfo: { mentionedJid: [m.sender] }})
     let capAir = `🎊🎁 AirDrop turun nih!, dapatkan hadiah spesial dari AirDrop, AirDrop akan hilang/expired dalam 5 menit\n\nKetik: *!buka* untuk membukanya, dan reply pesan ini\n\n*-ID:* ${id}`
     allUser.map(([user, data], i) => (Number(data.rock = 0)))
 let msg = await conn.sendMessage('120363422904223539@g.us', {
         text: capAir,
         contextInfo: {
           mentionedJid: participants.map(a => a.id),
           externalAdReply: {
             showAdAttribution: false,
             title: `[ 🎁 𝖠𝗂𝗋𝖣𝗋𝗈𝗉 ]`,
             body: '',
             thumbnailUrl: 'https://telegra.ph/file/c27eee40140de58ffdd24.png', 
             sourceUrl: '',
             mediaType: 1,
             renderLargerThumbnail: true
             }}}, { quoted: floc });
     msg
     conn.airdrop['120363422904223539@g.us'] = {
           id: id,
           msg: msg,
           users: []
        }
    setTimeout(() => {
        conn.sendMessage('120363422904223539@g.us', { delete: { remoteJid: '120363422904223539@g.us', fromMe: true, id: msg.key.id, participant: msg.key.participant }})
        conn.reply('6287785751981@s.whatsapp.net', 'AirDrop udah selesai', floc)
            delete conn.airdrop['120363422904223539@g.us']
      }, 5 * 60 * 1000)
   } else return m.reply(`AirDrop sudah turun sensei`)
}
handler.command = /^(airdrop2)/i
handler.owner = true

export default handler