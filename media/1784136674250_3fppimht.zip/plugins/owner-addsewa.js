let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0] || isNaN(args[0])) throw `Masukkan angka mewakili jumlah hari!\n*Contoh: ${usedPrefix + command} 30*`

    let who
    if (m.isGroup) who = args[1] ? args[1] : m.chat
    else who = args[1]

    let daysToAdd = parseInt(args[0])
    let now = Date.now()
    let msToAdd = daysToAdd * 86400000

    if (!global.db.data.chats[who]) global.db.data.chats[who] = {}
    if (!global.db.data.chats[who].expired) global.db.data.chats[who].expired = 0

    if (now < global.db.data.chats[who].expired) {
        global.db.data.chats[who].expired += msToAdd
    } else {
        global.db.data.chats[who].expired = now + msToAdd
    }

    let sisa = global.db.data.chats[who].expired - now
    conn.reply(m.chat, `Berhasil memperpanjang masa sewa grup selama ${daysToAdd} hari.\n\nHitung mundur: ${msToDate(sisa)}`, m)
}
handler.help = ['addsewa']
handler.tags = ['owner']
handler.command = /^(addsewa)$/i
handler.rowner = true
handler.group = true

export default handler

function msToDate(ms) {
    let days = Math.floor(ms / (24 * 60 * 60 * 1000))
    let daysms = ms % (24 * 60 * 60 * 1000)
    let hours = Math.floor(daysms / (60 * 60 * 1000))
    let hoursms = ms % (60 * 60 * 1000)
    let minutes = Math.floor(hoursms / (60 * 1000))
    return `${days} Hari ${hours} Jam ${minutes} Menit`
}