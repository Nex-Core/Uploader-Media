let handler = async (m, { conn, args, participants }) => {
    const petTypes = ['kucing', 'anjing', 'kuda', 'kyubi', 'naga'];
    const petEmojis = {
        'kucing': '🐈',
        'anjing': '🐕',
        'kuda': '🐎',
        'kyubi': '🦊',
        'naga': '🐉'
    };
    
    const petType = args[0] ? args[0].toLowerCase() : '';

    if (!petTypes.includes(petType)) {  
        return m.reply(
            `🐾 *PILIH PET KAMU*\n\n` +
            petTypes.map(pet => `${petEmojis[pet]} ${capitalize(pet)}`).join('\n') +
            `\n\n*Contoh:* .battlepet kucing`
        );  
    }  

    if (!global.db.data.users[m.sender][petType] || global.db.data.users[m.sender][petType] < 1) {  
        return m.reply(`⚠️ *Kamu belum memiliki pet ${petEmojis[petType]} ${capitalize(petType)}!*\n\nBeli dulu di *.petshop*`);  
    }  

    const userCooldown = global.db.data.users[m.sender].battleCooldown || 0;  
    const now = new Date().getTime();  
    const cooldownTime = 15 * 60 * 1000;

    if (now - userCooldown < cooldownTime) {  
        const remainingTime = Math.ceil((cooldownTime - (now - userCooldown)) / 1000 / 60);  
        return m.reply(`⏳ *Tunggu ${remainingTime} menit lagi sebelum bisa bertarung lagi!*`);  
    }  

    await handlePetBattle(m, conn, participants, petType, petEmojis);
};

async function handlePetBattle(m, conn, participants, petType, petEmojis) {
    const userPetLevel = global.db.data.users[m.sender][petType];
    conn.fightArena = conn.fightArena || {};

    if (conn.fightArena[m.sender]) {  
        return m.reply(`⚔️ *Arena pertarungan kamu sedang digunakan.*`);  
    }

    try {
        const petTypes = ['kucing', 'anjing', 'kuda', 'kyubi', 'naga'];
        let users = participants.map(u => u.id).filter(id => {
            if (id === m.sender || !global.db.data.users?.[id]) return false;
            return global.db.data.users[id][petType] >= 1;
        });

        let opponent;
        let opponentPetLevel;
        let opponentPetType = petType;
        let isNPC = false;

        if (users.length === 0) {
            users = participants.map(u => u.id).filter(id => {
                if (id === m.sender || !global.db.data.users?.[id]) return false;
                return petTypes.some(pet => global.db.data.users[id][pet] >= 1);
            });

            if (users.length === 0) {
                isNPC = true;
                opponent = 'NPC';
                opponentPetLevel = Math.max(1, userPetLevel + randomBetween(-2, 2));
                opponentPetType = petTypes[randomBetween(0, petTypes.length - 1)];
            } else {
                opponent = users[Math.floor(Math.random() * users.length)];
                opponentPetType = petTypes.find(pet => global.db.data.users[opponent][pet] >= 1) || petType;
                opponentPetLevel = global.db.data.users[opponent][opponentPetType];
            }
        } else {
            opponent = users[Math.floor(Math.random() * users.length)];
            opponentPetLevel = global.db.data.users[opponent][petType];
        }

        conn.fightArena[m.sender] = true;

        let opponentTag = isNPC ? `*Pet Liar*` : `@${opponent.split('@')[0]}`;
        let userPetEmoji = petEmojis[petType];
        let opponentPetEmoji = petEmojis[opponentPetType];

        m.reply(
            `⚔️ *BATTLE DIMULAI!*\n\n` +
            `${userPetEmoji} *${capitalize(petType)}* milik @${m.sender.split('@')[0]} (Level ${userPetLevel})\n` +
            `     VS\n` +
            `${opponentPetEmoji} *${capitalize(opponentPetType)}* milik ${opponentTag} (Level ${opponentPetLevel})!\n\n` +
            `⏳ Pertarungan sedang berlangsung...`,
            null, { mentions: isNPC ? [m.sender] : [m.sender, opponent] }
        );

        let chances = [];  
        for (let i = 0; i < userPetLevel; i++) chances.push('player');  
        for (let i = 0; i < opponentPetLevel; i++) chances.push('opponent');  

        let playerPoints = 0;  
        let opponentPoints = 0;  

        for (let i = 0; i < 10; i++) {  
            let winner = chances[randomBetween(0, chances.length - 1)];  
            if (winner == 'player') playerPoints += 1;  
            else opponentPoints += 1;  
        }  

        let resultMessage;  
        if (playerPoints > opponentPoints) {  
            let reward = (playerPoints - opponentPoints) * 20000;  
            global.db.data.users[m.sender].eris = global.db.data.users[m.sender].eris || 0;
            global.db.data.users[m.sender].tiketcoin = global.db.data.users[m.sender].tiketcoin || 0;
            global.db.data.users[m.sender].eris += reward;  
            global.db.data.users[m.sender].tiketcoin += 1;  
            
            resultMessage = 
                `🎉 *KAMU MENANG!*\n\n` +
                `${userPetEmoji} *${capitalize(petType)}* Level ${userPetLevel} ` +
                `mengalahkan ${opponentPetEmoji} *${capitalize(opponentPetType)}* ${opponentTag} (Level ${opponentPetLevel})!\n\n` +
                `📊 *Skor Akhir:* ${playerPoints * 10} - ${opponentPoints * 10}\n\n` +
                `💰 *Hadiah:*\n` +
                `• Rp ${reward.toLocaleString()}\n` +
                `• 🎫 1 Tiket Coin`;
        } else if (playerPoints < opponentPoints) {  
            let penalty = (opponentPoints - playerPoints) * 100000;  
            global.db.data.users[m.sender].eris = global.db.data.users[m.sender].eris || 0;
            global.db.data.users[m.sender].tiketcoin = global.db.data.users[m.sender].tiketcoin || 0;
            global.db.data.users[m.sender].eris -= penalty;  
            global.db.data.users[m.sender].tiketcoin += 1;  
            
            resultMessage = 
                `😢 *KAMU KALAH!*\n\n` +
                `${userPetEmoji} *${capitalize(petType)}* Level ${userPetLevel} ` +
                `kalah dari ${opponentPetEmoji} *${capitalize(opponentPetType)}* ${opponentTag} (Level ${opponentPetLevel})\n\n` +
                `📊 *Skor Akhir:* ${playerPoints * 10} - ${opponentPoints * 10}\n\n` +
                `💸 *Denda:*\n` +
                `• Rp ${penalty.toLocaleString()}\n` +
                `• 🎫 1 Tiket Coin (Hadiah Hiburan)`;
        } else {  
            resultMessage = 
                `🤝 *SERI!*\n\n` +
                `${userPetEmoji} *${capitalize(petType)}* vs ${opponentPetEmoji} *${capitalize(opponentPetType)}*\n\n` +
                `📊 *Skor Akhir:* ${playerPoints * 10} - ${opponentPoints * 10}\n\n` +
                `Tidak ada hadiah atau denda.`;
        }  

        m.reply(resultMessage, null, { mentions: isNPC ? [] : [opponent, m.sender] });  

        global.db.data.users[m.sender].battleCooldown = new Date().getTime();  
        setTimeout(() => {
            m.reply(`🛌 *Pet ${userPetEmoji} ${capitalize(petType)} kamu sedang istirahat*\n⏳ Cooldown 15 menit sebelum battle lagi.`, null, { mentions: [m.sender] });
        }, 2000);

    } catch (error) {
        console.error('Battle error:', error);
        m.reply('❌ *Terjadi kesalahan saat battle!*\n\n' + error.message);
    } finally {
        delete conn.fightArena[m.sender];
    }
}

function randomBetween(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

handler.help = ['battlepet <nama_pet>'];
handler.tags = ['rpg'];
handler.command = /^battlepet$/i;
handler.limit = true;
handler.group = true;

export default handler;