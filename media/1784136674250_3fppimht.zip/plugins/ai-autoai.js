import fetch from 'node-fetch';

const sendToGemini = async (prompt) => {
    const apiKey = 'AIzaSyA04IprS-Sm4NSSkcsFjvM9mdeVMxohu0A';
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=${apiKey}`;
    
    const body = {
        contents: [
            {
                parts: [
                    { text: prompt }
                ]
            }
        ]
    };

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(body)
        });

        const data = await response.json();

        if (response.ok) {
            return data; 
        } else {
            throw new Error(data.error.message || 'Request failed');
        }
    } catch (error) {
        console.error('Error:', error.message);
        return null;
    }
};

let handler = async (m, { conn, text }) => {
    conn.autoaiSession = conn.autoaiSession || {};

    if (!text) throw `*• Example:* .autoai *[on/off]*`;

    if (text === "on") {
        if (conn.autoaiSession[m.chat]) {
            clearTimeout(conn.autoaiSession[m.chat].timeout);
        }
        conn.autoaiSession[m.chat] = { user: m.sender, messages: [], timeout: setTimeout(() => delete conn.autoaiSession[m.chat], 3600000) }; // 1 hour timeout
        m.reply("[ ✓ ] AutoAI session started.");
    } else if (text === "off") {
        if (conn.autoaiSession[m.chat]) {
            clearTimeout(conn.autoaiSession[m.chat].timeout);
            delete conn.autoaiSession[m.chat];
            m.reply("[ ✓ ] AutoAI session ended.");
        } else {
            m.reply("[ ✓ ] No active AutoAI session.");
        }
    }
};

// Middleware to process messages in an active session
handler.before = async (m, { conn }) => {
    conn.autoaiSession = conn.autoaiSession || {};
    if (!m.text || !conn.autoaiSession[m.chat]) return;
    if (/^[.\#!\/\\]/.test(m.text)) return;
    if (m.sender !== conn.autoaiSession[m.chat].user) return; // Only allow the session starter to interact

    await conn.sendMessage(m.chat, { react: { text: '⏱️', key: m.key } });

    try {
        const response = await sendToGemini(m.text);
        if (!response) {
            throw new Error('Failed to get a response from Gemini API.');
        }

        const candidates = response.candidates;
        let result = candidates && candidates.length > 0
            ? candidates[0].content.parts[0].text
            : 'No response received from the model.';

        result = result.replace(/\*\*/g, '*');
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        m.reply(result);

        conn.autoaiSession[m.chat].messages.push(m.text);
    } catch (error) {
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        m.reply('An error occurred while processing your request.');
        console.error(error);
    }
};

handler.command = ['autoai'];
handler.tags = ['ai'];
handler.help = ['autoai'].map(a => a + " <on/off>");
handler.premium = true;
handler.register = true;

export default handler;