import moment from 'moment-timezone'

const handler = async (m, { conn, text, isOwner }) => {
  let linkRegex = /chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})(?:\s+([0-9]{1,3}))?/i
  let [_, code, dayStr] = text.match(linkRegex) || []
  if (!code) return m.reply('❗ Link salah, say!\nContoh: .join <link> [hari]')

  let groupId = await conn.groupAcceptInvite(code)
  let groupMetadata = await conn.groupMetadata(groupId)
  let creator = groupMetadata.participants.find(p => p.admin === 'superadmin')
  let admins = groupMetadata.participants.filter(p => p.admin).length
  let members = groupMetadata.participants.length
  let groupName = groupMetadata.subject || '-'
  let groupCreate = groupMetadata.creation * 1000
  let createdAt = moment(groupCreate).tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')

  if (!dayStr) {
    let msg = `
⢀       ⣠⣶⣶⣆   
⣠⣤⣤⣤⣴⣿⣿⣯⣵⢟   
⢸⣟⣉⣉⣽⡿⠉⠛⠿⠿⠿⠃  
⠉⠉⣡⣾⠇₊ ׁ𖢷 ׄ ˚𝓐𝖽𝗈𝗋𝖻'𝓈 𝗌𝗐𝖾𝗍𝗍'𝔂𝅄 ᡣ𐭩  ࣪  
     🦢 ۫  ⑆ 𝗃𝗈𝗂𝗇 𝗌𝗎𝖼𝖼𝖾𝗌𝗌𝖿𝗎𝗅𝗅𝗒, 𝖽𝖺𝗋𝗅𝗂𝗇𝗀! ⑅᜔ ִ ۪۫
           	     
╰╼ ┈─ 🩰 ⠁◌  ˚𝗴𝗿𝗼𝘂𝗽 𝗶𝗻𝗳𝗼 ⠹ 𝅄 !

⤿ ִ  ׄᥴ⃘ᦱ 𝗇𝖺𝗆𝖾 ⠲ ${groupName}
⤿ ִ  ׄᥴ⃘ᦱ 𝖼𝗋𝖾𝖺𝗍𝖾𝖽 𝖺𝗍 ⠲ ${createdAt}
⤿ ִ  ׄᥴ⃘ᦱ 𝖼𝗋𝖾𝖺𝗍𝗈𝗋 ⠲ ${creator ? '@' + creator.id.split('@')[0] : '-'}
⤿ ִ  ׄᥴ⃘ᦱ 𝗀𝗋𝗈𝗎𝗉 𝗂𝖽 ⠲ ${groupId}
⤿ ִ  ׄᥴ⃘ᦱ 𝖺𝖽𝗆𝗂𝗇𝗌 ⠲ ${admins}
⤿ ִ  ׄᥴ⃘ᦱ 𝗆𝖾𝗆𝖻𝖾𝗋𝗌 ⠲ ${members}
⤿ ִ  ׄᥴ⃘ᦱ 𝖽𝗎𝗋𝖺𝗌𝗂 ⠲ ∞ (tanpa batas waktu)

               ׄ  ֵ  ━━━━━━━━━━━━━━━ ֵ  ׄׄ
            ˚ 𓊆˒˓ 🎀 ۫﹢ 𝗅𝗈𝗏𝖾 𝖻𝗒 Nishi chisato ! ♡. .⁺ ׅ

📮 *𝓝𝓸𝓽𝓮*: 
• 𝙱𝚘𝚝 𝚒𝚗𝚒 𝚝𝚒𝚍𝚊𝚔 𝚙𝚊𝚔𝚎 𝚜𝚎𝚠𝚊, 𝚋𝚎𝚋𝚊𝚜 𝚜𝚎𝚙𝚎𝚗𝚞𝚑𝚗𝚢𝚊~  
• 𝙺𝚎𝚝𝚒𝚔 *.menu* 𝚋𝚞𝚊𝚝 𝚕𝚒𝚑𝚊𝚝 𝚏𝚒𝚝𝚞𝚛 𝚋𝚘𝚝! 
• 𝙺𝚊𝚕𝚊𝚞 𝚊𝚍𝚊 𝚖𝚊𝚜𝚊𝚕𝚊𝚑, 𝚌𝚑𝚊𝚝 𝚘𝚠𝚗𝚎𝚛 𝚢𝚊~ 
• 𝙲𝚘𝚗𝚝𝚊𝚌𝚝 𝙾𝚠𝚗𝚎𝚛: wa.me/6283854025278
`.trim()

    let thumb = 'https://telegra.ph/file/265c672094dfa87caea19.jpg'
    try {
      thumb = await conn.profilePictureUrl(groupId, 'image')
    } catch (e) {}

    await conn.sendMessage(groupId, {
      text: msg,
      mentions: creator ? [creator.id] : [],
      contextInfo: {
        mentionedJid: creator ? [creator.id] : [],
        externalAdReply: {
          title: 'Nishi - BOT JOIN',
          body: groupName,
          thumbnailUrl: thumb,
          mediaType: 1,
          renderLargerThumbnail: false,
          sourceUrl: 'https://wa.me/6283854025278'
        }
      }
    }, { quoted: floc })
    return
  }

  let days = isNumber(dayStr) ? parseInt(dayStr) : (isOwner ? 0 : 3)
  days = Math.max(1, Math.min(days, 999))

  let now = moment().tz('Asia/Jakarta')
  let expiredTime = moment(now).add(days, 'days')

  let timeSewa = now.format('dddd, DD MMMM YYYY HH:mm:ss')
  let timeEnd = expiredTime.format('dddd, DD MMMM YYYY HH:mm:ss')

  let chats = global.db.data.chats[groupId]
  if (!chats) chats = global.db.data.chats[groupId] = {}
  chats.expired = +expiredTime

  let msg = `
⢀       ⣠⣶⣶⣆   
⣠⣤⣤⣤⣴⣿⣿⣯⣵⢟   
⢸⣟⣉⣉⣽⡿⠉⠛⠿⠿⠿⠃  
⠉⠉⣡⣾⠇₊ ׁ𖢷 ׄ ˚𝓐𝖽𝗈𝗋𝖻'𝓈 𝗌𝗐𝖾𝗍𝗍'𝔂𝅄 ᡣ𐭩  ࣪  
      🦢 ۫  ⑆ 𝗃𝗈𝗂𝗇 𝗌𝗎𝖼𝖼𝖾𝗌𝗌𝖿𝗎𝗅𝗅𝗒, 𝖽𝖺𝗋𝗅𝗂𝗇𝗀! ⑅᜔ ִ ۪۫
           	     
╰╼ ┈─ 🩰 ⠁◌  ˚𝗴𝗿𝗼𝘂𝗽 𝗶𝗻𝗳𝗼 ⠹ 𝅄 !

⤿ ִ  ׄᥴ⃘ᦱ 𝗇𝖺𝗆𝖾 ⠲ ${groupName}
⤿ ִ  ׄᥴ⃘ᦱ 𝖼𝗋𝖾𝖺𝗍𝖾𝖽 𝖺𝗍 ⠲ ${createdAt}
⤿ ִ  ׄᥴ⃘ᦱ 𝖼𝗋𝖾𝖺𝗍𝗈𝗋 ⠲ ${creator ? '@' + creator.id.split('@')[0] : '-'}
⤿ ִ  ׄᥴ⃘ᦱ 𝗀𝗋𝗈𝗎𝗉 𝗂𝖽 ⠲ ${groupId}
⤿ ִ  ׄᥴ⃘ᦱ 𝖺𝖽𝗆𝗂𝗇𝗌 ⠲ ${admins}
⤿ ִ  ׄᥴ⃘ᦱ 𝗆𝖾𝗆𝖻𝖾𝗋𝗌 ⠲ ${members}
⤿ ִ  ׄᥴ⃘ᦱ 𝖽𝗎𝗋𝖺𝗌𝗂 ⠲ ${days} 𝗁𝖺𝗋𝗂
⤿ ִ  ׄᥴ⃘ᦱ 𝗌𝗍𝖺𝗋𝗍 ⠲ ${timeSewa}
⤿ ִ  ׄᥴ⃘ᦱ 𝖾𝗇𝖽 ⠲ ${timeEnd}

               ׄ  ֵ  ━━━━━━━━━━━━━━━ ֵ  ׄׄ
            ˚ 𓊆˒˓ 🎀 ۫﹢ 𝗅𝗈𝗏𝖾 𝖻𝗒 Nishi chisato ! ♡. .⁺ ׅ

📮 *𝓝𝓸𝓽𝓮*: 
• 𝙱𝚘𝚝 𝚜𝚎𝚠𝚊 𝚐𝚊𝚔 𝚋𝚒𝚜𝚊 𝚍𝚒𝚛𝚎𝚏𝚞𝚗𝚍, 𝚢𝚊 𝚜𝚊𝚢~ 
• 𝙺𝚎𝚝𝚒𝚔 *.menu* 𝚋𝚞𝚊𝚝 𝚕𝚒𝚑𝚊𝚝 𝚏𝚒𝚝𝚞𝚛 𝚋𝚘𝚝! 
• 𝙲𝚎𝚔 𝚜𝚒𝚜𝚊 𝚠𝚊𝚔𝚝𝚞 𝚜𝚎𝚠𝚊 𝚍𝚎𝚗𝚐𝚊𝚗 *.ceksewa* 
• 𝙺𝚊𝚕𝚊𝚞 𝚊𝚍𝚊 𝚖𝚊𝚜𝚊𝚕𝚊𝚑, 𝚌𝚑𝚊𝚝 𝚘𝚠𝚗𝚎𝚛 𝚢𝚊~ 
• 𝙿𝚎𝚛𝚙𝚊𝚗𝚓𝚊𝚗𝚐 𝚜𝚎𝚠𝚊? 𝙷𝚞𝚋𝚞𝚗𝚐𝚒 𝚘𝚠𝚗𝚎𝚛: wa.me/6283854025278
`.trim()

  let thumb = 'https://telegra.ph/file/265c672094dfa87caea19.jpg'
  try {
    thumb = await conn.profilePictureUrl(groupId, 'image')
  } catch (e) {}

  await conn.sendMessage(groupId, {
    text: msg,
    mentions: creator ? [creator.id] : [],
    contextInfo: {
      mentionedJid: creator ? [creator.id] : [],
      externalAdReply: {
        title: 'Nishi - BOT SEWA',
        body: groupName,
        thumbnailUrl: thumb,
        mediaType: 1,
        renderLargerThumbnail: false,
        sourceUrl: 'https://wa.me/6283854025278'
      }
    }
  }, { quoted: floc })
}

handler.help = ['join <link> [hari]']
handler.tags = ['owner']
handler.command = /^join$/i
handler.rowner = true

export default handler

const isNumber = x => !isNaN(x) && !isNaN(parseFloat(x))