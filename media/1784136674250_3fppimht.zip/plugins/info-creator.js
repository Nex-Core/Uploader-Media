let handler = async (m, { conn }) => {
    const authorName = global.author || 'Rain..';
    const botName = global.namebot || 'Nishi chisato';
    const ownerNumber = global.nomorown || '6283849737975'; // Ganti dengan nomor owner
    const email = 'support@pontabot.com';
    const website = 'https://pontagpt.vervel.app';
    const instagram = 'https://instagram.com/pontasensei';

    const fakeContact = {
        displayName: `👑 ${authorName} (Owner)`,
        vcard: `BEGIN:VCARD\n` +
            `VERSION:3.0\n` +
            `N:${authorName};;;;\n` +
            `FN:Rain..\n` +
            `ORG:Ponta Inc;\n` +
            `TITLE:Founder & CEO\n` +
            `EMAIL;type=INTERNET:${email}\n` +
            `URL:${website}\n` +
            `TEL;type=WORK;waid=${ownerNumber}:+${ownerNumber}\n` +
            `ADR:;;Indonesia;;;;\n` +
            `X-SOCIALPROFILE;type=instagram:${instagram}\n` +
            `X-WA-BIZ-DESCRIPTION:To the point aja kalo chat.\n` +
            `X-WA-BIZ-NAME:${authorName}\n` +
            `X-WA-BIZ-JID:${ownerNumber}@s.whatsapp.net\n` +
            `END:VCARD`
    };

    await conn.sendMessage(m.chat, {
        contacts: {
            displayName: fakeContact.displayName,
            contacts: [{ vcard: fakeContact.vcard }]
        }
    }, { quoted: m });

    await conn.reply(m.chat, `Hai @${m.sender.split('@')[0]}, ini ownerku`, m, { mentions: [m.sender] });
};

handler.help = ['owner', 'creator'];
handler.tags = ['info'];
handler.command = /^(owner|creator)$/i;

export default handler;