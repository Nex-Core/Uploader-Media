import fs from 'fs'
import moment from 'moment-timezone'

let handler = async (m, { usedPrefix, command, conn, text }) => {
  let mentionedJid = [m.sender]
  let name = conn.getName(m.sender)

  let totalreg = Object.keys(global.db.data.users).length
  let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length

  // Menambahkan format angka dengan koma
  let totalregFormatted = totalreg.toLocaleString('en-US')
  let rtotalregFormatted = rtotalreg.toLocaleString('en-US')

  let kon = `乂 *D A T A B A S E* 乂\n
  🗂 *Database*
       ╰╼ Total:  _${totalregFormatted}_
  📊 *Terdaftar*
       ╰╼ Total:  _${rtotalregFormatted}_`
  
  await conn.relayMessage(m.chat,  {
    requestPaymentMessage: {
      currencyCodeIso4217: 'Ponta',
      amount1000: 100 * 1000,
      requestFrom: '0@s.whatsapp.net',
      noteMessage: {
      extendedTextMessage: {
      text: kon,
      contextInfo: {
      mentionedJid: [m.sender],
      externalAdReply: {
      showAdAttribution: true
      }}}}}}, {})
}

handler.help = ['user']
handler.tags = ['main','info']
handler.command = /^(pengguna|(jumlah)?database|user)$/i

export default handler