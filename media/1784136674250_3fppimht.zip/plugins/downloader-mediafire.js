import fetch from 'node-fetch'
import fs from 'fs'

let handler = async (m, { conn, text }) => {
    if (!text) return m.reply('Mana linknya!')

    try {
        const response = await fetch(`https://api-faa.my.id/faa/mediafire?url=${encodeURIComponent(text)}`)
        const result = await response.json()

        if (result.status) {
            const file = result.result
            const mime = file.mime || 'application/octet-stream'
            const fileName = file.filename || 'mediafire_file'
            const fileSize = file.size || 'Unknown'

            const fileBuffer = await (await fetch(file.download_url)).buffer()

            let caption = `*📝 File Name:* ${fileName}\n*📁 Size:* ${fileSize}\n*📦 Type:* ${file.mime}`

            await conn.sendMessage(m.chat, {
                document: fileBuffer,
                mimetype: mime,
                fileName: fileName,
                caption: caption,
                jpegThumbnail: fs.readFileSync('./thumbnail.jpg'),
                fileLength: fileBuffer.length
            }, { quoted: floc })
        } else {
            m.reply('Gagal mengambil data dari MediaFire. Silakan coba lagi.')
        }
    } catch (error) {
        console.error(error)
        m.reply('Terjadi kesalahan saat mengunduh file.')
    }
}

handler.help = ['mediafire'].map(v => v + ' <url>')
handler.tags = ['downloader']
handler.command = /^(mf|mediafire)$/i
handler.register = true;
handler.limit = true;

export default handler