let handler = async (m, { conn }) => {
  let sewa = `
*𝑺𝒆𝒘𝒂 𝑩𝒐𝒕 Nishikigi Chisato* ✨

📌 *List Harga Sewa*  
- 🎟️ *20 Hari* → Rp10.000  
- 🎫 *1 Bulan* → Rp15.000  
- 🔖 *2 Bulan* → Rp30.000  
- 💎 *4 Bulan* → Rp60.000  
- ⭐ *6 Bulan* → Rp90.000  
- 👑 *Permanent* → Rp200.000  

📥 *Fitur Premium*  
- Limit Unlimited  
- WM Sticker Custom  
- Remini & HD Unlimited  
- TikTok HD  
- To Anime / Real / Figure
- AI Claude & Chi-GPT (Realtime)  
- NSFW Unlock  
- ➕ Dan masih banyak lagi!  

🛠️ *Catatan*  
- Bot aktif 24 jam nonstop  
- Bot off hanya saat perbaikan/error  
- Hubungi owner untuk order  

📩 *Kontak Owner:*  
wa.me/6283854025278
`;

  try {
    await conn.sendMessage(m.chat, {
      text: sewa,
      contextInfo: {
        forwardingScore: 999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: "120363384344978130@newsletter", // ganti dengan newsletter kamu
          newsletterName: global.namebot,
        },
        externalAdReply: {
          title: titlebot,          // judul promosi
          thumbnailUrl: global.thumb, // thumbnail bot
          sourceUrl: global.sgc,   // link GC atau channel kamu
          mediaType: 1,
          renderLargerThumbnail: true,
        },
        mentionedJid: [m.sender],
      },
    }, { quoted: floc });
  } catch (e) {
    conn.reply(m.chat, 'Maaf, menu sewa sedang error', m);
    throw e;
  }
};

handler.command = /^(sewa|sewabot)$/i;
handler.tags = ['info'];
handler.help = ['sewa', 'sewabot'];

export default handler;