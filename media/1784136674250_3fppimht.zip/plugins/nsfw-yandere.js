import axios from 'axios';
import cheerio from 'cheerio';

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return m.reply(`• *Example:* ${usedPrefix + command} loli`);

  const searchUrl = `https://yande.re/post?tags=${encodeURIComponent(text)}`;

  try {
    const response = await axios.get(searchUrl);
    const $ = cheerio.load(response.data);

    const posts = [];
    $('li').each((_, el) => {
      const id = $(el).attr('id');
      const imgSrc = $(el).find('img').attr('src');
      const imgTitle = $(el).find('img').attr('title');
      const directLink = $(el).find('a.directlink').attr('href');

      if (id && id !== 'tab-login' && id !== 'tab-reset' && imgSrc && imgTitle) {
        const titleParts = imgTitle.split(' Tags: ');
        const rating = titleParts[0].replace('Rating: ', '').trim();
        const tagsAndUser = titleParts[1]?.split(' User: ') || ["", "-"];
        const postTags = tagsAndUser[0].trim();
        const user = tagsAndUser[1]?.trim() || "-";

        posts.push({
          id,
          imgSrc,
          rating,
          tags: postTags,
          user,
          directLink,
        });
      }
    });

    if (!posts.length) return m.reply(`Tidak ada hasil untuk tag *${text}*`);

    // pilih random
    const post = posts[Math.floor(Math.random() * posts.length)];

    const buttons = [
      { buttonId: `${usedPrefix + command} ${text}`, buttonText: { displayText: 'Berikutnya' }, type: 1 },
      { buttonId: post.directLink, buttonText: { displayText: 'Download' }, type: 1 }
    ];

    const caption = `⛱️ *ID:* ${post.id}
📊 *Rating:* ${post.rating}
📌 *Tags:* ${post.tags}
💳 *User:* ${post.user}
🔗 *Link:* ${post.directLink}`;

    await conn.sendMessage(m.chat, {
      image: { url: post.imgSrc },
      caption,
      footer: '乂 HTTPS://YANDE.RE',
      buttons,
      headerType: 1,
    }, { quoted: floc });

  } catch (e) {
    console.error(e);
    m.reply('Terjadi kesalahan saat scraping data.');
  }
};

handler.help = ['yandere'];
handler.tags = ['nsfw'];
handler.command = /^(yandere)$/i;
handler.register = true;
handler.premium = true;

export default handler;