import axios from "axios";

const BASE_URL = "https://app.claila.com/api/v2";
const MODEL = "gpt-5";

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `Tolong masukkan pertanyaan!\n\nContoh:\n${usedPrefix}${command} Apa itu teori relativitas?`;

  await conn.sendMessage(m.chat, {
    react: { text: '✨', key: m.key }
  });

  try {
    const sessionId = Date.now().toString();
    const response = await sendMessage(text, sessionId);

    let answer = 'Maaf, aku tidak bisa menjawab itu.';

    if (typeof response === 'string') {
      answer = response;
    } else if (response?.response) {
      answer = response.response;
    } else if (response?.message) {
      answer = response.message;
    } else if (response?.choices?.[0]?.message?.content) {
      answer = response.choices[0].message.content;
    } else {
      answer = JSON.stringify(response).slice(0, 500);
    }

    await conn.reply(m.chat, answer, m);
  } catch (err) {
    console.error(err);
    await conn.reply(m.chat, 'Terjadi kesalahan saat menjawab. Coba lagi nanti.', m);
  }

  await conn.sendMessage(m.chat, {
    react: { text: '', key: m.key }
  });
};

handler.command = ['gpt5'];
handler.tags = ['ai'];
handler.help = ['gpt5'].map(a => a + ' <pertanyaan>');
handler.limit = 3;
handler.register = true;

export default handler;

async function getCSRFToken() {
  const res = await axios.get(`${BASE_URL}/getcsrftoken`, {
    headers: {
      "Accept": "*/*",
      "User-Agent": "Mozilla/5.0",
      "X-Requested-With": "XMLHttpRequest"
    }
  });
  return res.data;
}

async function sendMessage(message, sessionId) {
  const csrfToken = await getCSRFToken();

  const data = new URLSearchParams({
    model: MODEL,
    calltype: "completion",
    message,
    sessionId
  });

  const res = await axios.post(`${BASE_URL}/unichat2`, data, {
    headers: {
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
      "X-CSRF-Token": csrfToken,
      "User-Agent": "Mozilla/5.0",
      "X-Requested-With": "XMLHttpRequest"
    }
  });

  return res.data;
}