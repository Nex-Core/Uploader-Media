import axios from "axios";

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `Tolong masukkan pertanyaan!\n\nContoh:\n${usedPrefix}${command} Jelaskan teori relativitas!`;

  await conn.sendMessage(m.chat, {
    react: { text: '✨', key: m.key }
  });

  try {
    const logic = 'Kamu adalah asisten AI cerdas, informatif, dan sopan.';
    
    const response = await axios({
      method: "POST",
      url: "https://chateverywhere.app/api/chat",
      headers: {
        "Content-Type": "application/json",
        Cookie: "_ga=GA1.1.34196701.1707462626; _ga_ZYMW9SZKVK=GS1.1.1707462625.1.0.1707462625.60.0.0;",
        Origin: "https://chateverywhere.app",
        Referer: "https://chateverywhere.app/id",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36"
      },
      data: {
        model: {
          id: "gpt-3.5-turbo-0613",
          name: "GPT-3.5",
          maxLength: 12000,
          tokenLimit: 4000
        },
        prompt: text,
        messages: [
          { role: "assistant", content: logic },
          { role: "user", content: text }
        ]
      }
    });

    console.log('API Response:', JSON.stringify(response.data, null, 2));

    let answer = 'Maaf, aku tidak bisa menjawab itu.';

    if (response?.data) {
      if (typeof response.data === 'string') {
        answer = response.data;
      } else if (response.data.response) {
        answer = response.data.response;
      } else if (response.data.choices?.[0]?.message?.content) {
        answer = response.data.choices[0].message.content;
      } else if (response.data.message?.content) {
        answer = response.data.message.content;
      } else {
        answer = JSON.stringify(response.data).slice(0, 500);
      }
    }

    await conn.reply(m.chat, answer, m);

  } catch (err) {
    console.error(err);
    await conn.reply(m.chat, 'Terjadi kesalahan saat menjawab. Coba lagi nanti.', m);
  }

  await conn.sendMessage(m.chat, {
    react: { text: '', key: m.key }
  });
};

handler.command = ['gpt', 'gpt4'];
handler.tags = ['ai'];
handler.help = ['gpt4'].map(a => a + ' <pertanyaan>');
handler.limit = 3;
handler.register = true;

export default handler;