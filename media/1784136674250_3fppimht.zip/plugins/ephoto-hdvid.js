import axios from "axios";
import crypto from "crypto";
import { FormData, Blob } from "formdata-node";
import { fileTypeFromBuffer } from "file-type";
import fakeUserAgent from "fake-useragent";

const handler = async (m, { conn, usedPrefix, command, args }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || q.mediaType || "";

  if (!/video/.test(mime)) throw `⤷ Balas video dengan caption: *${usedPrefix + command} [resolusi]*\n\n*Pilihan:* full-hd, 2k, 4k\nContoh: *${usedPrefix + command} 2k*`;

  let resOption = (args[0] || 'hd').toLowerCase();
  let validRes = ['hd', 'full-hd', '2k', '4k'];
  if (!validRes.includes(resOption)) throw `⤷ Resolusi tidak valid. Pilih: full-hd, 2k, atau 4k`;

  const reactWait = { react: { text: "⏳", key: m.key } };
  const reactDone = { react: { text: "✅", key: m.key } };

  try {
    await conn.sendMessage(m.chat, reactWait);

    let buffer = await q.download?.();
    if (!buffer) throw "Gagal mengunduh video.";

    let videoUrl = await uploadTmpfiles(buffer);

    const api = `https://api.nexray.web.id/tools/v1/hdvideo?url=${encodeURIComponent(videoUrl)}&resolusi=${resOption}`;
    
    const { data } = await axios.get(api, {
      headers: { "User-Agent": fakeUserAgent() }
    });

    if (!data.status) throw "Server API gagal memproses video.";

    await conn.sendMessage(
      m.chat,
      {
        video: { url: data.result },
        caption: `• ͙✧*:・ﾟ✧ ɴᴇxʀᴀʏ ʜᴅ ᴠɪᴅᴇᴏ ✧・ﾟ✧*:・ﾟ•\n\n⤷ Status  : Success ✓\n⤷ Resolusi: ${resOption.toUpperCase()}\n⤷ Author  : ${data.author}`,
      },
      { quoted: floc }
    );

  } catch (e) {
    let reason = e?.response?.data?.error || e?.message || "Terjadi kesalahan.";
    conn.reply(m.chat, `✦ *Gagal memproses Video HD*\n\n${reason}`, floc);
  } finally {
    await conn.sendMessage(m.chat, reactDone);
  }
};

handler.command = /^(hdvid|hdvideo|vhd)$/i;
handler.help = ['hdvid', 'vhd'].map(v => v + ' <resolusi>');
handler.tags = ["ephoto"];
handler.premium = true;
handler.register = true;

export default handler;

async function uploadTmpfiles(content) {
  const { ext } = (await fileTypeFromBuffer(content)) || { ext: "mp4" };
  const formData = new FormData();
  const randomBytes = crypto.randomBytes(5).toString("hex");
  
  formData.append(
    "file",
    new Blob([content], { type: "video/mp4" }),
    `${randomBytes}.${ext}`
  );

  const response = await axios.post(
    "https://tmpfiles.org/api/v1/upload",
    formData,
    { headers: { "User-Agent": fakeUserAgent() } }
  );

  const result = response.data;
  const match = /https?:\/\/tmpfiles.org\/(.*)/.exec(result.data.url);
  if (!match) throw new Error("URL Invalid");
  return `https://tmpfiles.org/dl/${match[1]}`;
}