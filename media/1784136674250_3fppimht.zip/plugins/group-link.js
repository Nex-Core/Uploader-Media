const GROUP_JID_RE = /^[0-9]{5,16}-?[0-9]+@g\.us$/

let handler = async (m, { conn, args }) => {

  let group = m.chat
  if (args[0] && GROUP_JID_RE.test(args[0])) group = args[0]
  if (!GROUP_JID_RE.test(group)) throw 'Hanya bisa digunakan di grup (atau beri JID grup yang valid).'

  let code
  try {
    code = await conn.groupInviteCode(group)
  } catch (e) {
    throw 'Gagal mengambil link undangan (mungkin fitur dimatikan atau bot bukan admin).'
  }

  await m.reply('🛡️ https://chat.whatsapp.com/' + code)
}

handler.help = ['linkgc']
handler.tags = ['group']
handler.command = /^(linkgc)$/i
handler.admin = true     
handler.botAdmin = true  
export default handler