const xpperlimit = 1; // Konversi nilai Eris ke bank

// Fungsi untuk format angka menjadi ribuan, juta, miliar, dan seterusnya
const formatNumber = (number) => {
    if (number >= 1e63) return (number / 1e63).toFixed(2).replace(/\.00$/, '') + " vigintiliun";
    if (number >= 1e60) return (number / 1e60).toFixed(2).replace(/\.00$/, '') + " novemdesiliun";
    if (number >= 1e57) return (number / 1e57).toFixed(2).replace(/\.00$/, '') + " octodesiliun";
    if (number >= 1e54) return (number / 1e54).toFixed(2).replace(/\.00$/, '') + " septendesiliun";
    if (number >= 1e51) return (number / 1e51).toFixed(2).replace(/\.00$/, '') + " sexdesiliun";
    if (number >= 1e48) return (number / 1e48).toFixed(2).replace(/\.00$/, '') + " quindesiliun";
    if (number >= 1e45) return (number / 1e45).toFixed(2).replace(/\.00$/, '') + " kvatradesiliun";
    if (number >= 1e42) return (number / 1e42).toFixed(2).replace(/\.00$/, '') + " tredesiliun";
    if (number >= 1e39) return (number / 1e39).toFixed(2).replace(/\.00$/, '') + " dodesiliun";
    if (number >= 1e36) return (number / 1e36).toFixed(2).replace(/\.00$/, '') + " undesiliun";
    if (number >= 1e33) return (number / 1e33).toFixed(2).replace(/\.00$/, '') + " desiliun";
    if (number >= 1e30) return (number / 1e30).toFixed(2).replace(/\.00$/, '') + " noniliun";
    if (number >= 1e27) return (number / 1e27).toFixed(2).replace(/\.00$/, '') + " oktiliun";
    if (number >= 1e24) return (number / 1e24).toFixed(2).replace(/\.00$/, '') + " septiliun";
    if (number >= 1e21) return (number / 1e21).toFixed(2).replace(/\.00$/, '') + " sekstiliun";
    if (number >= 1e18) return (number / 1e18).toFixed(2).replace(/\.00$/, '') + " quintiliun";
    if (number >= 1e15) return (number / 1e15).toFixed(2).replace(/\.00$/, '') + " quadriliun";
    if (number >= 1e12) return (number / 1e12).toFixed(2).replace(/\.00$/, '') + " triliun";
    if (number >= 1e9) return (number / 1e9).toFixed(2).replace(/\.00$/, '') + " miliar";
    if (number >= 1e6) return (number / 1e6).toFixed(2).replace(/\.00$/, '') + " juta";
    if (number >= 1e3) return (number / 1e3).toFixed(2).replace(/\.00$/, '') + " ribu";
    return number.toString(); // Angka kecil tetap apa adanya
}

let handler = async (m, { conn, command, args }) => {
  let user = global.db.data.users[m.sender];
  let user2 = m.sender;

  // Tentukan jumlah dari perintah atau argumen
  let count = command.replace(/^atm/i, '').trim();
  if (/^all$/i.test(count) || /^all$/i.test(args[0])) {
    // "all" atau "all" (dengan spasi) menyimpan semua yang bisa
    count = Math.min(Math.floor(user.eris / xpperlimit), user.fullatm - user.bank);
  } else {
    // Jika tidak, parse jumlah dari argumen atau perintah
    count = parseInt(count) || parseInt(args[0]) || 1;
  }
  count = Math.max(1, count); // Pastikan jumlah minimal 1

  // Cek kondisi dan tanggapi dengan pesan yang sesuai
  if (user.bank >= user.fullatm) {
    return m.reply('Uang di bankmu sudah penuh!');
  }
  if (count > user.fullatm - user.bank) {
    return m.reply('Jumlah uang yang ingin ditabung melebihi kapasitas bank!');
  }
  if (user.eris >= xpperlimit * count) {
    user.eris -= xpperlimit * count;
    user.bank += count;
    conn.reply(m.chat, `✅@${user2.split('@')[0]} Menabung Uang Di Bank\n🏧 Sebesar : _Rp.${formatNumber(count)}_\n💸 Uangmu Di Dompet : _Rp.${formatNumber(user.eris)}_`, m);
  } else {
    conn.reply(m.chat, `[❗] Uang Anda tidak mencukupi untuk menabung ${formatNumber(count)} Money 💹`, m);
  }
};

handler.help = ['atm'];
handler.tags = ['main'];
handler.command = /^atm([0-9]+)|atm|atmall|atm\sall|nabung([0-9]+)|nabung|nabungall|nabung\sall$/i;

export default handler;