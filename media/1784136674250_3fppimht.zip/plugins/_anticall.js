import baileys from 'baileys';
const { WAMessageStubType } = baileys;
const isNumber = x => typeof x === 'number' && !isNaN(x);
const delay = ms => isNumber(ms) && new Promise(resolve => setTimeout(() => {
    resolve();
}, ms));

export async function all(m) {
	if (m.fromMe && m.isBaileys) return true;
	
	let setting = global.db.data.settings[this.user.jid];
	if (!setting.anticall) return;
	
	if (m.messageStubType === WAMessageStubType.CALL_MISSED_VOICE || m.messageStubType === WAMessageStubType.CALL_MISSED_VIDEO) {
	    await delay(1000);
		await conn.reply(m.chat, `GW BLOKIR LO KONTOL😹`, m);
		return conn.updateBlockStatus(m.chat, "block");
	}
}