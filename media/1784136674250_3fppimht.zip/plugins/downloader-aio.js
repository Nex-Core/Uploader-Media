
// const axios = require('axios');
// const crypto = require('crypto');
import axios from 'axios';
import crypto from 'crypto';

const sentMessages = new Set();

let handler = async (m, { conn, text, command, usedPrefix }) => {
  if (!text) throw `EX:\n${usedPrefix}${command} <link IG/FB/TikTok>`;

  if (sentMessages.has(m.key.id)) return;
  sentMessages.add(m.key.id);

  await m.reply(wait);

  try {
    const result = await aio4ksave(text);
    const { download } = result;

    if (Array.isArray(download) && download.length >= 3) {
      const { url } = download[2];
      await conn.sendFile(m.chat, url, 'media.mp4', `> Ini dia kak medianya.`, floc);
    } 
    else if (Array.isArray(download) && download.length > 0) {
      await m.reply(`> Hanya ditemukan ${download.length} media.`);
    }
    else if (typeof download === 'object') {
      await conn.sendFile(
        m.chat,
        download.withoutWatermark || download.watermark,
        'tiktok.mp4',
        `> ${result.info.desc || 'Video TikTok'}`,
        floc
      );
    } else {
      m.reply('> Media tidak ditemukan!');
    }
  } catch (err) {
    console.error(err);
    m.reply('> Gagal memproses video.\n\n' + (err?.message || err));
  }

  setTimeout(() => sentMessages.delete(m.key.id), 30000);
};

handler.help = ['aio'].map(v => v + ' <url>');
handler.tags = ['downloader'];
handler.command = /^(aio)$/i;
handler.limit = true;
handler.register = true;

export default handler;
// module.exports = handler;

const aio4ksave = async (url) => {
  function generateSessionId() {
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let s = "";
    for (let i = 0; i < 10; i++) s += chars[Math.floor(Math.random() * chars.length)];
    return `4ksave_${s}_${Date.now()}`;
  }

  const pemKey = `-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDCAdf/EyIbLBxjGqmh7qLU6/CPCzru+75+82OSPZ+nf4BFvg88drpZ6KigNW0J8TNgxe6Yms1irCZNVDyu+RXsl4y/7c2KOHc4OGTzHB5fUMiMasFUvcEs2P70e6yA/sKHZfBLG1XPhlb84Ibs3nhD3W5e2SuC+4EuVkaqzN08LQIDAQAB
-----END PUBLIC KEY-----`;

  const sessionId = generateSessionId();

  let xSecureMessage = crypto.publicEncrypt(
    {
      key: pemKey,
      padding: crypto.constants.RSA_PKCS1_PADDING
    },
    Buffer.from(Date.now().toString())
  ).toString('base64');

  const createDlUrl = (token) =>
    token && `https://api.4ksave.com/st-tik/token/${token}?sessionid=${sessionId}&wh=www.4ksave.com&status=download`;

  const urlType = /(fb|facebook)\./i.test(url)
    ? 'fb'
    : url.includes('instagram.')
    ? 'ig'
    : 'tt';

  const urlMapping = {
    fb: {
      path: '-video/fb',
      parse: (data) => ({
        download: data.fbBos.map(v => ({
          ...v,
          cover: createDlUrl(v.cover),
          url: createDlUrl(v.url),
          thumb: createDlUrl(v.thumb)
        }))
      })
    },
    ig: {
      path: '/ins',
      parse: (data) => ({
        download: data.insBos.map(v => ({
          ...v,
          cover: createDlUrl(v.cover),
          url: createDlUrl(v.url),
          thumb: createDlUrl(v.thumb)
        }))
      })
    },
    tt: {
      path: '/tiktok',
      parse: (data) => ({
        download: {
          withoutWatermark: createDlUrl(data.withoutWaterMarkMp4),
          watermark: createDlUrl(data.waterMarkMp4),
          audio: createDlUrl(data.mp3)
        },
        info: {
          desc: data.desc,
          author: data.author,
          duration: data.duration,
          cover: data.cover
        }
      })
    }
  };

  const apiUrl = `https://api.4ksave.com/st-tik${urlMapping[urlType].path}/dl?url=${encodeURIComponent(url)}&sessionid=${sessionId}`;
  const headers = {
    'accept': 'application/json, text/plain, */*',
    'x-secure-message': xSecureMessage,
    'x-robots-tag': 'noindex, nofollow',
    'user-agent': 'okhttp/4.12.0'
  };

  const response = await axios.get(apiUrl, {
    headers,
    referrer: 'https://www.4ksave.com/',
    referrerPolicy: 'strict-origin-when-cross-origin'
  });

  return {
    status: 'success',
    ...urlMapping[urlType].parse(response.data?.result)
  };
};