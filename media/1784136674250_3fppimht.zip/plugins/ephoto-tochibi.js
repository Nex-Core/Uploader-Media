import axios from "axios";
import crypto from "crypto";
import { FormData, Blob } from "formdata-node";
import { fileTypeFromBuffer } from "file-type";
import fakeUserAgent from "fake-useragent";

const handler = async (m, { conn, usedPrefix, command }) => {
  let user = global.db?.data?.users?.[m.sender] || {};
  if (!user.chibiUses) user.chibiUses = 0;
  if (!user.lastChibiReset) user.lastChibiReset = 0;

  let now = Date.now();
  if (!user.premium && now - user.lastChibiReset > 10 * 60 * 60 * 1000) {
    user.chibiUses = 0;
    user.lastChibiReset = now;
  }

  if (!user.premium && user.chibiUses >= 3) {
    return m.reply(
      `*Limit Chibi habis* (${user.chibiUses}/3)\n` +
      `Tunggu 10 jam untuk reset atau upgrade ke premium.\n\n` +
      `> Ketik: ${usedPrefix}premium`
    );
  }

  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";

  if (!mime) throw `Kirim/Reply gambar dengan caption *${usedPrefix + command}*`;
  if (!/image\/(jpe?g|png)/.test(mime)) throw `Mime ${mime} tidak support`;

  const react = { react: { text: "🧸", key: m.key } };
  const reactdone = { react: { text: "✨", key: m.key } };

  try {
    await conn.sendMessage(m.chat, react);

    const img = await q.download();
    const imageUrl = await uploadTmpfiles(img);

    const api = `https://api.nexray.web.id/ephoto/chibi?url=${encodeURIComponent(imageUrl)}`;

    const response = await axios.get(api, {
      responseType: "arraybuffer",
      headers: { "User-Agent": fakeUserAgent() }
    });

    const buffer = Buffer.from(response.data);

    let limitInfo = user.premium ? "Unlimited" : `${user.chibiUses + 1}/3`;

    await conn.sendMessage(
      m.chat,
      {
        image: buffer,
        caption: `🧸 *Chibi Style berhasil dibuat*\n\nPenggunaan: ${limitInfo}`,
        mentions: [m.sender]
      },
      { quoted: floc }
    );

    if (!user.premium) user.chibiUses += 1;

  } catch (e) {
    let reason = e?.response?.data?.error || e?.message || e.toString();
    await conn.sendMessage(
      m.chat,
      { text: `✦ *Error saat membuat Chibi Style*\n\n${reason}` },
      { quoted: floc }
    );
  } finally {
    await conn.sendMessage(m.chat, reactdone);
  }
};

handler.command = /^(tochibi|chibi)$/i;
handler.help = ["tochibi"].map(v => v + " <reply image>");
handler.tags = ["ephoto"];
handler.register = true;

export default handler;

async function uploadTmpfiles(content) {
  const { ext } = (await fileTypeFromBuffer(content)) || { ext: "jpg" };

  const formData = new FormData();
  const randomBytes = crypto.randomBytes(5).toString("hex");

  formData.append(
    "file",
    new Blob([content], { type: "application/octet-stream" }),
    `${randomBytes}.${ext}`
  );

  const response = await axios.post(
    "https://tmpfiles.org/api/v1/upload",
    formData,
    { headers: { "User-Agent": fakeUserAgent() } }
  );

  const result = response.data;
  const match = /https?:\/\/tmpfiles.org\/(.*)/.exec(result.data.url);

  if (!match) throw new Error("Invalid tmpfiles URL format");

  return `https://tmpfiles.org/dl/${match[1]}`;
}