import cp from 'child_process'
import { promisify } from 'util'
import fs from 'fs'

let exec = promisify(cp.exec).bind(cp)
let readdir = promisify(fs.readdir)

let handler = async (m) => {
    await conn.reply(m.chat, "Done", m)
    let o
    try {
        // Baca isi dari folder media
        let files = await readdir('media')
        
        // Hapus setiap berkas atau direktori di dalam folder media
        for (const file of files) {
            await exec(`rm -rf media/${file}`)
        }
    } catch (e) {
        o = e
    } 
}

handler.help = ['clearmedia']
handler.tags = ['owner']
handler.command = /^(clearmedia|delmedia)$/i
handler.rowner = true

export default handler