const xpperlimit = 1; // Konversi nilai Bank ke Eris

// Fungsi untuk format angka menjadi ribuan, juta, miliar, dan seterusnya
const formatNumber = (number) => {
    if (number >= 1e63) return (number / 1e63).toFixed(2).replace(/\.00$/, '') + " vigintiliun";
    if (number >= 1e60) return (number / 1e60).toFixed(2).replace(/\.00$/, '') + " novemdesiliun";
    if (number >= 1e57) return (number / 1e57).toFixed(2).replace(/\.00$/, '') + " octodesiliun";
    if (number >= 1e54) return (number / 1e54).toFixed(2).replace(/\.00$/, '') + " septendesiliun";
    if (number >= 1e51) return (number / 1e51).toFixed(2).replace(/\.00$/, '') + " sexdesiliun";
    if (number >= 1e48) return (number / 1e48).toFixed(2).replace(/\.00$/, '') + " quindesiliun";
    if (number >= 1e45) return (number / 1e45).toFixed(2).replace(/\.00$/, '') + " kvatradesiliun";
    if (number >= 1e42) return (number / 1e42).toFixed(2).replace(/\.00$/, '') + " tredesiliun";
    if (number >= 1e39) return (number / 1e39).toFixed(2).replace(/\.00$/, '') + " dodesiliun";
    if (number >= 1e36) return (number / 1e36).toFixed(2).replace(/\.00$/, '') + " undesiliun";
    if (number >= 1e33) return (number / 1e33).toFixed(2).replace(/\.00$/, '') + " desiliun";
    if (number >= 1e30) return (number / 1e30).toFixed(2).replace(/\.00$/, '') + " noniliun";
    if (number >= 1e27) return (number / 1e27).toFixed(2).replace(/\.00$/, '') + " oktiliun";
    if (number >= 1e24) return (number / 1e24).toFixed(2).replace(/\.00$/, '') + " septiliun";
    if (number >= 1e21) return (number / 1e21).toFixed(2).replace(/\.00$/, '') + " sekstiliun";
    if (number >= 1e18) return (number / 1e18).toFixed(2).replace(/\.00$/, '') + " quintiliun";
    if (number >= 1e15) return (number / 1e15).toFixed(2).replace(/\.00$/, '') + " quadriliun";
    if (number >= 1e12) return (number / 1e12).toFixed(2).replace(/\.00$/, '') + " triliun";
    if (number >= 1e9) return (number / 1e9).toFixed(2).replace(/\.00$/, '') + " miliar";
    if (number >= 1e6) return (number / 1e6).toFixed(2).replace(/\.00$/, '') + " juta";
    if (number >= 1e3) return (number / 1e3).toFixed(2).replace(/\.00$/, '') + " ribu";
    return number.toString(); // Angka kecil tetap apa adanya
}

let handler = async (m, { conn, command, args }) => {
  let user = global.db.data.users[m.sender];

  // Tentukan jumlah dari perintah atau argumen
  let count = command.replace(/^pull/i, '').trim();
  if (/^all$/i.test(count) || /^all$/i.test(args[0])) {
    // "all" atau "all" (dengan spasi) menarik semua yang bisa
    count = Math.min(Math.floor(user.bank / xpperlimit), user.bank);
  } else {
    // Jika tidak, parse jumlah dari argumen atau perintah
    count = parseInt(count) || parseInt(args[0]) || 1;
  }
  count = Math.max(1, count); // Pastikan jumlah minimal 1

  // Cek kondisi dan tanggapi dengan pesan yang sesuai
  if (user.bank >= xpperlimit * count) {
    user.bank -= xpperlimit * count;
    user.eris += count;
    conn.reply(m.chat, `✅@${m.sender.split('@')[0]} Mengambil Uang Di Bank\n🏧 Sebesar : _Rp.${formatNumber(count)}_\n💸 Uangmu Di Dompet : _Rp.${formatNumber(user.eris)}_`, m);
  } else {
    conn.reply(m.chat, `Money kamu tidak mencukupi untuk menarik ${formatNumber(count)} Money 💹`, m);
  }
};

handler.help = ['pull'];
handler.tags = ['main'];
handler.command = /^pull([0-9]+)|pull|pullall|pull\sall|tarik([0-9]+)|tarik|tarikall|tarik\sall$/i;
handler.register = false;

export default handler;