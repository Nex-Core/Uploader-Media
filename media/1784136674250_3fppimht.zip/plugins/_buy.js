let handler = async (m, { conn, text, command }) =>  

m.reply(`Format Anda Salah Gunakan Format Berikut

Untuk Membeli Atau Menjual barang ada dishop ketik *.shop* Untuk melihat list harga.

Contoh: 
🌽 .shop buy sushi 1
> Untuk Membeli barang
🌽 .shop sell limit 1
> Untuk Menjual barang

...`)

handler.command = /^(buy|sell)$/i
export default handler