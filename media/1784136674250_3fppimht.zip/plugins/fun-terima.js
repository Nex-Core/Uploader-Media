import PhoneNumber from 'awesome-phonenumber';
import { areJidsSameUser } from 'baileys';

function resolveJid(input, participants = []) {
    const found = participants.find(p =>
        areJidsSameUser(p?.id, input) ||
        areJidsSameUser(p?.lid, input) ||
        areJidsSameUser(p?.jid, input)
    );
    return found?.jid || input;
}

function no(number) {
    return number.replace(/\s/g, '').replace(/([@+-])/g, '');
}

let handler = async (m, { conn, text, participants, usedPrefix }) => {
    let who;

    text = no(text);

    if (!text && !m.quoted && !m.mentionedJid?.length) {
        return conn.reply(m.chat, `Berikan nomor, tag, atau balas pesan target`, m);
    }

    if (m.quoted) {
        who = m.quoted.sender;
    } else if (m.mentionedJid?.length) {
        who = m.mentionedJid[0];
    } else if (text) {
        const target = text.trim();
        if (target.startsWith('@')) {
            who = target.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        } else if (target.includes('@s.whatsapp.net') || target.includes('@lid')) {
            who = target;
        } else {
            who = target.replace(/\D/g, '') + '@s.whatsapp.net';
        }
    }

    if (m.isGroup) {
        who = resolveJid(who, participants);
    }

    if (!who) {
        return conn.reply(m.chat, `Target atau nomor tidak ditemukan, mungkin sudah keluar atau bukan anggota grup ini`, m);
    }

    if (who === m.sender) {
        return conn.reply(m.chat, `Tidak bisa berpacaran dengan diri sendiri!`, m);
    }
    if (who === conn.user.jid) {
        return conn.reply(m.chat, `Tidak bisa berpacaran dengan saya t_t`, m);
    }

    let me = m.sender;

    if (global.db.data.users[who]?.pasangan !== m.sender) {
        conn.reply(m.chat, `Maaf @${who.split('@')[0]} tidak sedang menembak anda`, m, { contextInfo: { mentionedJid: [who] } });
    } else {
        global.db.data.users[m.sender].pasangan = who;
        conn.reply(m.chat, `Selamat anda resmi berpacaran dengan @${who.split('@')[0]}\n\nSemoga langgeng dan bahagia selalu @${who.split('@')[0]} 💓 @${me.split('@')[0]} 🥳🥳🥳`, m, { contextInfo: { mentionedJid: [who, me] } });
    }
};

handler.help = ['terima @tag'];
handler.tags = ['fun'];
handler.command = /^(terima)$/i;
handler.group = true;
handler.limit = false;

export default handler;