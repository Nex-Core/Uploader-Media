import fs from 'fs';
import archiver from 'archiver';
import path from 'path';
import moment from 'moment';

const handler = async (m, { conn }) => {
  m.reply('Sedang mempersiapkan backup...');
  let timestamp = moment().format('YYYYMMDD-HHmmss');
  let waktuBackup = moment().format('YYYY-MM-DD HH:mm:ss');
  let namabot = 'NISHIKIGI CHISATO'
  let backupName = `SC ${namabot} ${waktuBackup}.zip`;
  let output = fs.createWriteStream(backupName);
  let archive = archiver('zip', { zlib: { level: 9 } });
  
  output.on('close', function () {
    let caption = `\`Berikut adalah file backup\`\n\n* Nama file: ${backupName}\n* Ukuran file: ${(archive.pointer() / 1024 / 1024).toFixed(2)} MB`;
    
    // Send to owner's number
    let ownerNumber = `${global.nomorown}@s.whatsapp.net`;  // Global variable for owner's number
    conn.sendFile(ownerNumber, backupName, backupName, caption, m)
      .then(() => {
        fs.unlinkSync(backupName);  // Delete the backup file after sending it
      })
      .catch((err) => {
        throw err;
      });
  });

  archive.on('warning', function (err) {
    if (err.code === 'ENOENT') {
      console.warn(err);
    } else {
      throw err;
    }
  });

  archive.on('error', function (err) {
    throw err;
  });

  archive.pipe(output);
  archive.glob('**/*', {
    cwd: '/home/container',
    ignore: ['node_modules/**', 'sessions/', 'tmp/**', '.npm/**', backupName]
  });
  archive.finalize();
};

handler.help = ['backupsc'];
handler.tags = ['owner'];
handler.command = /^backupsc$/i;
handler.owner = true;

export default handler;