const { proto, generateWAMessageFromContent } = (await import('baileys')).default;

let handler = async (m, { conn, command }) => {
    let ruang = conn.mabar_sekiro[m.chat];
    conn.sekiro = conn.sekiro || {};
    let room = conn.sekiro[m.chat];

    if (ruang && ruang.state === 'pilihserver' && m.sender === ruang.master) {
        let user = global.db.data.users[m.sender];
        let enemies = {
            ashina: ['Ashina Soldier', 'Bandit', 'Wolf', 'Taro Trooper', 'Nightjar Ninja'],
            hirata: ['Shinobi Hunter', 'Juzou the Drunkard', 'Bandit Archer', 'Lone Shadow', 'Mist Noble'],
            senpou: ['Senpou Monk', 'Infested Monk', 'Centipede Assassin', 'Rat', 'Temple Guardian'],
            castle: ['Ashina Elite', 'Lone Shadow Vilehand', 'Nightjar Veteran', 'Red Guard', 'Chained Ogre'],
            fountainhead: ['Okami Warrior', 'Headless', 'Shichimen Warrior', 'Corrupted Monk', 'Divine Dragon']
        };

        const paths = {
            ashina: { 
                level: 10, 
                health: 100, 
                stamina: 80, 
                katana: 1, 
                katanadura: 50, 
                pathName: 'Ashina Outskirts', 
                katanaName: 'Fubuki' 
            },
            hirata: { 
                level: 20, 
                health: 150, 
                stamina: 100, 
                katana: 2, 
                katanadura: 100, 
                pathName: 'Hirata Estate', 
                katanaName: 'Koyuki' 
            },
            senpou: { 
                level: 30, 
                health: 200, 
                stamina: 120, 
                katana: 3, 
                katanadura: 150, 
                pathName: 'Senpou Temple', 
                katanaName: 'Mizore' 
            },
            castle: { 
                level: 40, 
                health: 250, 
                stamina: 150, 
                katana: 4, 
                katanadura: 200, 
                pathName: 'Ashina Castle', 
                katanaName: 'Shigure' 
            },
            fountainhead: { 
                level: 100, 
                health: 400, 
                stamina: 200, 
                katana: 5, 
                katanadura: 250, 
                pathName: 'Fountainhead Palace', 
                katanaName: 'Yukikaze' 
            }
        };

        let pathData = paths[command];
        if (!pathData) return m.reply('Jalur tidak valid!');

        if (user.level < pathData.level) return m.reply(`Kamu membutuhkan *Level ${pathData.level}* untuk bertarung di *${pathData.pathName}*!`);
        if (user.health < pathData.health) return m.reply(`Health kamu kurang dari *${pathData.health} ❤️*!`);
        if (user.stamina < pathData.stamina) return m.reply(`Stamina kamu kurang dari *${pathData.stamina} ⚡*!`);
        if (user.katana < pathData.katana) return m.reply(`Kamu membutuhkan *${pathData.katanaName}* untuk bertarung di *${pathData.pathName}*!`);
        if (user.katanadurability < pathData.katanadura) return m.reply(`Durability katana kamu kurang dari *${pathData.katanadura} 🗡️*!`);

        conn.sekiro[m.chat] = {
            id: Math.floor(Math.random() * 100000000).toString(),
            p: m.sender,
            players: [m.sender],
            nameserver: command,
            healtserver: pathData.health,
            staminaserver: pathData.stamina,
            katanaserver: pathData.katana,
            katanadura: pathData.katanadura,
            katanaName: pathData.katanaName,
            cdserver: 1800000,
            enemy: pickRandom(enemies[command]),
            hapus: delete conn.mabar_sekiro[m.chat],
            status: 'wait'
        };

        room = conn.sekiro[m.chat];
        let playerList = room.players.map((player, index) => `*${index + 1}.* @${player.replace(/@.+/, '')}`).join('\n');
        let buatRoom = `⚔️ Berhasil membuat room\n*Room ID:* ${room.id}\n*Path:* ${pathData.pathName}\n\n♻️ Menunggu shinobi lain untuk join`;
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: buatRoom,
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: "*© Nishi chisato*"
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            title: "\t🏯 *SEKIRO ROOM* 🏯\n",
                            subtitle: "",
                            hasMediaAttachment: false
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: "{\"display_text\":\"♻️ Join\",\"id\":\"sekiro_join\"}"
                                },
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: "{\"display_text\":\"👤 Solo\",\"id\":\"sekiro_solo\"}"
                                },
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: "{\"display_text\":\"🚫 Batalkan\",\"id\":\"sekiro_batall\"}"
                                },
                            ],
                        })
                    })
                },
            }
        }, {});
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    }
};

handler.command = /^(ashina|hirata|senpou|castle|fountainhead)$/i;
handler.group = true;

export default handler;

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)];
}