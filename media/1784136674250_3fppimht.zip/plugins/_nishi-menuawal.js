import { promises, readFileSync } from 'fs'
import { join } from 'path'
import { xpRange } from '../lib/levelling.js'
import moment from 'moment-timezone'
import os from 'os'
import fs from 'fs'
import fetch from 'node-fetch'
const { generateWAMessageFromContent, proto } = (await import('baileys')).default

const defaultMenu = {
  before: `
`.trimStart(),
  header: '',
  body: '',
  footer: '',
  after: '',
}
let ponta = `⋆｡˚☁︎˚｡⋆｡˚☽˚｡⋆  
ᴡᴀᴛᴀꜱʜɪ ʜᴀ ɴɪꜱʜɪ ᴄʜɪꜱᴀᴛᴏ ᴅᴇꜱᴜ  
ʙᴏᴛᴏ ᴅᴇ ᴡʜᴀᴛꜱᴀᴘᴘ ꒰｡ ꜱᴛɪᴋᴀ̄・ᴋᴏɴᴛᴇɴ・ᴀɪ ｡꒱  
ᴀɪ ᴏᴛᴇᴛꜱᴜᴅᴀᴏᴜ... ꒰ঌ ꕤ໋

┊☾ ୨୧ ᴍᴇɴᴜ ɢᴜɪᴅᴇ ୨୧ ☽  
⤿ ִ ׄᥴ⃘ᦱ *.ᴀʟʟᴍᴇɴᴜ* ⠲ ᴛᴀᴍᴘɪʟᴋᴀɴ ꜱᴇᴍᴜᴀ ꜰɪᴛᴜʀ  
⤿ ִ ׄᥴ⃘ᦱ *.ʟɪꜱᴛᴍᴇɴᴜ* ⠲ ᴍᴇɴᴜ ꜱɪᴍᴘᴇʟ & ᴄᴇᴘᴀᴛ  
⤿ ִ ׄᥴ⃘ᦱ *.ᴏᴡɴᴇʀ* ⠲ ᴋᴏɴᴛᴀᴋ ᴘᴇᴍʙᴜᴀᴛ ʙᴏᴛ  
⤿ ִ ׄᥴ⃘ᦱ *.ꜱᴄʀɪᴘᴛ* ⠲ ʙᴇʟɪ ꜱᴄʀɪᴘᴛ ᴏʀɪꜱɪɴᴀʟ ᴄʜɪɪ ♡

┊☾ ୨୧ ɴᴏᴛᴇ ୨୧ ☽  
⤿ ִ ׄᥴ⃘ᦱ *.ᴛᴜᴛᴏʀɪᴀʟ* ⠲ ᴄᴀʀᴀ ᴘᴀᴋᴀɪ ʙᴏᴛ  
⤿ ִ ׄᥴ⃘ᦱ *.ʀᴇᴘᴏʀᴛ* ⠲ ʟᴀᴘᴏʀɪɴ ʙᴜɢ

╰╼ ꒰ঌ ༝ ˚｡⋆ ᴛʀᴜsᴛ ʏᴏᴜʀ sᴘᴀʀᴋʟᴇ  
ᴀɴᴅ ᴇɴᴊᴏʏ ʏᴏᴜʀ ᴊᴏᴜʀɴᴇʏ ᯓ★⋆｡˚☁︎`
let handler = async (m, { conn, usedPrefix: _p, __dirname, args, command}) => {
let tags = {
'nishimenu': { }
}
 
  try {
  	// DEFAULT MENU
      let dash = global.dashmenu
  	let m1 = global.dmenut
      let m2 = global.dmenub
      let m3 = global.dmenuf
      let m4 = global.dmenub2
      
      // COMMAND MENU
      let cc = global.cmenut
      let c1 = global.cmenuh
      let c2 = global.cmenub
      let c3 = global.cmenuf
      let c4 = global.cmenua
      
      // LOGO L P
      let lprem = global.lopr
      let llim = global.lolm
      let tag = `@${m.sender.split('@')[0]}`
    
    //-----------TIME---------
    let ucpn = `${ucapan()}`
    let d = new Date(new Date + 3600000)
    let locale = 'id'
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
    let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
    let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
    // d.getTimeZoneOffset()
    // Offset -420 is 18.00
    // Offset    0 is  0.00
    // Offset  420 is  7.00
    let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
    let dateIslamic = Intl.DateTimeFormat(locale + '-TN-u-ca-islamic', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }).format(d)
    let time = d.toLocaleTimeString(locale, {
      hour: 'numeric',
      minute: 'numeric',
      second: 'numeric'
    })
    let _uptime = process.uptime() * 1000
    let _muptime
    if (process.send) {
      process.send('uptime')
      _muptime = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }
    let muptime = clockString(_muptime)
    let uptime = clockString(_uptime)
    let _mpt
    if (process.send) {
      process.send('uptime')
      _mpt = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }
    let mpt = clockString(_mpt)
    let usrs = db.data.users[m.sender]
      
    let wib = moment.tz('Asia/Jakarta').format('HH:mm:ss')
    let wibh = moment.tz('Asia/Jakarta').format('HH')
    let wibm = moment.tz('Asia/Jakarta').format('mm')
    let wibs = moment.tz('Asia/Jakarta').format('ss')
    let wit = moment.tz('Asia/Jayapura').format('HH:mm:ss')
    let wita = moment.tz('Asia/Makassar').format('HH:mm:ss')
    let wktuwib = `${wibh} H ${wibm} M ${wibs} S`
 
    let mode = global.opts['self'] ? 'Private' : 'Publik'
    let _package = JSON.parse(await promises.readFile(join(__dirname, '../package.json')).catch(_ => ({}))) || {}
    let { age, exp, limit, level, role, registered, eris} = global.db.data.users[m.sender]
    let { min, xp, max } = xpRange(level, global.multiplier)
    let name = await conn.getName(m.sender)
    let premium = global.db.data.users[m.sender].premiumTime
    let prems = `${premium > 0 ? 'Premium': 'Free'}`
    let platform = os.platform()
    
    //---------------------
    
    let totalreg = Object.keys(global.db.data.users).length
    let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length
    let help = Object.values(global.plugins).filter(plugin => !plugin.disabled).map(plugin => {
      return {
        help: Array.isArray(plugin.tags) ? plugin.help : [plugin.help],
        tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
        prefix: 'customPrefix' in plugin,
        limit: plugin.limit,
        premium: plugin.premium,
        enabled: !plugin.disabled,
      }
    })
    let groups = {}
    for (let tag in tags) {
      groups[tag] = []
      for (let plugin of help)
        if (plugin.tags && plugin.tags.includes(tag))
          if (plugin.help) groups[tag].push(plugin)
          }
    conn.menu = conn.menu ? conn.menu : {}
    let before = conn.menu.before || defaultMenu.before
    let header = conn.menu.header || defaultMenu.header
    let body = conn.menu.body || defaultMenu.body
    let footer = conn.menu.footer || defaultMenu.footer
    let after = conn.menu.after || (conn.user.jid == global.conn.user.jid ? '' : `Powered by https://wa.me/${global.conn.user.jid.split`@`[0]}`) + defaultMenu.after
    let _text = [
      before,
      ...Object.keys(tags).map(tag => {
        return header.replace(/%category/g, tags[tag]) + '\n' + [
          ...help.filter(menu => menu.tags && menu.tags.includes(tag) && menu.help).map(menu => {
            return menu.help.map(help => {
              return body.replace(/%cmd/g, menu.prefix ? help : '%_p' + help)
                .replace(/%islimit/g, menu.limit ? llim : '')
                .replace(/%isPremium/g, menu.premium ? lprem : '')
                .trim()
            }).join('\n')
          }),
          footer
        ].join('\n')
      }),
      after
    ].join('\n')
    let text = typeof conn.menu == 'string' ? conn.menu : typeof conn.menu == 'object' ? _text : ''
    let replace = {
      '%': '%',
      p: uptime, muptime,
      me: conn.getName(conn.user.jid),
      npmname: _package.name,
      npmdesc: _package.description,
      version: _package.version,
      exp: exp - min,
      maxexp: xp,
      totalexp: exp,
      xp4levelup: max - exp,
      github: _package.homepage ? _package.homepage.url || _package.homepage : '[unknown github url]',
      tag, dash,m1,m2,m3,m4,cc, c1, c2, c3, c4,lprem,llim,
      ucpn,platform, wib, mode, _p, eris, age, tag, name, prems, level, limit, name, weton, week, date, dateIslamic, time, totalreg, rtotalreg, role,
      readmore: readMore
    }
    text = text.replace(new RegExp(`%(${Object.keys(replace).sort((a, b) => b.length - a.length).join`|`})`, 'g'), (_, name) => '' + replace[name])
    
 let fkon = { key: { fromMe: false, participant: `${m.sender.split`@`[0]}@s.whatsapp.net`, ...(m.chat ? { remoteJid: '16504228206@s.whatsapp.net' } : {}) }, message: { contactMessage: { displayName: `${name}`, vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;a,;;;\nFN:${name}\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`}}}

     conn.sendMessage(m.key.remoteJid, {
  image: { url: `${global.thumb2}` },
  caption: ponta,
  footer: `ɴɪsʜɪ ᴄʜɪsᴀᴛᴏ - ꜰᴇᴀʀʟᴇss.`,
  buttons: [
    {
      buttonId: ".owner",
      buttonText: { displayText: "✦ ᴄᴏɴᴛᴀᴄᴛ ᴏᴡɴᴇʀ" },
      type: 1
    },
    {
      buttonId: ".sc",
      buttonText: { displayText: "✦ ʙᴜʏ sᴄʀɪᴘᴛ" },
      type: 1
    },
    {
      buttonId: "action",
      buttonText: { displayText: "ᴍᴀɪɴ ᴍᴇɴᴜ" },
      type: 4,
      nativeFlowInfo: {
        name: "single_select",
        paramsJson: JSON.stringify({
          title: "ᴄʟɪᴄᴋ ʜᴇʀᴇ",
          sections: [
            {
              title: "✦ ɪɴꜰᴏʀᴍᴀsɪ ✦",
              rows: [
                { title: "ʟɪʜᴀᴛ sᴇᴍᴜᴀ ᴍᴇɴᴜ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ sᴇᴍᴜᴀ ᴍᴇɴᴜ ʏᴀɴɢ ᴛᴇʀsᴇᴅɪᴀ", id: ".allmenu" },
                { title: "ʜᴀʀɢᴀ sᴇᴡᴀ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ʜᴀʀɢᴀ sᴇᴡᴀ ɴɪsʜɪᴋɪɢɪ ᴄʜɪsᴀᴛᴏ", id: ".sewa" },
                { title: "ᴘᴇʀᴀᴛᴜʀᴀɴ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴘᴇʀᴀᴛᴜʀᴀɴ ᴋᴀᴍɪ", id: ".rules" }
              ]
            },
            {
              title: "🗃️ ꜰɪᴛᴜʀ ᴛᴇʀsᴇᴅɪᴀ",
              rows: [
                { title: "ᴍᴇɴᴜ ᴀɪ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ ᴀɪ", id: ".menuai" },
                { title: "ᴍᴇɴᴜ ᴀᴜᴅɪᴏ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ ᴀᴜᴅɪᴏ", id: ".menuaudio" },
                { title: "ᴍᴇɴᴜ ᴄʟᴀɴ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ ᴄʟᴀɴ", id: ".menuclan" },
                { title: "ᴍᴇɴᴜ ᴅᴏᴡɴʟᴏᴀᴅ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ", id: ".menudownloader" },
                { title: "ᴍᴇɴᴜ ᴇᴘʜᴏᴛᴏ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ ᴇᴘʜᴏᴛᴏ", id: ".menuephoto" },
                { title: "ᴍᴇɴᴜ ꜰᴜɴ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ ꜰᴜɴ", id: ".menufun" },
                { title: "ᴍᴇɴᴜ ɢᴀᴍᴇ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ ɢᴀᴍᴇ", id: ".menugame" },
                { title: "ᴍᴇɴᴜ ɢʀᴏᴜᴘ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ ɢʀᴏᴜᴘ", id: ".menugroup" },
                { title: "ᴍᴇɴᴜ ɪɴꜰᴏ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ ɪɴꜰᴏ", id: ".menuinfo" },
                { title: "ᴍᴇɴᴜ ɪɴᴛᴇʀɴᴇᴛ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ ɪɴᴛᴇʀɴᴇᴛ", id: ".menuinternet" },
                { title: "ᴍᴇɴᴜ ᴍᴀɪɴ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ ᴜᴛᴀᴍᴀ", id: ".menumain" },
                { title: "ᴍᴇɴᴜ ᴍᴀᴋᴇʀ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ ᴍᴀᴋᴇʀ", id: ".menumaker" },
                { title: "ᴍᴇɴᴜ ɴsꜰᴡ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ ɴsꜰᴡ", id: ".menunsfw" },
                { title: "ᴍᴇɴᴜ ᴏᴡɴᴇʀ", description: "*ᴋʜᴜsᴜs ꜰᴇᴀʀʟᴇss.*", id: ".menuowner" },
                { title: "ᴍᴇɴᴜ ϙᴜᴏᴛᴇs", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ ϙᴜᴏᴛᴇs", id: ".menuquotes" },
                { title: "ᴍᴇɴᴜ ʀᴀɴᴅᴏᴍ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ ʀᴀɴᴅᴏᴍ", id: ".menurandom" },
                { title: "ᴍᴇɴᴜ ʀᴘɢ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ ʀᴘɢ", id: ".menurpg" },
                { title: "ᴍᴇɴᴜ sᴇᴀʀᴄʜ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ sᴇᴀʀᴄʜ", id: ".menusearch" },
                { title: "ᴍᴇɴᴜ sᴛɪᴄᴋᴇʀ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ sᴛɪᴄᴋᴇʀ", id: ".menusticker" },
                { title: "ᴍᴇɴᴜ sᴛᴏʀᴇ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ sᴛᴏʀᴇ", id: ".menustore" },
                { title: "ᴍᴇɴᴜ ᴛᴏᴏʟs", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ ᴛᴏᴏʟs", id: ".menutools" },
                { title: "ᴍᴇɴᴜ ᴜsᴇʀ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ ᴜsᴇʀ", id: ".menuuser" },
                { title: "ᴍᴇɴᴜ ᴠᴏɪᴄᴇ", description: "ᴋʟɪᴋ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ ᴠᴏɪᴄᴇ", id: ".menuvoice" }
              ]
            }
          ]
        })
      }
    }
  ],
  headerType: 4,
  viewOnce: true,
}, { quoted: floc });
            
  } catch (e) {
    conn.reply(m.chat, 'Maaf, menu sedang error', m)
    throw e
  }
}
handler.help = ['menu']
handler.tags = ['main']
handler.command = /^(menu|help|\?)$/i

handler.register = true

export default handler

//----------- FUNCTION -------

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

function clockString(ms) {
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [h, ' H ', m, ' M ', s, ' S '].map(v => v.toString().padStart(2, 0)).join('')
}
function clockStringP(ms) {
  let ye = isNaN(ms) ? '--' : Math.floor(ms / 31104000000) % 10
  let mo = isNaN(ms) ? '--' : Math.floor(ms / 2592000000) % 12
  let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000) % 30
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [ye, ' *Years 🗓️*\n',  mo, ' *Month 🌙*\n', d, ' *Days ☀️*\n', h, ' *Hours 🕐*\n', m, ' *Minute ⏰*\n', s, ' *Second ⏱️*'].map(v => v.toString().padStart(2, 0)).join('')
}
function ucapan() {
  const time = moment.tz('Asia/Jakarta').format('HH')
  let res = "Kok Belum Tidur Kak? 🥱"
  if (time >= 4) {
    res = "Pagi Kak 🌄"
  }
  if (time >= 10) {
    res = "Siang Kak ☀️"
  }
  if (time >= 15) {
    res = "Sore Kak 🌇"
  }
  if (time >= 18) {
    res = "Malam Kak 🌙"
  }
  return res
}

/*backup fix beton
import { promises, readFileSync } from 'fs'
import { join } from 'path'
import { xpRange } from '../lib/levelling.js'
import moment from 'moment-timezone'
import os from 'os'
import fs from 'fs'
import fetch from 'node-fetch'
const { generateWAMessageFromContent, proto } = (await import('baileys')).default

const defaultMenu = {
  before: `
`.trimStart(),
  header: '',
  body: '',
  footer: '',
  after: '',
}
let ponta =`*私は *${global.namebot}* です。ステッカーの作成、コンテンツのダウンロード、AI などをお手伝いする WhatsApp ボットです。🍁

*.allmenu*
> ( untuk menampilkan semua fitur )
*.listmenu*
> ( untuk menampilkan menu simpel )
*.owner*
> ( untuk menanyakan sesuatu )

_Note: Jika Kamu tidak tahu cara Menggunakan Bot Kamu bisa ketik .tutorial_`
let handler = async (m, { conn, usedPrefix: _p, __dirname, args, command}) => {
let tags = {
'yuemenu': { }
}
 
  try {
  	// DEFAULT MENU
      let dash = global.dashmenu
  	let m1 = global.dmenut
      let m2 = global.dmenub
      let m3 = global.dmenuf
      let m4 = global.dmenub2
      
      // COMMAND MENU
      let cc = global.cmenut
      let c1 = global.cmenuh
      let c2 = global.cmenub
      let c3 = global.cmenuf
      let c4 = global.cmenua
      
      // LOGO L P
      let lprem = global.lopr
      let llim = global.lolm
      let tag = `@${m.sender.split('@')[0]}`
    
    //-----------TIME---------
    let ucpn = `${ucapan()}`
    let d = new Date(new Date + 3600000)
    let locale = 'id'
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
    let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
    let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
    // d.getTimeZoneOffset()
    // Offset -420 is 18.00
    // Offset    0 is  0.00
    // Offset  420 is  7.00
    let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
    let dateIslamic = Intl.DateTimeFormat(locale + '-TN-u-ca-islamic', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }).format(d)
    let time = d.toLocaleTimeString(locale, {
      hour: 'numeric',
      minute: 'numeric',
      second: 'numeric'
    })
    let _uptime = process.uptime() * 1000
    let _muptime
    if (process.send) {
      process.send('uptime')
      _muptime = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }
    let muptime = clockString(_muptime)
    let uptime = clockString(_uptime)
    let _mpt
    if (process.send) {
      process.send('uptime')
      _mpt = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }
    let mpt = clockString(_mpt)
    let usrs = db.data.users[m.sender]
      
    let wib = moment.tz('Asia/Jakarta').format('HH:mm:ss')
    let wibh = moment.tz('Asia/Jakarta').format('HH')
    let wibm = moment.tz('Asia/Jakarta').format('mm')
    let wibs = moment.tz('Asia/Jakarta').format('ss')
    let wit = moment.tz('Asia/Jayapura').format('HH:mm:ss')
    let wita = moment.tz('Asia/Makassar').format('HH:mm:ss')
    let wktuwib = `${wibh} H ${wibm} M ${wibs} S`
 
    let mode = global.opts['self'] ? 'Private' : 'Publik'
    let _package = JSON.parse(await promises.readFile(join(__dirname, '../package.json')).catch(_ => ({}))) || {}
    let { age, exp, limit, level, role, registered, eris} = global.db.data.users[m.sender]
    let { min, xp, max } = xpRange(level, global.multiplier)
    let name = await conn.getName(m.sender)
    let premium = global.db.data.users[m.sender].premiumTime
    let prems = `${premium > 0 ? 'Premium': 'Free'}`
    let platform = os.platform()
    
    //---------------------
    
    let totalreg = Object.keys(global.db.data.users).length
    let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length
    let help = Object.values(global.plugins).filter(plugin => !plugin.disabled).map(plugin => {
      return {
        help: Array.isArray(plugin.tags) ? plugin.help : [plugin.help],
        tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
        prefix: 'customPrefix' in plugin,
        limit: plugin.limit,
        premium: plugin.premium,
        enabled: !plugin.disabled,
      }
    })
    let groups = {}
    for (let tag in tags) {
      groups[tag] = []
      for (let plugin of help)
        if (plugin.tags && plugin.tags.includes(tag))
          if (plugin.help) groups[tag].push(plugin)
          }
    conn.menu = conn.menu ? conn.menu : {}
    let before = conn.menu.before || defaultMenu.before
    let header = conn.menu.header || defaultMenu.header
    let body = conn.menu.body || defaultMenu.body
    let footer = conn.menu.footer || defaultMenu.footer
    let after = conn.menu.after || (conn.user.jid == global.conn.user.jid ? '' : `Powered by https://wa.me/${global.conn.user.jid.split`@`[0]}`) + defaultMenu.after
    let _text = [
      before,
      ...Object.keys(tags).map(tag => {
        return header.replace(/%category/g, tags[tag]) + '\n' + [
          ...help.filter(menu => menu.tags && menu.tags.includes(tag) && menu.help).map(menu => {
            return menu.help.map(help => {
              return body.replace(/%cmd/g, menu.prefix ? help : '%_p' + help)
                .replace(/%islimit/g, menu.limit ? llim : '')
                .replace(/%isPremium/g, menu.premium ? lprem : '')
                .trim()
            }).join('\n')
          }),
          footer
        ].join('\n')
      }),
      after
    ].join('\n')
    let text = typeof conn.menu == 'string' ? conn.menu : typeof conn.menu == 'object' ? _text : ''
    let replace = {
      '%': '%',
      p: uptime, muptime,
      me: conn.getName(conn.user.jid),
      npmname: _package.name,
      npmdesc: _package.description,
      version: _package.version,
      exp: exp - min,
      maxexp: xp,
      totalexp: exp,
      xp4levelup: max - exp,
      github: _package.homepage ? _package.homepage.url || _package.homepage : '[unknown github url]',
      tag, dash,m1,m2,m3,m4,cc, c1, c2, c3, c4,lprem,llim,
      ucpn,platform, wib, mode, _p, eris, age, tag, name, prems, level, limit, name, weton, week, date, dateIslamic, time, totalreg, rtotalreg, role,
      readmore: readMore
    }
    text = text.replace(new RegExp(`%(${Object.keys(replace).sort((a, b) => b.length - a.length).join`|`})`, 'g'), (_, name) => '' + replace[name])
    
 let fkon = { key: { fromMe: false, participant: `${m.sender.split`@`[0]}@s.whatsapp.net`, ...(m.chat ? { remoteJid: '16504228206@s.whatsapp.net' } : {}) }, message: { contactMessage: { displayName: `${name}`, vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;a,;;;\nFN:${name}\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`}}}

     conn.sendMessage(m.chat, {
  text: ponta,
  contextInfo: {
  externalAdReply: {
  title: global.namebot,
  body: global.author,
  thumbnailUrl: global.thumb,
  sourceUrl: global.myweb,
  mediaType: 1,
  renderLargerThumbnail: true
  }}}, { quoted: floc })
            
  } catch (e) {
    conn.reply(m.chat, 'Maaf, menu sedang error', m)
    throw e
  }
}
handler.help = ['menu']
handler.tags = ['main']
handler.command = /^(menu|help|\?)$/i

handler.register = true
handler.exp = 3

export default handler

//----------- FUNCTION -------

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

function clockString(ms) {
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [h, ' H ', m, ' M ', s, ' S '].map(v => v.toString().padStart(2, 0)).join('')
}
function clockStringP(ms) {
  let ye = isNaN(ms) ? '--' : Math.floor(ms / 31104000000) % 10
  let mo = isNaN(ms) ? '--' : Math.floor(ms / 2592000000) % 12
  let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000) % 30
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [ye, ' *Years 🗓️*\n',  mo, ' *Month 🌙*\n', d, ' *Days ☀️*\n', h, ' *Hours 🕐*\n', m, ' *Minute ⏰*\n', s, ' *Second ⏱️*'].map(v => v.toString().padStart(2, 0)).join('')
}
function ucapan() {
  const time = moment.tz('Asia/Jakarta').format('HH')
  let res = "Kok Belum Tidur Kak? 🥱"
  if (time >= 4) {
    res = "Pagi Kak 🌄"
  }
  if (time >= 10) {
    res = "Siang Kak ☀️"
  }
  if (time >= 15) {
    res = "Sore Kak 🌇"
  }
  if (time >= 18) {
    res = "Malam Kak 🌙"
  }
  return res
}*/