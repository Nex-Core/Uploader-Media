import axios from "axios";
import { generateWAMessageFromContent, generateWAMessage } from 'baileys';

const handler = async (m, { conn, text, usedPrefix, command }) => {
    const Ar = {
        key: {
            participant: '0@s.whatsapp.net',
            remoteJid: "0@s.whatsapp.net",
            fromMe: false,
            id: "Halo",
        },
        message: {
            conversation: m.text
        }
    };

    if (!text) {
        return conn.reply(
            m.chat,
            `Link nya mana?\nEX: ${usedPrefix + command} https://vt.tiktok.com/xxx/`,
            Ar
        );
    }

    await conn.sendMessage(m.chat, { react: { text: '🍁', key: m.key } });

    try {
        const data = await tikwm(text);
        let caption = `\`T I K T O K   D O W N L O A D E D\`\n\nRequest By ${m.pushName || 'Pengguna'}`;

        if (data.images && data.images.length > 0) {
            let images = [];
            
            for (let i = 0; i < data.images.length; i++) {
                images.push({
                    image: { url: data.images[i] },
                    caption: `Slide ${i + 1} dari ${data.images.length}\n\n${caption}`
                });
            }

            if (images.length === 1) {
                await conn.sendMessage(m.chat, images[0], { quoted: Ar });
            } else {
                await sendAlbum(conn, m.chat, images, { quoted: Ar });
            }
        } else {
            const sentMsg = await conn.sendMessage(m.chat, {
                video: { url: data.play },
                caption
            }, { quoted: Ar });

            setTimeout(async () => {
                try {
                    await conn.sendMessage(m.chat, { delete: sentMsg.key });
                } catch (err) {
                    console.error("Gagal hapus video:", err.message);
                }
            }, 30000);
        }

        if (data.music) {
            await conn.sendMessage(m.chat, {
                audio: { url: data.music },
                mimetype: 'audio/mpeg'
            }, { quoted: Ar });
        }

        await conn.sendMessage(m.chat, { react: { text: '🌸', key: m.key } });

    } catch (error) {
        console.error(error);
        conn.reply(m.chat, "Terjadi kesalahan saat memproses link TikTok.", Ar);
    }
};

handler.help = ['tiktok'].map(v => v + ' <url>');
handler.tags = ['downloader'];
handler.command = /^(tiktok|tt)$/i;
handler.register = true;
handler.limit = 2;

export default handler;

async function sendAlbum(conn, jid, medias, options = {}) {
  const userJid = conn.user?.id || conn.authState?.creds?.me?.id;
  if (!Array.isArray(medias) || medias.length < 1) {
    throw new Error("Album minimal berisi 1 media (gambar/video).");
  }

  const time = options.delay || 500;
  delete options.delay;

  const album = await generateWAMessageFromContent(
    jid,
    {
      albumMessage: {
        expectedImageCount: medias.filter(m => m.image).length,
        expectedVideoCount: medias.filter(m => m.video).length
      }
    },
    { userJid, ...options }
  );

  await conn.relayMessage(jid, album.message, { messageId: album.key.id });

  for (const media of medias) {
    if (!(media.image || media.video)) continue;

    const msg = await generateWAMessage(
      jid,
      {
        ...(media.image ? { image: media.image } : {}),
        ...(media.video ? { video: media.video } : {}),
        caption: media.caption || "",
        ...options
      },
      {
        userJid,
        upload: async (readStream, opts) => {
          return await conn.waUploadToServer(readStream, opts);
        },
        ...options
      }
    );

    msg.message.messageContextInfo = {
      messageAssociation: {
        associationType: 1,
        parentMessageKey: album.key
      }
    };

    await conn.relayMessage(jid, msg.message, { messageId: msg.key.id });
    await new Promise(res => setTimeout(res, time));
  }

  return album;
}

async function tikwm(url) {
    let retries = 0;
    const maxRetries = 5;
    const retryDelay = 3000;

    while (retries < maxRetries) {
        try {
            const res = await axios.get(`https://tikwm.com/api/?url=${encodeURIComponent(url)}`);
            if (res.data && res.data.data) return res.data.data;
            throw new Error(res.data.msg || "Gagal memuat data");
        } catch (e) {
            console.error(`Retry ${retries + 1}: ${e.message}`);
            retries++;
            if (retries >= maxRetries) throw e;
            await new Promise(resolve => setTimeout(resolve, retryDelay));
        }
    }
}