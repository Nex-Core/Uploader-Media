let handler = async(m, { conn, command, args, participants }) => {
   let users = Object.entries(global.db.data.users).map(([key, value]) => {
    return {...value, jid: key}
  })
  let sortedExp = users.map(toNumber('exp')).sort(sort('exp'))
   let len = args[0] && args[0].length > 0 ? Math.min(10, Math.max(parseInt(args[0]), 10)) : Math.min(10, sortedExp.length)
   
   if (command === 'lbexp') {
   let usersExp = sortedExp.map(enumGetKey)
   let text = `\tぶ 𝗹 𝗲 𝗮 𝗱 𝗲 𝗿 𝗯 𝗼 𝗮 𝗿 𝗱 🏆
• *🧪 XP Leaderboard Top ${len}* •
🎖️ Posisi Kamu : *${usersExp.indexOf(m.sender) + 1}* dari *${usersExp.length}*

${sortedExp.slice(0, len).map(({ jid, exp }, i) => `${formatRank(i)}. *${participants.some(p => jid === p.jid) ? `(${conn.getName(jid)}) wa.me/` : '@'}${jid.split`@`[0]}*    ${formatNumber(exp)}`).join`\n`}
▬▭▬▭▬▭▬▭▬▭▬▭`
   conn.reply(m.chat, text, floc, {
    contextInfo: {
      mentionedJid: [...usersExp.slice(0, len)].filter(v => !participants.some(p => v === p.jid))
    }
  })
   } else if (command === 'lbmoney') {
   let sortedEris = users.map(toNumber('eris')).sort(sort('eris'))
   let usersEris = sortedEris.map(enumGetKey)
   let text = `\tぶ 𝗹 𝗲 𝗮 𝗱 𝗲 𝗿 𝗯 𝗼 𝗮 𝗿 𝗱 🏆
   
• *💵 Money Leaderboard Top ${len}* •
🎖️ Posisi Kamu : *${usersEris.indexOf(m.sender) + 1}* dari *${usersEris.length}*

${sortedEris.slice(0, len).map(({ jid, eris }, i) => `${formatRank(i)}. *${participants.some(p => jid === p.jid) ? `(${conn.getName(jid)}) wa.me/` : '@'}${jid.split`@`[0]}*    ${formatNumber(eris)}`).join`\n`}
▬▭▬▭▬▭▬▭▬▭▬▭`
   conn.reply(m.chat, text, floc, {
    contextInfo: {
      mentionedJid: [...usersEris.slice(0, len)].filter(v => !participants.some(p => v === p.jid))
    }
  })
   } else if (command === 'lblimit') {
   let sortedLim = users.map(toNumber('limit')).sort(sort('limit'))
   let usersLim = sortedLim.map(enumGetKey)
   let text = `\tぶ 𝗹 𝗲 𝗮 𝗱 𝗲 𝗿 𝗯 𝗼 𝗮 𝗿 𝗱 🏆
   
• *💳 Limit Leaderboard Top ${len}* •
🎖️ Posisi Kamu : *${usersLim.indexOf(m.sender) + 1}* dari *${usersLim.length}*

${sortedLim.slice(0, len).map(({ jid, limit }, i) => `${formatRank(i)}. *${participants.some(p => jid === p.jid) ? `(${conn.getName(jid)}) wa.me/` : '@'}${jid.split`@`[0]}*    ${formatNumber(limit)}`).join`\n`}
▬▭▬▭▬▭▬▭▬▭▬▭`
   conn.reply(m.chat, text, floc, {
    contextInfo: {
      mentionedJid: [...usersLim.slice(0, len)].filter(v => !participants.some(p => v === p.jid))
    }
  })
   } else if (command === 'lblevel') {
   let sortedLevel = users.map(toNumber('level')).sort(sort('level'))
   let usersLevel = sortedLevel.map(enumGetKey)
   let text = `\tぶ 𝗹 𝗲 𝗮 𝗱 𝗲 𝗿 𝗯 𝗼 𝗮 𝗿 𝗱 🏆

• *🎗️ Level Leaderboard Top ${len}* •
🎖️ Posisi Kamu : *${usersLevel.indexOf(m.sender) + 1}* dari *${usersLevel.length}*

${sortedLevel.slice(0, len).map(({ jid, level }, i) => `${formatRank(i)}. *${participants.some(p => jid === p.jid) ? `(${conn.getName(jid)}) wa.me/` : '@'}${jid.split`@`[0]}*    Level ${level}`).join`\n`}
▬▭▬▭▬▭▬▭▬▭▬▭`
   conn.reply(m.chat, text, floc, {
    contextInfo: {
      mentionedJid: [...usersLevel.slice(0, len)].filter(v => !participants.some(p => v === p.jid))
    }
  })
   } else if (command === 'lbsub') {
   let sortedSubscribers = users.map(toNumber('subscribers')).sort(sort('subscribers'))
   let usersSubs = sortedSubscribers.map(enumGetKey)
   let text = `\tぶ 𝗹 𝗲 𝗮 𝗱 𝗲 𝗿 𝗯 𝗼 𝗮 𝗿 𝗱 🏆

• *🌐 Subscriber Leaderboard Top ${len}* •
🎖️ Posisi Kamu : *${usersSubs.indexOf(m.sender) + 1}* dari *${usersSubs.length}*

${sortedSubscribers.slice(0, len).map(({ jid, subscribers }, i) => `${formatRank(i)}. *${participants.some(p => jid === p.jid) ? `(${conn.getName(jid)}) wa.me/` : '@'}${jid.split`@`[0]}*    ${formatNumber(subscribers)}`).join`\n`}
▬▭▬▭▬▭▬▭▬▭▬▭`
    conn.reply(m.chat, text, floc, {
    contextInfo: {
      mentionedJid: [...usersSubs.slice(0, len)].filter(v => !participants.some(p => v === p.jid))
    }
  })
   } else if (command === 'lbdamage') {
   let sortedDamage = users.map(toNumber('damage')).sort(sort('damage'))
   let usersDamage = sortedDamage.map(enumGetKey)
   let text = `\tぶ 𝗹 𝗲 𝗮 𝗱 𝗲 𝗿 𝗯 𝗼 𝗮 𝗿 𝗱 🏆

• *💥 Damage Leaderboard Top ${len}* •
🥇 Posisi Kamu : *${usersDamage.indexOf(m.sender) + 1}* dari *${usersDamage.length}*

${sortedDamage.slice(0, len).map(({ jid, damage }, i) => `${formatRank(i) }. *${participants.some(p => jid === p.jid) ? `(${conn.getName(jid)}) wa.me/` : '@'}${jid.split`@`[0]}* ${formatNumber(damage)}`).join`\n`}
▬▭▬▭▬▭▬▭▬▭▬▭`
    conn.reply(m.chat, text, floc, {
    contextInfo: {
      mentionedJid: [...usersDamage.slice(0, len)].filter(v => !participants.some(p => v === p.jid))
    }
  })
   } else if (command === 'lbastro') {
   let sortedTotal = users.map(toNumber('totalb')).sort(sort('totalb'))
   let usersTotal = sortedTotal.map(enumGetKey)
   let nuy = args[0] && args[0].length > 0 ? Math.min(10, Math.max(parseInt(args[0]), 10)) : Math.min(10, sortedTotal.length)
   let text = `\tぶ 𝗹 𝗲 𝗮 𝗱 𝗲 𝗿 𝗯 𝗼 𝗮 𝗿 𝗱 🏆

• *👨🏻‍🚀 Astronot Leaderboard Top ${nuy}* •
🥇 Posisi Kamu : *${usersTotal.indexOf(m.sender) + 1}* dari *${usersTotal.length}*

${sortedTotal.slice(0, nuy).map(({ jid, totalb }, i) => `${formatRank(i) }. *${participants.some(p => jid === p.jid) ? `(${conn.getName(jid)}) wa.me/` : '@'}${jid.split`@`[0]}* ${formatNumber(totalb)}x Berangkat`).join`\n`}
▬▭▬▭▬▭▬▭▬▭▬▭`
    conn.reply(m.chat, text, floc, {
    contextInfo: {
      mentionedJid: [...usersTotal.slice(0, len)].filter(v => !participants.some(p => v === p.jid))
    }
  })
  } else if (command === 'lbsampah') {
   let sortedTotals = users.map(toNumber('sampah')).sort(sort('sampah'))
   let usersTotals = sortedTotals.map(enumGetKey)
   let saa = args[0] && args[0].length > 0 ? Math.min(10, Math.max(parseInt(args[0]), 10)) : Math.min(10, sortedTotals.length)
   let text = `\tぶ 𝗹 𝗲 𝗮 𝗱 𝗲 𝗿 𝗯 𝗼 𝗮 𝗿 𝗱 🏆

• *📦 Mulung Leaderboard Top ${saa}* •
🥇 Posisi Kamu : *${usersTotals.indexOf(m.sender) + 1}* dari *${usersTotals.length}*

${usersTotals.slice(0, saa).map(({ jid, sampah }, i) => `${formatRank(i) }. *${participants.some(p => jid === p.jid) ? `(${conn.getName(jid)}) wa.me/` : '@'}${jid.split`@`[0]}* ${formatNumber(sampah)} sampah`).join`\n`}
▬▭▬▭▬▭▬▭▬▭▬▭`
    conn.reply(m.chat, text, floc, {
    contextInfo: {
      mentionedJid: [...usersTotals.slice(0, saa)].filter(v => !participants.some(p => v === p.jid))
    }
  })
   }
}

handler.command = /^lb(exp|money|limit|level|sub|damage|astro|sampah)$/i

export default handler;

function sort(property, ascending = true) {
  if (property) return (...args) => args[ascending & 1][property] - args[!ascending & 1][property]
  else return (...args) => args[ascending & 1] - args[!ascending & 1]
}

function toNumber(property, _default = 0) {
  if (property) return (a, i, b) => {
    return {...b[i], [property]: a[property] === undefined ? _default : a[property]}
  }
  else return a => a === undefined ? _default : a
}

function enumGetKey(a) {
  return a.jid
}

function formatRank(i) {
    return i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : (i + 1).toString();
  }
  
function formatNumber(num) {
  const suffixes = ['', 'Rb', 'Jt', 'M', 'T', 'Qa', 'Qi', 'Sk', 'Sp', 'Ot', 'Nn', 'Ds'];
  const numString = Math.abs(num).toString();
  const numDigits = numString.length;

  if (numDigits <= 3) {
    return numString;
  }

  const suffixIndex = Math.floor((numDigits - 1) / 3);
  let formattedNum = (num / Math.pow(1000, suffixIndex)).toFixed(1);
  
  // Menghapus desimal jika angka sudah bulat
  if (formattedNum.endsWith('.0')) {
    formattedNum = formattedNum.slice(0, -2);
  }

  return formattedNum + suffixes[suffixIndex];
}