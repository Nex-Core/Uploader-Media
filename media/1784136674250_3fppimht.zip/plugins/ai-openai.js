import axios from "axios";

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return conn.sendMessage(
      m.chat,
      { text: `✿ EX:\n${usedPrefix + command} halo kamu ai apa?` },
      { quoted: floc }
    );
  }

  await conn.sendMessage(m.chat, { react: { text: "✨", key: m.key } });

  try {
    const api = `https://api.nexray.web.id/ai/openai?text=${encodeURIComponent(text)}`;

    const { data } = await axios.get(api);

    if (!data.status || !data.result) {
      throw new Error("Gagal mendapatkan respon dari AI");
    }

    await conn.sendMessage(
      m.chat,
      { text: data.result },
      { quoted: floc }
    );

  } catch (e) {
    await conn.sendMessage(
      m.chat,
      { text: `Terjadi kesalahan:\n${e.message}` },
      { quoted: floc }
    );
  } finally {
    await conn.sendMessage(m.chat, { react: { text: "", key: m.key } });
  }
};

handler.help = ['openai'].map(a => a + " <pertanyaan>");
handler.tags = ['ai'];
handler.command = /^(ai|openai|nishi)$/i;
handler.register = true;
handler.limit = true;

export default handler;