const { proto, generateWAMessageFromContent } = (await import('baileys')).default;

let handler = async (m, { conn, command }) => {
    let ruang = conn.mabar[m.chat];
    conn.dungeonparty = conn.dungeonparty || {};
    let room = conn.dungeonparty[m.chat];

    if (ruang && ruang.state === 'pilihserver' && m.sender === ruang.master) {
        let user = global.db.data.users[m.sender];
        let monsters = {
            easy: ['Shadow Spriggan', 'Mist Wisp', 'Feral Imp', 'Crystal Beetle', 'Gloom Pixie'],
            normal: ['Abyssal Gnoll', 'Frost Harpy', 'Cinder Hound', 'Void Banshee', 'Iron Kobold'],
            hard: ['Starfang Minotaur', 'Eclipse Wyrm', 'Bloodmare Centaur', 'Dusk Cyclops', 'Flame Oni'],
            extreme: ['Astral Lich', 'Nether Kraken', 'Soul Devourer', 'Chaos Behemoth', 'Shadow Kitsune'],
            bos: ['Celestial Orochi', 'Abyss Overlord', 'Starborn Titan', 'Eclipse Samurai', 'Void Shogun'],
            abyss: ['Ethereal Leviathan', 'Dark Seraphim', 'Oblivion Drake', 'Nebula Oni', 'Cosmic Wraith'],
            king: ['Astral Warlord', 'Ecliptic Sovereign', 'Skyforge Behemoth', 'Nether Monarch', 'Starlight Emperor'],
            emperor: ['Crimson Overking', 'Void Archduke', 'Aether Tyrant', 'Eclipse Daimyo', 'Oblivion Kaiser'],
            demigod: ['Divine Shogun', 'Celestial Ronin', 'Eternal Samurai', 'Astral Warmaiden', 'Cosmic Overlord'],
            god: ['Primordial Kami', 'Ethereal Deity', 'Starvoid Sovereign', 'Chaos Divinity', 'Aetherial Monarch']
        };

        const levels = {
            party_easy: { level: 10, health: 90 },
            party_normal: { level: 20, health: 150 },
            party_hard: { level: 30, health: 200 },
            party_extreme: { level: 40, health: 250 },
            party_bos: { level: 100, health: 300 },
            party_abyss: { level: 150, health: 350 },
            party_king: { level: 180, health: 400 },
            party_emperor: { level: 250, health: 450 },
            party_demigod: { level: 500, health: 500 },
            party_god: { level: 1000, health: 500 }
        };

        let levelData = levels[command];
        if (!levelData) return m.reply('Server tidak valid!');

        if (user.level < levelData.level) return m.reply(`Kamu membutuhkan *Level ${levelData.level}* untuk bermain di server *${command.replace('party_', '')}*!`);
        if (user.health < levelData.health) return m.reply(`Health kamu kurang dari *${levelData.health} ❤️*!`);

        conn.dungeonparty[m.chat] = {
            id: Math.floor(Math.random() * 100000000).toString(),
            p: m.sender,
            players: [m.sender],
            nameserver: command.replace('party_', ''),
            cdserver: 1800000,
            healtserver: levelData.health,
            monster: pickRandom(monsters[command.replace('party_', '')]),
            status: 'wait'
        };

        room = conn.dungeonparty[m.chat];
        let playerList = room.players.map((player, index) => `*${index + 1}.* @${player.replace(/@.+/, '')} (${global.db.data.users[player].skill})`).join('\n');
        let buatRoom = `🔱 Berhasil membuat room\n*Room ID:* ${room.id}\n*Server:* ${command.replace('party_', '').charAt(0).toUpperCase() + command.replace('party_', '').slice(1)}\n\n♻️ Menunggu pemain lain untuk join`;
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: buatRoom,
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: "*© Nishi chisato*"
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            title: "\t🏅 *PARTY ROOM* 🏅\n",
                            subtitle: "",
                            hasMediaAttachment: false
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: "{\"display_text\":\"♻️ Join\",\"id\":\"party_join\"}"
                                },
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: "{\"display_text\":\"🚫 Batalkan\",\"id\":\"party_cancel\"}"
                                },
                            ],
                        })
                    })
                },
            }
        }, {});
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        delete conn.mabar[m.chat];
    }
};

handler.command = /^(party_easy|party_normal|party_hard|party_extreme|party_bos|party_abyss|party_king|party_emperor|party_demigod|party_god)$/i;
handler.group = true;

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)];
}

export default handler;