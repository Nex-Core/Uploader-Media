import axios from 'axios';
import fs from 'fs';
import child_process from 'child_process';

const fetchJson = async (url, options = {}) => {
    const response = await axios.get(url, { ...options, responseType: 'json' });
    return response.data;
};

const sleep = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

const GIFBufferToVideoBuffer = async (image) => {
    const filename = `${Math.random().toString(36)}`;
    await fs.writeFileSync(`./tmp/${filename}.gif`, image);
    child_process.exec(
        `ffmpeg -i ./tmp/${filename}.gif -movflags faststart -pix_fmt yuv420p -vf "scale=trunc(iw/2)*2:trunc(ih/2)*2" ./tmp/${filename}.mp4`
    );
    await sleep(4000);
    const buffer = await fs.readFileSync(`./tmp/${filename}.mp4`);
    await Promise.all([fs.promises.unlink(`./tmp/${filename}.mp4`), fs.promises.unlink(`./tmp/${filename}.gif`)]);
    return buffer;
};

const commandsConfig = {
    hug: { endpoint: 'hug', action: 'hugged' },
    cry: { endpoint: 'cry', action: 'cried for' },
    kill: { endpoint: 'kill', action: 'killed' },
    pat: { endpoint: 'pat', action: 'patted' },
    lick: { endpoint: 'lick', action: 'licked' },
    kiss: { endpoint: 'kiss', action: 'kissed' },
    bite: { endpoint: 'bite', action: 'bit' },
    yeet: { endpoint: 'yeet', action: 'yeeted' },
    bully: { endpoint: 'bully', action: 'bullied' },
    bonk: { endpoint: 'bonk', action: 'bonked' },
    wink: { endpoint: 'wink', action: 'winked at' },
    poke: { endpoint: 'poke', action: 'poked' },
    nom: { endpoint: 'nom', action: 'nommed' },
    slap: { endpoint: 'slap', action: 'slapped' },
    smile: { endpoint: 'smile', action: 'smiled at' },
    wave: { endpoint: 'wave', action: 'waved at' },
    awoo: { endpoint: 'awoo', action: 'awooed at' },
    blush: { endpoint: 'blush', action: 'blushed at' },
    smug: { endpoint: 'smug', action: 'smugged at' },
    glomp: { endpoint: 'glomp', action: 'glomped' },
    happy: { endpoint: 'happy', action: 'happied' },
    dance: { endpoint: 'dance', action: 'danced with' },
    cringe: { endpoint: 'cringe', action: 'cringed at' },
    cuddle: { endpoint: 'cuddle', action: 'cuddled' },
    highfive: { endpoint: 'highfive', action: 'highfived' },
    handhold: { endpoint: 'handhold', action: 'held hands with' },
    feed: { endpoint: 'feed', action: 'fed' },
    tickle: { endpoint: 'tickle', action: 'tickled' },
};

const handler = async (m, { command, conn }) => {
    if (!m.mentionedJid[0] && !m.quoted) return m.reply('Tag atau balas seseorang!');

    await conn.sendMessage(m.chat, { react: { text: '🕓', key: m.key } });

    const config = commandsConfig[command];
    if (!config) return m.reply('Perintah tidak ditemukan!');

    try {
        const pat = await fetchJson(`https://api.waifu.pics/sfw/${config.endpoint}`);
        const response = await axios.get(pat.url, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(response.data, 'utf-8');
        const fetchedgif = await GIFBufferToVideoBuffer(buffer);

        const sender = m.sender;
        const target = m.mentionedJid[0] || m.quoted?.sender || sender;
        const caption = sender === target
            ? `@${sender.split('@')[0]} ${config.action} themselves!`
            : `@${sender.split('@')[0]} ${config.action} @${target.split('@')[0]}`;

        await conn.sendMessage(
            m.chat,
            { video: fetchedgif, gifPlayback: true, mentions: [sender, target], caption },
            { quoted: floc }
        );
    } catch (error) {
        console.error(`Error: ${error.message}\nStack: ${error.stack}`);
        m.reply(`Terjadi kesalahan: ${error.message}`);
    }
};

handler.command = Object.keys(commandsConfig);
handler.tags = ['fun'];
handler.help = Object.keys(commandsConfig);
handler.group = true;
handler.register = true;

export default handler;