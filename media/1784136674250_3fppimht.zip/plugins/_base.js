let handler = async (m, { conn, isOwner }) => {
  let kon = `
*🛒 Sell Script Bot Nishikigi Chisato* ✨

*🧾 Features on Bot*  
*Total Features: 1000+* 🚀  
🌟 *AI Features*  
- 🤖 AI GPT  
- 🌐 AI OpenAI  
- 🧑‍🎤 AI Character  
- 📸 AI Gemini (Image Support)  
- 🎨 AI Mirror (Image Filter)  
- 🖌️ AI ToAnime  
- 🔍 Using Scraper  
- ➕ And More!  

📥 *Download Features*  
- 📷 Instagram  
- 🎵 TikTok  
- 🎥 TikTok (HD)  
- 📘 Facebook  
- 📹 Facebook (HD)  
- 🖼️ Pinterest (Video Download)  
- 🎞️ YouTube Download (MP3/MP4) Using Scraper  
- 🔗 Full Scraper Support  
- ➕ And More!  

🎮 *Game Features*  
- 🧠 TebakKata  
- 💣 TebakBom  
- 🎌 TebakAnime  
- 🎮 TebakGame  
- 🎤 TebakLirik  
- 🎶 TebakLagu  
- ❓ SiapakahAku?  
- 👨‍👩‍👧‍👦 Family100  
- 📹 YouTuber  
- ➕ And More!  

🗡️ *RPG New Features*  
- 👥 Play with Friends  
- 🏰 Dungeon Server Room  
- 🚀 Astronot Server Room  
- 🗺️ Explore Server Room  
- ➕ And More!  

*🧾 Script Info*  
- 📜 Script Baileys  
- 🧩 Type: Plugins  
- 📦 Module: ESM (baileys)  
- 🔘 Supports All Buttons  

*🏷️ Price List*  
- 💰 *75K*  
  - 🚫 No Updates  

- 💸 *110K*  
  - Garansi: 2 Months  
  - 🔄 Free Updates  

- 🎉 *250K*  
  - Garansi: Permanent  
  - 🔄 Free Updates  

*🔗 You can try it here:*  
📩 *Interested? Contact Owner!*  
- WhatsApp Owner: https://wa.me/6283854025278
`;

  try {
    await conn.sendMessage(m.chat, {
      text: kon,
      contextInfo: {
        forwardingScore: 999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: "120363384344978130@newsletter",
          newsletterName: global.namebot,
        },
        externalAdReply: {
          title: titlebot,
          thumbnailUrl: global.thumb,
          sourceUrl: global.sgc,
          mediaType: 1,
          renderLargerThumbnail: true,
        },
        mentionedJid: [m.sender],
      },
    }, { quoted: floc });
  } catch (e) {
    conn.reply(m.chat, 'Maaf, menu sedang error', m);
    throw e;
  }
};

handler.command = /^(sc|sourcecode|script)$/i;
handler.tags = ['info'];
handler.help = ['sc'];

export default handler;