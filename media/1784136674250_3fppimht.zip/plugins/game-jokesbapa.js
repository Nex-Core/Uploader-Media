import fs from 'fs'

const jokesData = JSON.parse(fs.readFileSync('./json/jokes-bapak.json', 'utf-8'))

async function handler(m) {
    this.jokesBapack = this.jokesBapack || {}
    let id = 'jokesbapak_' + m.chat
    
    if (id in this.jokesBapack) {
        return this.reply(m.chat, '⚠️ Masih ada jokes yang belum dijawab!\n\nKetik jawabanmu atau ketik *nyerah* untuk menyerah.', this.jokesBapack[id].msg)
    }
    
    const randomJoke = jokesData[Math.floor(Math.random() * jokesData.length)]
    
    const caption = `🤣 *JOKES BAPAK-BAPAK*

❓ ${randomJoke.setup}

💰 Hadiah: Money 500.000

_Ketik jawabanmu atau "nyerah" untuk menyerah_`

    const msg = await this.reply(m.chat, caption, m)
    
    this.jokesBapack[id] = {
        id,
        msg,
        answer: randomJoke.answer,
        setup: randomJoke.setup
    }
}

handler.help = ['jokesbapak']
handler.tags = ['game']
handler.command = /^(jokesbapa(k)?|jokesreceh|jokeslucu)$/i

export default handler