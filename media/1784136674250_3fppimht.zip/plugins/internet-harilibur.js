import axios from 'axios'
import cheerio from 'cheerio'

let handler = async (m, { conn }) => {
  m.reply('⏳ Sedang memuat...')
  try {
    let teks = `🎉 *${(await nexLibur()).nextLibur}* 🎉\n\n`
    let result = (await nexLibur()).libnas_content

    for (let a of result) {
      teks += `📅 *Ringkasan:* ${a.summary}\n🔖 *Hari:* ${a.days}\n📆 *Bulan:* ${a.dateMonth}\n\n`
      teks += '----------------------------\n'
    }
    conn.reply(m.chat, teks, m)
  } catch (e) {
    throw e
  }
}

handler.help = ['harilibur']
handler.command = ['harilibur', 'nextlibur']
handler.tags = ['internet']

export default handler

async function nexLibur() {
  const { data } = await axios.get("https://www.liburnasional.com/");
  let libnas_content = [];
  let $ = cheerio.load(data);
  let result = {
    nextLibur:
      "Hari libur" +
      $("div.row.row-alert > div").text().split("Hari libur")[1].trim(),
    libnas_content,
  };
  $("tbody > tr > td > span > div").each(function (a, b) {
    let summary = $(b).find("span > strong > a").text();
    let days = $(b).find("div.libnas-calendar-holiday-weekday").text();
    let dateMonth = $(b).find("time.libnas-calendar-holiday-datemonth").text();
    libnas_content.push({ summary, days, dateMonth });
  });
  return result;
}