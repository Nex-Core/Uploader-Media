let handler = async (m, { conn, participants }) => {
    let users = Object.entries(global.db.data.users)
        .map(([jid, data]) => ({
            jid,
            name: conn.getName(jid) || "User",
            pahala: data.pahala || 0
        }))
        .sort((a, b) => b.pahala - a.pahala) // Urutkan berdasarkan pahala tertinggi
        .slice(0, 10) // Ambil 10 besar

    if (users.length === 0) {
        return conn.reply(m.chat, "📜 *Leaderboard Pahala*\n\n❌ Belum ada data pahala. Mulai mengaji sekarang untuk masuk peringkat! 📖✨", m)
    }

    const formatNumber = (num) => num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')

    let mentions = users.map(u => u.jid)
    let rankingIcons = ["🏆", "🥈", "🥉"] // Ikon ranking 1-3
    let leaderboard = users.map((user, i) => 
        `${rankingIcons[i] || "🎖"} *${i + 1}.* @${user.jid.replace(/@.+/, '')} — *${formatNumber(user.pahala)}* Pahala`
    ).join("\n")

    let message = `
┏━━━🏆 *TOP 10 PAHALA* 🏆━━━┓
📖 Semakin banyak mengaji, semakin tinggi peringkatmu! ✨

${leaderboard}

💡 *Tips:* Rajin mengaji setiap hari untuk naik peringkat! 🕌
┗━━━━━━━━━━━━━━━━━━━━┛
    `.trim()

    conn.reply(m.chat, message, m, { mentions })
}

handler.command = /^(toppahala)$/i
handler.register = true
handler.group = true

export default handler