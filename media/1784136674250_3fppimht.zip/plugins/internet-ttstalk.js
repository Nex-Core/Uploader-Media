import axios from 'axios';
import cheerio from 'cheerio';

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Masukkan username TikTok!\n\nEX: ${usedPrefix}${command} arull_hx`;

  await conn.sendMessage(m.chat, { react: { text: '🌸', key: m.key } });

  const result = await tiktokStalk(text);

  if (!result?.status) throw result.message || 'Profil tidak ditemukan atau terjadi kesalahan!';

  const data = result.data;

  const caption = `
╰╼ ┈─ ⠁◌ ˚Profile Info ⠹ !

⤿ ִ ׄᥴ⃘ᦱ Username ⠲ @${data.user.uniqueId || text}
⤿ ִ ׄᥴ⃘ᦱ Followers ⠲ ${data.stats.followerCount ?? 0}
⤿ ִ ׄᥴ⃘ᦱ Following ⠲ ${data.stats.followingCount ?? 0}
⤿ ִ ׄᥴ⃘ᦱ Likes ⠲ ${data.stats.heartCount ?? 0}
⤿ ִ ׄᥴ⃘ᦱ Bio ⠲ ${data.user.signature || 'Tidak ada bio'}
⤿ ִ ׄᥴ⃘ᦱ Profile ⠲ https://www.tiktok.com/@${text}

     ׄ ֵ ━━━━━━━━━━━━━━━ ֵ ׄׄ
    ˚ 𓊆˒˓ ۫﹢ Love by nishi chi ! ♡. . ⁺ ׅ`;

  if (data.user.avatarLarger?.startsWith('http')) {
    await conn.sendMessage(m.chat, {
      image: { url: data.user.avatarLarger },
      caption
    }, { quoted: floc });
  } else {
    await conn.reply(m.chat, caption, floc);
  }
};

handler.help = ['ttstalk <username>'];
handler.tags = ['internet'];
handler.command = /^(ttstalk|tiktokstalk)$/i;
handler.limit = 2;
handler.register = true;

export default handler;

async function tiktokStalk(username) {
  try {
    const response = await axios.get(`https://www.tiktok.com/@${username}?_t=ZS-8tHANz7ieoS&_r=1`);
    const html = response.data;
    const $ = cheerio.load(html);
    const scriptData = $('#__UNIVERSAL_DATA_FOR_REHYDRATION__').html();
    if (!scriptData) throw new Error('User tidak ditemukan');
    const parsedData = JSON.parse(scriptData);
    const userDetail = parsedData.__DEFAULT_SCOPE__?.['webapp.user-detail'];
    if (!userDetail || !userDetail.userInfo) throw new Error('User tidak ditemukan');
    return {
      author: global.author,
      status: true,
      data: userDetail.userInfo
    };
  } catch (error) {
    return {
      author: global.author,
      status: false,
      message: error.message || 'Terjadi kesalahan'
    };
  }
}