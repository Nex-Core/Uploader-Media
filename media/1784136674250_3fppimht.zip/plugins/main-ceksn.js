import { createHash } from 'crypto';

let handler = async function (m, { conn }) {
  let sn = createHash('md5').update(m.sender).digest('hex');
  let botName = global.namebot || "YourBotName";

  // Get the current date
  let date = new Date().toLocaleDateString('id-ID', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  // Create a URL link for SN
  let snUrl = `https://ar-sensei.com/sn/${sn}`;

  // Send message with formatted tag, date, and SN as clickable URL
  conn.reply(m.chat, `📌 *Tag:* @${m.sender.split('@')[0]}
📅 *Date:* ${date}

🔑 *SN Anda:* ${snUrl}

> *contoh:*  .unreg https://ar-sensei.com/sn/xxxxxx

🤖 *Bot:* ${botName}
  `, floc, { mentions: [m.sender] });
};

handler.help = ['ceksn'];
handler.tags = ['main'];
handler.command = /^(ceksn)$/i;
handler.register = true;

export default handler;