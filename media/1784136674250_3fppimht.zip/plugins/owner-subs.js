import PhoneNumber from 'awesome-phonenumber';
import { areJidsSameUser } from 'baileys';

function resolveJid(input, participants = []) {
    const found = participants.find(p =>
        areJidsSameUser(p?.id, input) ||
        areJidsSameUser(p?.lid, input) ||
        areJidsSameUser(p?.jid, input)
    );
    return found?.jid || input;
}

function no(number) {
    return number.replace(/\s/g, '').replace(/([@+-])/g, '');
}

let handler = async (m, { conn, command, text, participants, usedPrefix }) => {
    if (!text) {
        return conn.reply(m.chat, `Masukkan nomor, tag, atau balas pesan target`, m);
    }

    let who;
    let amount;

    // Split text to separate target and amount
    const args = text.trim().split(/\s+/);
    const target = args[0];
    amount = args[1];

    // Validate amount
    if (!amount || isNaN(amount)) {
        return conn.reply(m.chat, `Masukkan jumlah subscribers yang valid (angka)`, m);
    }

    let subsValue = parseInt(amount);
    if (subsValue < 1) {
        return conn.reply(m.chat, `Minimal subscribers yang diubah adalah 1`, m);
    }

    // Handle target
    text = no(target);

    if (m.quoted) {
        who = m.quoted.sender;
    } else if (m.mentionedJid?.length) {
        who = m.mentionedJid[0];
    } else if (text) {
        if (target.startsWith('@')) {
            who = target.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        } else if (target.includes('@s.whatsapp.net') || target.includes('@lid')) {
            who = target;
        } else {
            who = target.replace(/\D/g, '') + '@s.whatsapp.net';
        }
    }

    if (m.isGroup) {
        who = resolveJid(who, participants);
    }

    if (!who) {
        return conn.reply(m.chat, `Target atau nomor tidak ditemukan, mungkin sudah keluar atau bukan anggota grup ini`, m);
    }

    let users = global.db.data.users;
    if (!users[who]) {
        users[who] = { subscribers: 0 }; // Initialize user with 0 subscribers if not found
    }

    // Handle add or remove subscribers based on command
    if (command.toLowerCase() === 'addsubscribers') {
        users[who].subscribers += subsValue;
        conn.reply(m.chat, `Berhasil menambahkan ${subsValue} subscribers untuk @${who.split('@')[0]}!`, m, { mentions: [who] });
    } else if (command.toLowerCase() === 'removesubscribers') {
        if (subsValue > users[who].subscribers) {
            users[who].subscribers = 0;
            conn.reply(m.chat, `Berhasil mengurangi subscribers untuk @${who.split('@')[0]}. Subscribers kini menjadi 0!`, m, { mentions: [who] });
        } else {
            users[who].subscribers -= subsValue;
            conn.reply(m.chat, `Berhasil mengurangi ${subsValue} subscribers untuk @${who.split('@')[0]}!`, m, { mentions: [who] });
        }
    }
};

handler.help = ['addsubscribers @tag|+phone <amount>', 'removesubscribers @tag|+phone <amount>'];
handler.tags = ['owner'];
handler.command = /^(add|remove)subscribers$/i;
handler.owner = true;

export default handler;