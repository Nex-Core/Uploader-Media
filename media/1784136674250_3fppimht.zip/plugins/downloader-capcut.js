import axios from 'axios'

let handler = async (m, { conn, text }) => {
  if (!text) return conn.reply(m.chat, 'Masukkan URL CapCut!\nContoh: .capcut <url>', m)
  if (!text.includes('capcut.com')) return conn.reply(m.chat, 'URL bukan link CapCut!', m)

  const res = await anyDownloader(text)

  if (!res || !res.medias || !res.medias.length) {
    return conn.reply(m.chat, 'Gagal mengambil data video!', m)
  }

  const video =
    res.medias.find(v => v.quality.toLowerCase().includes('hd')) ||
    res.medias.find(v => v.quality.toLowerCase().includes('no watermark')) ||
    res.medias[0]

  const caption = res.title || 'CapCut Download'

  await conn.sendMessage(
    m.chat,
    {
      video: { url: video.url },
      caption
    },
    { quoted: floc }
  )
}

handler.help = ['capcut'].map(v => v + ' <url>');
handler.tags = ['downloader']
handler.command = /^(capcut|ccdl|cc|capcutdl)$/i
handler.register = true
handler.limit = true

export default handler


async function anyDownloader(url) {
  const endpoint = 'https://anydownloader.com/wp-json/api/download/'

  const headers = {
    'accept': 'application/json, text/plain, */*',
    'content-type': 'application/json;charset=UTF-8',
    'origin': 'https://anydownloader.com',
    'referer': 'https://anydownloader.com/',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36'
  }

  const body = { url }

  try {
    const res = await axios.post(endpoint, body, { headers })
    return res.data
  } catch (e) {
    return null
  }
}