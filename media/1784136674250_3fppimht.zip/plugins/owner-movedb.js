let handler = async (m, { conn, usedPrefix, command, text }) => {
    function no(number) {
        return number.replace(/\s/g, '').replace(/([@+-])/g, '');
    }

    let [oldNum, newNum] = text.split('|').map(n => no(n.trim()));
    
    if (!oldNum || !newNum) return conn.reply(m.chat, `Format salah!\nEX: *${usedPrefix}${command} nomor lama|nomor baru*`, m);
    
    if (isNaN(oldNum) || isNaN(newNum)) return conn.reply(m.chat, `Masukkan nomor yang valid!`, m);
    
    if (oldNum.length > 15 || newNum.length > 15) return conn.reply(m.chat, `Nomor tidak valid!`, m);

    let oldUser = oldNum + '@s.whatsapp.net';
    let newUser = newNum + '@s.whatsapp.net';

    if (!global.db.data.users[oldUser]) return conn.reply(m.chat, `Nomor lama belum terdaftar di database!`, m);
    
    if (global.db.data.users[newUser]) return conn.reply(m.chat, `Nomor baru sudah terdaftar di database!`, m);

    global.db.data.users[newUser] = { ...global.db.data.users[oldUser] };

    delete global.db.data.users[oldUser];

    let ppOld = await conn.profilePictureUrl(oldUser, 'image').catch(_ => "https://telegra.ph/file/24fa902ead26340f3df2c.png");
    let ppNew = await conn.profilePictureUrl(newUser, 'image').catch(_ => "https://telegra.ph/file/24fa902ead26340f3df2c.png");

    let anu = `✅ *Sukses Memindahkan Database!*\n\n📌 *Dari:* ${conn.getName(oldUser)}\n🆕 *Ke:* ${conn.getName(newUser)}\n\n📂 Semua data telah dipindahkan!`;
    m.reply(anu);
}

handler.help = ['movedb']
handler.tags = ['owner']
handler.command = /^(movedb|pindahdb)$/i

handler.owner = true

export default handler;