import axios from 'axios';
import * as cheerio from 'cheerio';

let handler = async (m, { text, conn, usedPrefix, command }) => {
    if (!text) return m.reply(`Contoh: ${usedPrefix + command} https://facebook.com/share/v/xxxx`)
    
    await conn.sendMessage(m.chat, {
        react: { text: "🚀", key: m.key }
    })

    try {
        let response = await scrapeFB(text)
        
        if (!response.success || response.links.length === 0) {
            throw new Error("Gagal mengambil data video.")
        }

        let video = response.links[0]
        let caption = `*FACEBOOK DOWNLOADER*\n\n` +
                      `📝 *Judul:* ${response.title}\n` +
                      `⏱️ *Durasi:* ${response.duration}\n` +
                      `📉 *Kualitas:* ${video.quality}\n\n` +
                      `_Request By ${m.pushName}_`

        await conn.sendFile(m.chat, video.url, 'fb.mp4', caption, floc)

        await conn.sendMessage(m.chat, {
            react: { text: "✅", key: m.key }
        })

    } catch (e) {
        console.error(e)
        m.reply("❌ Error: " + e.message)
        await conn.sendMessage(m.chat, {
            react: { text: "❌", key: m.key }
        })
    }
}

handler.help = ['facebook', 'fb'].map(v => v + ' <url>');
handler.tags = ['downloader'];
handler.command = /^((facebook|fb)(downloader|dl)?)$/i;

export default handler;

async function getTokens() {
    try {
        const { data } = await axios.get('https://fbdownloader.to/id', {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
        });
        return {
            k_exp: data.match(/k_exp\s*=\s*"(\d+)"/)?.[1],
            k_token: data.match(/k_token\s*=\s*"([a-f0-9]+)"/)?.[1]
        };
    } catch {
        return null;
    }
}

async function scrapeFB(facebookUrl) {
    const tokens = await getTokens();
    if (!tokens?.k_token) return { success: false, message: "Failed to fetch tokens" };

    const body = new URLSearchParams({
        k_exp: tokens.k_exp,
        k_token: tokens.k_token,
        p: 'home',
        q: facebookUrl,
        lang: 'id',
        v: 'v2',
        w: ''
    });

    try {
        const { data: res } = await axios.post('https://fbdownloader.to/api/ajaxSearch', body.toString(), {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With': 'XMLHttpRequest',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
        });

        if (res.status !== 'ok') return { success: false, message: res.message || "API Error" };

        const $ = cheerio.load(res.data);
        const result = {
            success: true,
            title: $('.content h3').text().trim() || 'Facebook Video',
            duration: $('.content p').first().text().trim(),
            thumbnail: $('.image-fb img').attr('src'),
            links: []
        };

        $('table tbody tr').each((_, el) => {
            const quality = $(el).find('.video-quality').text().trim();
            const url = $(el).find('a.download-link-fb').attr('href');
            if (quality && url) {
                result.links.push({ quality, url });
            }
        });

        return result;
    } catch (error) {
        return { success: false, message: error.message };
    }
}