import axios from "axios"

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return m.reply(`• EX: ${usedPrefix + command} a futuristic city with flying cars`)

  conn.sendMessage(m.chat, { react: { text: "🍁", key: m.key } })

  try {
    const app = new Veo3(false)
    const result = await app.run({
      apikey: "fgsiapi-f504cf6-6d",
      prompt: text
    })

    if (!result?.data?.video_nowm_url) throw "Gagal mendapatkan video"

    await conn.sendMessage(m.chat, {
      video: { url: result.data.video_nowm_url },
      caption: `VEO3 Result\n> Prompt: ${text}`
    }, { quoted: floc })
  } catch (e) {
    m.reply("Error: " + e.message)
  } finally {
    conn.sendMessage(m.chat, { react: { text: "✓", key: m.key } })
  }
}

handler.command = /^(veo3)$/i
handler.help = ['veo3'].map(a => a + " <prompt>");
handler.tags = ["ai"]
handler.premium = true
handler.register = true

export default handler

class Veo3 {
  constructor(debug = false) {
    this.debug = debug
    this.bypassUrl = "https://fgsi.koyeb.app/api/tools/bypasscf/v5"
    this.createUrl = "https://aiarticle.erweima.ai/api/v1/secondary-page/api/create"
    this.statusUrl = "https://aiarticle.erweima.ai/api/v1/secondary-page/api/"
    this.referer = "https://veo3api.ai/"
    this.origin = "https://veo3api.ai/"
    this.sitekey = "0x4AAAAAAA6UyTUbN2VIQ0np"
  }

  async bypassCF(url, apikey) {
    const res = await axios.get(this.bypassUrl, {
      params: { apikey, url, sitekey: this.sitekey, mode: "turnstile-min" },
      headers: { accept: "application/json" }
    })
    return res.data?.data?.token
  }

  async createVideo(token, payload) {
    const headers = {
      origin: this.origin,
      referer: this.referer,
      "user-agent":
        "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36",
      verify: token,
      uniqueid: btoa(Date.now())
    }
    const res = await axios.post(this.createUrl, payload, { headers })
    return res.data?.data?.recordId
  }

  async checkStatus(recordId) {
    const res = await axios.get(this.statusUrl + recordId, {
      headers: {
        origin: this.origin,
        referer: this.referer,
        accept: "application/json"
      }
    })
    return res.data?.data
  }

  async run({ apikey, prompt, imgUrls = [] }) {
    return new Promise(async (resolve, reject) => {
      try {
        const token = await this.bypassCF(this.origin, apikey)
        if (!token) return reject(new Error("Bypass token gagal didapat"))

        const payload = {
          prompt,
          imgUrls,
          quality: "720p",
          duration: 8,
          autoSoundFlag: true,
          soundPrompt: "",
          autoSpeechFlag: true,
          speechPrompt: "",
          speakerId: "Auto",
          aspectRatio: "16:9",
          secondaryPageId: 2019,
          channel: "VEO3",
          source: "veo3api.ai",
          type: "features",
          watermarkFlag: true,
          privateFlag: true,
          isTemp: true,
          vipFlag: true,
          model: "veo-3-fast",
        }

        const recordId = await this.createVideo(token, payload)
        if (!recordId) return reject(new Error("Gagal dapat Record ID"))

        const interval = setInterval(async () => {
          try {
            const data = await this.checkStatus(recordId)
            if (data.state === "success" && data.completeData) {
              clearInterval(interval)
              const result = JSON.parse(data.completeData)
              if (result?.data?.image_url) {
                result.data.video_nowm_url = result.data.image_url.replace(/\.(jpg|jpeg|png|webp|gif)$/i, ".mp4")
              }
              resolve(result)
            } else if (data.failCode || data.failMsg) {
              clearInterval(interval)
              reject(new Error(`Failed: ${data.failCode} ${data.failMsg}`))
            }
          } catch (err) {
            clearInterval(interval)
            reject(err)
          }
        }, 5000)
      } catch (err) {
        reject(err)
      }
    })
  }
}