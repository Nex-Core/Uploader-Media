export async function before(m) {
    this.autosholat = this.autosholat ?? {}

    let who = m.mentionedJid?.[0] || (m.fromMe ? this.user.jid : m.sender)
    let id = m.chat

    if (id in this.autosholat) return false

    let jadwalSholat = {
        Subuh: "04:30",
        Dzuhur: "11:49",
        Ashar: "15:03",
        Maghrib: "17:50",
        Isya: "19:00"
    }

    const date = new Date(new Date().toLocaleString("en-US", {
        timeZone: "Asia/Jakarta"
    }))
    const nowMinutes = date.getHours() * 60 + date.getMinutes()

    for (const [sholat, waktu] of Object.entries(jadwalSholat)) {
        const [hour, minute] = waktu.split(":").map(Number)
        const targetMinutes = hour * 60 + minute

        if (Math.abs(nowMinutes - targetMinutes) <= 1) {
            let caption = `Hai kak @${who.split`@`[0]}👋🏻, kok main HP terus~  
Sudah waktunya sholat *${sholat}*, yuk ambil wudhu dan tunaikan kewajibanmu.

* *${sholat}:* \`${waktu} WIB\`

_“Sesungguhnya sholat itu adalah kewajiban yang ditentukan waktunya atas orang-orang yang beriman.”_  
(QS. An-Nisa: 103)`

            this.autosholat[id] = [
                this.reply(m.chat, caption, null, {
                    contextInfo: {
                        mentionedJid: [who]
                    }
                }),
                setTimeout(() => {
                    delete this.autosholat[id]
                }, 60 * 1000)
            ]
            break
        }
    }
}

export const disabled = false