import { dare } from '@bochilteam/scraper'

let handler = async (m, { conn }) => conn.reply(m.chat, await dare(), m)

handler.help = ['dare']
handler.tags = ['fun']
handler.command = /^(dare)$/i

export default handler