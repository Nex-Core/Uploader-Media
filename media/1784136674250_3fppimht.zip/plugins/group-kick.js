import { areJidsSameUser } from 'baileys'

let handler = async (m, { conn, participants }) => {
    let users = m.quoted
        ? [m.quoted.sender]
        : m.mentionedJid.filter(u => !areJidsSameUser(u, conn.user.jid))

    if (!users.length) return m.reply(
        'Reply chat atau tag'
    )

    if (users.includes('6283854025278@s.whatsapp.net')) return m.reply(`Lu kick owner gw?, gw out2 skrng juga!`)

    for (let user of users) {
        let participant = participants.find(p =>
            p.jid === user || areJidsSameUser(p.jid, user) || areJidsSameUser(p.id, user)
        )

        let realJid = participant?.jid
        let isAdmin = participant?.admin

        if (!realJid || isAdmin) continue

        try {
            await conn.groupParticipantsUpdate(m.chat, [realJid], 'remove')
            await delay(1000)
        } catch (err) {
            console.error(`Gagal kick ${realJid}:`, err)
        }
    }
}

handler.help = ['kick']
handler.tags = ['group']
handler.command = /^(kick|dor)$/i

handler.admin = true
handler.group = true
handler.botAdmin = true

export default handler

const delay = ms => new Promise(resolve => setTimeout(resolve, ms))