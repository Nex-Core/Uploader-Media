let handler = async(m, { conn }) => {
  await m.reply(`Prefix bot saat ini: *${global.prefix.toString().slice(2, -2)}*`);
}
handler.tags = ['owner']
handler.help = ['cekprefix']
handler.command = /^(cekprefix|cekpref)$/i
handler.rowner = true

export default handler