const timeout = 1500000; // 25 menit cooldown untuk sesi pertarungan
const battleTimeout = 30000; // 30 detik untuk memilih serang atau mundur

export const handler = async (m, { conn }) => {
    const tag = '@' + m.sender.split`@`[0];
    let user = global.db.data.users[m.sender];
    let time = user.lastbattle + timeout;

    // Cek jika user sedang dalam sesi pertarungan
    if (user.battleSession) {
        throw `⚔️ Kamu sedang dalam sesi pertarungan! Selesaikan pertarungan yang sedang berlangsung sebelum memulai yang baru.`;
    }

    // Cek jika cooldown belum selesai
    if (Date.now() - user.lastbattle < timeout) {
        throw `Kamu sudah bertarung terlalu baru. Tunggu selama ${msToTime(time - Date.now())} lagi.`;
    }

    // Cek nilai attack
    if (user.attack < 100) {
        throw `⚠️ Attack kamu terlalu rendah (${user.attack}). Latihan terlebih dahulu dengan fitur training!`;
    }

    // Definisikan monster
    const monsters = [
        { name: "Kucing Liar", hp: 30, attack: 10, type: "Penyerang" },
        { name: "Anjing Hutan", hp: 50, attack: 15, type: "Penyerang" },
        { name: "Serigala", hp: 70, attack: 20, type: "Penyerang" },
        { name: "Beruang", hp: 100, attack: 25, type: "Penyerang" },
        { name: "Naga Kecil", hp: 150, attack: 30, type: "Penyerang" }
    ];

    // Pilih monster secara acak
    const monster = monsters[Math.floor(Math.random() * monsters.length)];
    user.battleSession = true; // Mengatur sesi pertarungan aktif
    user.monsterHp = monster.hp; // Menyimpan HP monster untuk referensi
    user.monsterAttack = monster.attack; // Menyimpan serangan monster

    let battleInfo = `🏆 *Pertarungan Melawan ${monster.name}* 🏆\n\n` +
        `🔹 *Nama Monster:* ${monster.name}\n` +
        `🔹 *HP Monster:* ${monster.hp}\n` +
        `🔹 *Tipe Monster:* ${monster.type}\n` +
        `🔹 *Serangan Monster:* ${monster.attack} Damage\n\n` +
        `Hasil Pertarungan akan segera ditampilkan...`;

    conn.reply(m.chat, battleInfo, m);

    setTimeout(() => {
        // Hitung damage berdasarkan attack pengguna
        const userDamage = Math.floor(user.attack * 0.8); // Damage user berdasarkan attack
        const monsterRemainingHp = monster.hp - userDamage;

        if (monsterRemainingHp <= 0) {
            let reward = Math.floor(Math.random() * (3000000 - 100000)) + 100000;
            let expGain = Math.floor(Math.random() * (100000 - 1000)) + 1000;
            let legendaryGain = Math.floor(Math.random() * (30 - 5)) + 5;
            let uncommonGain = Math.floor(Math.random() * (90 - 20)) + 20;
            let rockGain = Math.floor(Math.random() * (200 - 100)) + 100;
            let diamondGain = Math.floor(Math.random() * (30 - 12)) + 12;
            let woodGain = Math.floor(Math.random() * (300 - 100)) + 100;

            // Menambah item dan XP ke pengguna
            user.eris += reward;
            user.exp += expGain;
            user.legendary += legendaryGain;
            user.uncommon += uncommonGain;
            user.rock += rockGain;
            user.diamond += diamondGain;
            user.wood += woodGain;

            let resultInfo = `🎉 Kamu telah selesai bertarung melawan ${monster.name}!\n` +
                `🏅 Hasil Pertarungan: \n` +
                `💰 Uang: ${reward}\n` +
                `📊 XP: ${expGain}\n` +
                `💎 Legendary Item: ${legendaryGain}\n` +
                `📦 Uncommon Item: ${uncommonGain}\n` +
                `🪨 Rock: ${rockGain}\n` +
                `💎 Diamond: ${diamondGain}\n` +
                `🪵 Wood: ${woodGain}\n`;

            conn.reply(m.chat, resultInfo, m);
        } else {
            let resultInfo = `🔴 *Kamu kalah dalam pertarungan!*\n` +
                `Monster masih memiliki ${monsterRemainingHp} HP tersisa.\n`;

            conn.reply(m.chat, resultInfo, m);
        }

        user.battleSession = false; // Mengakhiri sesi pertarungan
        user.lastbattle = Date.now(); // Update waktu pertarungan
    }, battleTimeout);
}

const msToTime = (duration) => {
    let milliseconds = parseInt((duration % 1000) / 100),
        seconds = Math.floor((duration / 1000) % 60),
        minutes = Math.floor((duration / (1000 * 60)) % 60),
        hours = Math.floor((duration / (1000 * 60 * 60)) % 24);

    hours = (hours < 10) ? "0" + hours : hours;
    minutes = (minutes < 10) ? "0" + minutes : minutes;
    seconds = (seconds < 10) ? "0" + seconds : seconds;

    return `${hours} Jam ${minutes} Menit ${seconds} Detik`;
}

handler.help = ['battle']
handler.tags = ['rpg']
handler.command = /^(battle)$/i
export default handler;