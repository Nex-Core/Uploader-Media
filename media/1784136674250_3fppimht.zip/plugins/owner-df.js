import { join } from 'path'
import { unlinkSync, existsSync, readdirSync } from 'fs'

let handler = async (m, { conn, usedPrefix, command, args, __dirname }) => {
    if (!args[0]) {
        throw `*Masukkan nama plugin yang ingin dihapus!*\n\nContoh:\n\`${usedPrefix + command} info\``
    }

    const pluginFolder = join(__dirname, '../plugins/')
    const plugins = readdirSync(pluginFolder)
        .filter(file => file.endsWith('.js'))
        .map(file => file.replace('.js', ''))
    
    const file = join(pluginFolder, args[0] + '.js')

    if (!existsSync(file)) {
        return m.reply(
            `*Plugin tidak ditemukan!*\n\n` +
            `Daftar plugin yang tersedia:\n` +
            `\`\`\`\n${plugins.map(p => `- ${p}`).join('\n')}\n\`\`\`` +
            `\n\nGunakan:\n\`${usedPrefix + command} nama_plugin\`\nuntuk menghapus plugin tertentu.`
        )
    }

    try {
        unlinkSync(file)
        conn.reply(m.chat, `*Plugin berhasil dihapus!*\n\nNama: \`${args[0]}.js\``, m)
    } catch (error) {
        conn.reply(m.chat, `*Gagal menghapus plugin!*\n\nError: \`${error.message}\``, m)
    }
}

handler.help = ['df']
handler.tags = ['owner']
handler.command = /^(df)$/i
handler.mods = true

export default handler