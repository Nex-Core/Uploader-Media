import { createHash } from 'crypto'
import fetch from 'node-fetch'
import moment from 'moment-timezone'

let Reg = /\|?(.*)([.|] ?)([0-9]+)$/i

let handler = async function (m, { text, usedPrefix, command, conn }) {
    let namanya = conn.getName(m.sender)
    let locale = 'id'  
    let now = moment.tz('Asia/Jakarta')  
    let week = now.locale(locale).format('dddd')  
    let date = now.locale(locale).format('D MMMM YYYY')  
    let wktuwib = now.format('HH:mm:ss') + ' WIB'  

    let md = `.daftar namamu.umurmu\nContoh .daftar arul.18`  
    let user = global.db.data.users[m.sender]  
    const pp = await conn.profilePictureUrl(m.sender, "image").catch(_ => "https://telegra.ph/file/ee60957d56941b8fdd221.jpg")  

    if (user.registered === true) throw `Kamu sudah terdaftar\nMau daftar ulang? *${usedPrefix}unreg <nomor sn>*`  
    if (!Reg.test(text)) return conn.sendMessage(m.chat, { text: md }, { quoted: m })  

    let [_, name, splitter, age] = text.match(Reg)  
    if (!name) throw 'Nama tidak boleh kosong'  
    if (!age) throw 'Umur tidak boleh kosong'  
    age = parseInt(age)  
    if (age > 100) throw 'WOI TUA (。-`ω´-)'  
    if (age < 1) throw 'Halah dasar bocil'  

    user.name = name.trim()  
    user.age = age  
    user.regTime = +new Date  
    user.registered = true  

    let hash = createHash('md5').update(m.sender).digest('hex')  
    let sn = `https://ar-sensei.com/sn/${hash}`  
    const channelLink = "https://whatsapp.com/channel/0029VbARCEB6RGJPu2eHUM3M"

    await conn.sendMessage(m.chat, {  
        react: {  
            text: "✅",  
            key: m.key,  
        }  
    })  

    let response = await fetch('https://files.catbox.moe/11m82h.jpg')  
    let buffer = await response.buffer()  

    await conn.sendMessage(m.chat, {  
        text: `  
⢀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣶⣶⣆⠀  
⣠⣤⣤⣴⣿⣿⣯⣵⢟⠀  
⢸⣟⣉⣽⡿⠉⠛⠿⠿⠿⠃⠀  
⠉⠉⣡⣾⠇⠀₊ ׁ𖢷 ׄ ˚𝓢𝗎𝖼𝖼𝖾𝗌𝗌𝖿𝗎𝗅 𝗋𝖾𝗀𝗂𝗌𝗍𝗋𝖺𝗍𝗂𝗈𝗇!⠀ᡣ𐭩⠀࣪⠀  
⠀⠀⠀⠀🦢 ۫⠀⑆ 𝗒𝗈𝗎'𝗋𝖾 𝗇𝗈𝗐 𝗂𝗇 𝗍𝗁𝖾 𝗌𝗒𝗌𝗍𝖾𝗆! ⑅᜔ ִ ۪۫  
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  
╰╼ ┈─ ⠁◌⠀˚𝗋𝖾𝗀𝗂𝗌𝗍𝗋𝖺𝗍𝗂𝗈𝗇 𝖽𝖾𝗍𝖺𝗂𝗅𝗌 ⠹ 𝅄 !  

⤿ ִ⠀ׄᥴ⃘ᦱ 𝗇𝖺𝗆𝖾 ⠲ ${name}  
⤿ ִ⠀ׄᥴ⃘ᦱ 𝖺𝗀𝖾 ⠲ ${age} tahun  
⤿ ִ⠀ׄᥴ⃘ᦱ 𝗌𝗇 ⠲ ${sn}  
⤿ ִ⠀ׄᥴ⃘ᦱ 𝗍𝖺𝗇𝗀𝗀𝖺𝗅 ⠲ ${week}, ${date}  
⤿ ִ⠀ׄᥴ⃘ᦱ 𝗐𝖺𝗄𝗍𝗎 ⠲ ${wktuwib}  
⤿ ִ⠀ׄᥴ⃘ᦱ 𝖼𝗁𝖺𝗇𝗇𝖾𝗅 ⠲ ${channelLink}  

⠀⠀⠀⠀⠀⠀ׄ⠀ֵ⠀━━━━━━━━━━━━━━━ ֵ⠀ׄׄ  
⠀⠀⠀⠀˚ 𓊆˒˓ ۫﹢ 𝗅𝗈𝗏𝖾 𝖻𝗒 nishi chi ! ♡. . ⁺ ׅ  
`,  
        contextInfo: {  
            externalAdReply: {  
                title: "˚𝓢𝗎𝖼𝖼𝖾𝗌𝗌𝖿𝗎𝗅𝗅𝗒 𝗋𝖾𝗀𝗂𝗌𝗍𝖾𝗋𝖾𝖖!",  
                body: '𝓝𝗈𝗐 𝖾𝗇𝗃𝗈𝗒 𝖺𝗅𝗅 𝖻𝗈𝗍 𝖿𝖾𝖺𝗍𝗎𝗋𝖾𝗌!⠀ᡣ𐭩⠀࣪',  
                thumbnail: buffer,  
                sourceUrl: sn,  
                mediaType: 1,  
                renderLargerThumbnail: false
            }  
        }  
    })  

    const channelId = "120363417635456167@newsletter"  
    let notif = `  
⢀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣶⣶⣆⠀  
⣠⣤⣤⣴⣿⣿⣯⣵⢟⠀  
⢸⣟⣉⣽⡿⠉⠛⠿⠿⠿⠃⠀  
⠉⠉⣡⣾⠇⠀₊ ׁ𖢷 ׄ ˚𝓝𝖾𝗐 𝗋𝖾𝗀𝗂𝗌𝗍𝗋𝖺𝗍𝗂𝗈𝗇!⠀ᡣ𐭩⠀࣪⠀  
⠀⠀⠀⠀🦢 ۫⠀⑆ 𝗇𝖾𝗐 𝗎𝗌𝖾𝗋 𝖺𝗅𝖾𝗋𝗍! ⑅᜔ ִ ۪۫  
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  
╰╼ ┈─ ⠁◌⠀˚𝗎𝗌𝖾𝗋 𝖽𝖾𝗍𝖺𝗂𝗅𝗌 ⠹ 𝅄 !  

⤿ ִ⠀ׄᥴ⃘ᦱ 𝗇𝖺𝗆𝖾 ⠲ ${name}  
⤿ ִ⠀ׄᥴ⃘ᦱ 𝖺𝗀𝖾 ⠲ ${age} tahun  
⤿ ִ⠀ׄᥴ⃘ᦱ 𝗇𝗎𝗆𝖻𝖾𝗋 ⠲ wa.me/${m.sender.split('@')[0]}  
⤿ ִ⠀ׄᥴ⃘ᦱ 𝗌𝗇 ⠲ ${sn}  
⤿ ִ⠀ׄᥴ⃘ᦱ 𝗍𝗂𝗆𝖾 ⠲ ${week}, ${date} - ${wktuwib}  

⠀⠀⠀⠀⠀⠀ׄ⠀ֵ⠀━━━━━━━━━━━━━━━ ֵ⠀ׄׄ  
⠀⠀⠀⠀˚ 𓊆˒˓ ۫﹢ 𝗅𝗈𝗏𝖾 𝖻𝗒 nishi chi ! ♡. . ⁺ ׅ  
`  

    await conn.sendMessage(channelId, {  
        text: notif,  
        contextInfo: {  
            externalAdReply: {  
                title: `˚𝓝𝖾𝗐 𝗎𝗌𝖾𝗋: ${name}`,  
                body: `𝓢𝖭: ${sn}⠀ᡣ𐭩⠀࣪`,  
                thumbnailUrl: pp,  
                mediaType: 1,  
                renderLargerThumbnail: false,  
                sourceUrl: sn  
            }  
        }  
    }).catch(err => {  
        console.error("Gagal kirim ke channel:", err)  
    })  
}

handler.command = /^(daftar|register)$/i
export default handler