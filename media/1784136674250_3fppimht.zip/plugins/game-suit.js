const suits = ['batu', 'gunting', 'kertas'];
let cooldowns = {}; // Objek untuk menyimpan cooldown

let handler = async (m, { conn, args, usedPrefix }) => {
    let user = global.db.data.users[m.sender];
    let betAmount = 0;

    if (args[0] && args[0].toLowerCase() === 'all') {
        betAmount = user.eris;
    } else {
        betAmount = parseInt(args[0]) || 0;
    }

    if (betAmount <= 0 || isNaN(betAmount)) {
        return m.reply(`Masukkan jumlah taruhan.`);
    }

    if (user.eris < betAmount) {
        return m.reply(`Money tidak mencukupi untuk melakukan taruhan sebesar ${betAmount.toLocaleString()}.`);
    }

    let currentTime = Date.now();

    if (!cooldowns[m.sender]) {
        cooldowns[m.sender] = 0;
    }

    if (currentTime < cooldowns[m.sender]) {
        let remainingTime = Math.ceil((cooldowns[m.sender] - currentTime) / 1000);
        return conn.reply(m.chat, `⏳ Harap tunggu ${remainingTime} detik lagi sebelum bermain lagi.`, m);
    }

    const ownerID = '6283854025278@s.whatsapp.net';

    let userChoice = suits[Math.floor(Math.random() * suits.length)];

    let botChoice;
    if (m.sender === ownerID) {
        if (userChoice === 'kertas') botChoice = 'batu';
        if (userChoice === 'batu') botChoice = 'gunting';
        if (userChoice === 'gunting') botChoice = 'kertas';
    } else {
        botChoice = suits[Math.floor(Math.random() * suits.length)];
    }

    let result;
    if (userChoice === botChoice) {
        result = 'Seri';
    } else if (
        (userChoice === 'batu' && botChoice === 'gunting') ||
        (userChoice === 'gunting' && botChoice === 'kertas') ||
        (userChoice === 'kertas' && botChoice === 'batu')
    ) {
        result = 'Menang';
    } else {
        result = 'Kalah';
    }

    if (result === 'Menang') {
        user.eris += betAmount;
    } else if (result === 'Seri') {
    } else {
        user.eris -= betAmount;
    }

    let emojiUser = getEmojiForChoice(userChoice);
    let emojiBot = getEmojiForChoice(botChoice);

    conn.reply(m.chat, `👤 Kamu memilih: ${emojiUser} ${userChoice}\n🤖 Bot memilih: ${emojiBot} ${botChoice}\n📢 Hasil: ${getEmojiForResult(result)} ${result === 'Seri' ? 'Seri!' : `Kamu ${result}!`}\n${result === 'Menang' ? `🎉 Kamu memenangkan taruhan sebesar ${betAmount.toLocaleString()} Money.` : result === 'Kalah' ? `💸 Kamu kalah dalam taruhan sebesar ${betAmount.toLocaleString()} Money.` : 'Tidak ada taruhan karena seri.'}\n> Saldo Money saat ini: ${user.eris.toLocaleString()}`, m);

    cooldowns[m.sender] = currentTime + 10000;
};

function getEmojiForChoice(choice) {
    switch (choice) {
        case 'batu':
            return '✊';
        case 'gunting':
            return '✌️';
        case 'kertas':
            return '🖐️';
        default:
            return '';
    }
}

function getEmojiForResult(result) {
    switch (result) {
        case 'Menang':
            return '😁';
        case 'Kalah':
            return '😢';
        case 'Seri':
            return '😐';
        default:
            return '';
    }
}

handler.help = ['suit <jumlah taruhan | all>'];
handler.tags = ['game'];
handler.command = /^(suit)$/i;
handler.register = true;

export default handler;