const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = (await import('baileys')).default;

let handler = async (m, { conn, command, args }) => {
  let user = global.db.data.users[m.sender];
  let totalEksplorasi = user.sand || 0;
  let ekplorasiFormatted = totalEksplorasi.toLocaleString('en-US');
  const tag = '@' + m.sender.split`@`[0];

  const destinations = [
    'Desa Elf',
    'Desa Goblin',
    'Lost Temple',
    'Labirin Dark',
    'Kastil Naga',
    'Gua Troll',
    'Hutan Terlarang',
    'Pantai Berhantu',
    'Gunung Berapi',
    'Lembah Raksasa',
    'Pulau Harta',
    'Kuil Kuno',
    'Reruntuhan Ajaib',
    'Hutan Mistis',
    'Kota Hilang',
    'Danau Beku',
    'Dataran Guntur',
    'Gurun Pasir',
    'Benteng Batu',
    'Lembah Magis'
  ];

  let title = '';
  if (totalEksplorasi >= 1000) {
    title = 'Sang Legenda';
  } else if (totalEksplorasi >= 100) {
    title = 'Pecinta Alam';
  } else if (totalEksplorasi >= 25) {
    title = 'Penyelamat Alam';
  } else {
    title = 'Pemula';
  }

  function getRandomDestinations() {
    const shuffled = destinations.sort(() => 0.5 - Math.random());
    return shuffled.slice(0, 3);
  }

  try {
    if (command === 'berkelana') {
      // Setup cooldown (10 menit)
      let timing = (new Date - (user.lastbunga * 1)) * 1;
      if (timing < 600000) {
        return conn.reply(m.chat, `👋 Hai Kak ${tag}\nKamu sudah lelah dan butuh istirahat, beristirahat lah terlebih dahulu\nTunggu Selama ${clockString(600000 - timing)}`, m);
      }

      // Select three random destinations and store them in user data
      const randomDestinations = getRandomDestinations();
      user.tempDestinations = randomDestinations;

      // Create interactive message with buttons
      let caption = `◤───「 *STATISTIK* 」──✦
│🧑🏻‍💻 [ *Player :* ${tag}
│🌟 [ *Total berkelana :* ${ekplorasiFormatted} kali
│🏆 [ *Title Saat ini :* ${title}
◣──────────❈

✦▣──┄╌╼〘 *BERKELANA* 〙╾╌┄──▣

◤───「 *DESTINASI* 」──✦
├⎆ 1. ${randomDestinations[0]}
├⎆ 2. ${randomDestinations[1]}
├⎆ 3. ${randomDestinations[2]}
◣─────────────✦`;

      let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.create({
              body: proto.Message.InteractiveMessage.Body.create({
                text: caption
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
                text: "*© Nishi Chi*"
              }),
              header: proto.Message.InteractiveMessage.Header.create({
                title: "\t🌍 *BERKELANA* 🌍\n",
                subtitle: "",
                hasMediaAttachment: false
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: `{"display_text":"🌍 ${randomDestinations[0]}","id":"pilih_1"}`
                  },
                  {
                    name: "quick_reply",
                    buttonParamsJson: `{"display_text":"🌍 ${randomDestinations[1]}","id":"pilih_2"}`
                  },
                  {
                    name: "quick_reply",
                    buttonParamsJson: `{"display_text":"🌍 ${randomDestinations[2]}","id":"pilih_3"}`
                  }
                ]
              })
            })
          }
        }
      }, {});
      await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

      // Timeout for destination selection
      setTimeout(() => {
        if (user.tempDestinations) {
          delete user.tempDestinations;
          conn.reply(m.chat, `${tag}, waktu untuk memilih destinasi berkelana telah habis. Silakan coba lagi.`, m);
        }
      }, 60000); // 1 minute
    }
  } catch (err) {
    m.reply("📢: " + err);
  }
};

// Handle button responses
handler.before = async function (m) {
  let user = global.db.data.users[m.sender];
  const tag = '@' + m.sender.split`@`[0];
  let totalEksplorasi = user.sand || 0;
  let ekplorasiFormatted = totalEksplorasi.toLocaleString('en-US');

  let title = '';
  if (totalEksplorasi >= 1000) {
    title = 'Sang Legenda';
  } else if (totalEksplorasi >= 100) {
    title = 'Pecinta Alam';
  } else if (totalEksplorasi >= 25) {
    title = 'Penyelamat Alam';
  } else {
    title = 'Pemula';
  }

  const contentType = getContentType(m.message);
  if (contentType === 'templateButtonReplyMessage') {
    let selectedButton = m.message.templateButtonReplyMessage.selectedId;

    if (selectedButton && selectedButton.startsWith('pilih_')) {
      if (!user.tempDestinations) {
        return conn.reply(m.chat, `${tag}, silakan ketik .berkelana terlebih dahulu untuk mendapatkan pilihan destinasi.`, m);
      }

      const pilihanIndex = parseInt(selectedButton.split('_')[1]) - 1;
      const randomDestinations = user.tempDestinations;

      if (pilihanIndex < 0 || pilihanIndex >= randomDestinations.length) {
        return conn.reply(m.chat, `${tag}, pilihan tidak valid. Silakan pilih destinasi yang tersedia.`, m);
      }

      const pilihan = randomDestinations[pilihanIndex];
      let hasil;
      switch (pilihan.toLowerCase()) {
        case 'desa elf':
          hasil = await berkelanaDesaElf(user);
          break;
        case 'desa goblin':
          hasil = await berkelanaDesaGoblin(user);
          break;
        case 'lost temple':
          hasil = await berkelanaLostTemple(user);
          break;
        case 'labirin dark':
          hasil = await berkelanaLabirinDark(user);
          break;
        case 'kastil naga':
          hasil = await berkelanaKastilNaga(user);
          break;
        case 'gua troll':
          hasil = await berkelanaGuaTroll(user);
          break;
        case 'hutan terlarang':
          hasil = await berkelanaHutanTerlarang(user);
          break;
        case 'pantai berhantu':
          hasil = await berkelanaPantaiBerhantu(user);
          break;
        case 'gunung berapi':
          hasil = await berkelanaGunungBerapi(user);
          break;
        case 'lembah raksasa':
          hasil = await berkelanaLembahRaksasa(user);
          break;
        case 'pulau harta':
          hasil = await berkelanaPulauHarta(user);
          break;
        case 'kuil kuno':
          hasil = await berkelanaKuilKuno(user);
          break;
        case 'reruntuhan ajaib':
          hasil = await berkelanaReruntuhanAjaib(user);
          break;
        case 'hutan mistis':
          hasil = await berkelanaHutanMistis(user);
          break;
        case 'kota hilang':
          hasil = await berkelanaKotaHilang(user);
          break;
        case 'danau beku':
          hasil = await berkelanaDanauBeku(user);
          break;
        case 'dataran guntur':
          hasil = await berkelanaDataranGuntur(user);
          break;
        case 'gurun pasir':
          hasil = await berkelanaGurunPasir(user);
          break;
        case 'benteng batu':
          hasil = await berkelanaBentengBatu(user);
          break;
        case 'lembah magis':
          hasil = await berkelanaLembahMagis(user);
          break;
        default:
          return conn.reply(m.chat, `${tag}, pilihan tidak valid. Silakan pilih destinasi yang tersedia.`, m);
      }

      if (hasil) {
        setTimeout(() => {
          conn.reply(m.chat, `Hai ${tag} Ayo Berkelana kembali untuk menjelajahi dunia`, m);
        }, 600000); // 10 minutes
      }

      // Clear temp destinations and update last explore time
      delete user.tempDestinations;
      user.lastbunga = new Date() * 1;

      // Send the expedition result
      return conn.reply(m.chat, `◤───「 *STATISTIK* 」──✦
│🧑🏻‍💻 [ *Player :* ${tag}
│🌟 [ *Total Berkelana :* ${ekplorasiFormatted} kali
│🏆 [ *Title Saat ini :* ${title}
◣──────────❈

✦▣──┄╌╼〘 *BERKELANA* 〙╾╌┄──▣

◤───「 *🗺️ HASIL BERKELANA* 」──✦
├⎆ 🌍 *Destinasi:* ${pilihan}
${hasil}
◣─────────────✦
> Cek status akun Anda
> Ketik: .akunxp`, m);
    }
  }
};

// Functions for each expedition destination
function berkelanaDesaElf(user) {
  const randomEris = Math.floor(Math.random() * (5000000 - 100 + 1)) + 100;
  const randomExp = Math.floor(Math.random() * (2000 - 50 + 1)) + 50;
  const randomDiamond = Math.floor(Math.random() * (100 - 1 + 1)) + 5;
  const randomUncommon = Math.floor(Math.random() * (80 - 1 + 1)) + 5;
  user.eris += randomEris;
  user.exp += randomExp;
  user.diamond += randomDiamond;
  user.uncommon += randomUncommon;
  user.sand += 1;
  user.lastbunga = new Date() * 1;
  return `├⎆ 🎉 Selamat! Anda berhasil mendapatkan\n├⎆ 💰 *Money:* +${randomEris}\n├⎆ ⭐ *EXP:* +${randomExp}\n├⎆ 💎 *Diamond:* +${randomDiamond}\n├⎆ 📦 *Uncommon:* +${randomUncommon}`;
}

function berkelanaDesaGoblin(user) {
  const randomEris = Math.floor(Math.random() * (3000000 - 50 + 1)) + 50;
  const randomExp = Math.floor(Math.random() * (1500 - 30 + 1)) + 30;
  const randomDiamond = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  const randomUncommon = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  user.eris += randomEris;
  user.exp += randomExp;
  user.diamond += randomDiamond;
  user.uncommon += randomUncommon;
  user.sand += 1;
  user.lastbunga = new Date() * 1;
  return `├⎆ 🎉 Anda menemukan harta karun!\n├⎆ 💰 *Money:* +${randomEris}\n├⎆ ⭐ *EXP:* +${randomExp}\n├⎆ 💎 *Diamond:* +${randomDiamond}\n├⎆ 📦 *Uncommon:* +${randomUncommon}`;
}

function berkelanaLostTemple(user) {
  const randomEris = Math.floor(Math.random() * (7000000 - 150 + 1)) + 150;
  const randomExp = Math.floor(Math.random() * (3000 - 70 + 1)) + 70;
  const randomDiamond = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  const randomUncommon = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  user.eris += randomEris;
  user.exp += randomExp;
  user.diamond += randomDiamond;
  user.uncommon += randomUncommon;
  user.sand += 1;
  user.lastbunga = new Date() * 1;
  return `├⎆ 🎉 Anda menjelajahi Lost Temple!\n├⎆ 💰 *Money:* +${randomEris}\n├⎆ ⭐ *EXP:* +${randomExp}\n├⎆ 💎 *Diamond:* +${randomDiamond}\n├⎆ 📦 *Uncommon:* +${randomUncommon}`;
}

function berkelanaLabirinDark(user) {
  const randomEris = Math.floor(Math.random() * (6000000 - 120 + 1)) + 120;
  const randomExp = Math.floor(Math.random() * (2500 - 60 + 1)) + 60;
  const randomDiamond = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  const randomUncommon = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  user.eris += randomEris;
  user.exp += randomExp;
  user.diamond += randomDiamond;
  user.uncommon += randomUncommon;
  user.sand += 1;
  user.lastbunga = new Date() * 1;
  return `├⎆ 🎉 Anda berhasil keluar dari Labirin Dark!\n├⎆ 💰 *Money:* +${randomEris}\n├⎆ ⭐ *EXP:* +${randomExp}\n├⎆ 💎 *Diamond:* +${randomDiamond}\n├⎆ 📦 *Uncommon:* +${randomUncommon}`;
}

function berkelanaKastilNaga(user) {
  const randomEris = Math.floor(Math.random() * (8000000 - 200 + 1)) + 200;
  const randomExp = Math.floor(Math.random() * (4000 - 100 + 1)) + 100;
  const randomDiamond = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  const randomUncommon = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  user.eris += randomEris;
  user.exp += randomExp;
  user.diamond += randomDiamond;
  user.uncommon += randomUncommon;
  user.sand += 1;
  user.lastbunga = new Date() * 1;
  return `├⎆ 🎉 Anda menaklukkan Kastil Naga!\n├⎆ 💰 *Money:* +${randomEris}\n├⎆ ⭐ *EXP:* +${randomExp}\n├⎆ 💎 *Diamond:* +${randomDiamond}\n├⎆ 📦 *Uncommon:* +${randomUncommon}`;
}

function berkelanaGuaTroll(user) {
  const randomEris = Math.floor(Math.random() * (4000000 - 80 + 1)) + 80;
  const randomExp = Math.floor(Math.random() * (2000 - 50 + 1)) + 50;
  const randomDiamond = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  const randomUncommon = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  user.eris += randomEris;
  user.exp += randomExp;
  user.diamond += randomDiamond;
  user.uncommon += randomUncommon;
  user.sand += 1;
  user.lastbunga = new Date() * 1;
  return `├⎆ 🎉 Anda mengeksplorasi Gua Troll!\n├⎆ 💰 *Money:* +${randomEris}\n├⎆ ⭐ *EXP:* +${randomExp}\n├⎆ 💎 *Diamond:* +${randomDiamond}\n├⎆ 📦 *Uncommon:* +${randomUncommon}`;
}

function berkelanaHutanTerlarang(user) {
  const randomEris = Math.floor(Math.random() * (5000000 - 100 + 1)) + 100;
  const randomExp = Math.floor(Math.random() * (2000 - 50 + 1)) + 50;
  const randomDiamond = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  const randomUncommon = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  user.eris += randomEris;
  user.exp += randomExp;
  user.diamond += randomDiamond;
  user.uncommon += randomUncommon;
  user.sand += 1;
  user.lastbunga = new Date() * 1;
  return `├⎆ 🎉 Anda menjelajahi Hutan Terlarang!\n├⎆ 💰 *Money:* +${randomEris}\n├⎆ ⭐ *EXP:* +${randomExp}\n├⎆ 💎 *Diamond:* +${randomDiamond}\n├⎆ 📦 *Uncommon:* +${randomUncommon}`;
}

function berkelanaPantaiBerhantu(user) {
  const randomEris = Math.floor(Math.random() * (4500000 - 90 + 1)) + 90;
  const randomExp = Math.floor(Math.random() * (1800 - 45 + 1)) + 45;
  const randomDiamond = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  const randomUncommon = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  user.eris += randomEris;
  user.exp += randomExp;
  user.diamond += randomDiamond;
  user.uncommon += randomUncommon;
  user.sand += 1;
  user.lastbunga = new Date() * 1;
  return `├⎆ 🎉 Anda berani menjelajahi Pantai Berhantu!\n├⎆ 💰 *Money:* +${randomEris}\n├⎆ ⭐ *EXP:* +${randomExp}\n├⎆ 💎 *Diamond:* +${randomDiamond}\n├⎆ 📦 *Uncommon:* +${randomUncommon}`;
}

function berkelanaGunungBerapi(user) {
  const randomEris = Math.floor(Math.random() * (7000000 - 150 + 1)) + 150;
  const randomExp = Math.floor(Math.random() * (3000 - 70 + 1)) + 70;
  const randomDiamond = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  const randomUncommon = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  user.eris += randomEris;
  user.exp += randomExp;
  user.diamond += randomDiamond;
  user.uncommon += randomUncommon;
  user.sand += 1;
  user.lastbunga = new Date() * 1;
  return `├⎆ 🎉 Anda selamat dari Gunung Berapi!\n├⎆ 💰 *Money:* +${randomEris}\n├⎆ ⭐ *EXP:* +${randomExp}\n├⎆ 💎 *Diamond:* +${randomDiamond}\n├⎆ 📦 *Uncommon:* +${randomUncommon}`;
}

function berkelanaLembahRaksasa(user) {
  const randomEris = Math.floor(Math.random() * (5000000 - 100 + 1)) + 100;
  const randomExp = Math.floor(Math.random() * (2000 - 50 + 1)) + 50;
  const randomDiamond = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  const randomUncommon = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  user.eris += randomEris;
  user.exp += randomExp;
  user.diamond += randomDiamond;
  user.uncommon += randomUncommon;
  user.sand += 1;
  user.lastbunga = new Date() * 1;
  return `├⎆ 🎉 Anda menjelajahi Lembah Raksasa!\n├⎆ 💰 *Money:* +${randomEris}\n├⎆ ⭐ *EXP:* +${randomExp}\n├⎆ 💎 *Diamond:* +${randomDiamond}\n├⎆ 📦 *Uncommon:* +${randomUncommon}`;
}

function berkelanaPulauHarta(user) {
  const randomEris = Math.floor(Math.random() * (8000000 - 200 + 1)) + 200;
  const randomExp = Math.floor(Math.random() * (4000 - 100 + 1)) + 100;
  const randomDiamond = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  const randomUncommon = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  user.eris += randomEris;
  user.exp += randomExp;
  user.diamond += randomDiamond;
  user.uncommon += randomUncommon;
  user.sand += 1;
  user.lastbunga = new Date() * 1;
  return `├⎆ 🎉 Anda menemukan harta karun di Pulau Harta!\n├⎆ 💰 *Money:* +${randomEris}\n├⎆ ⭐ *EXP:* +${randomExp}\n├⎆ 💎 *Diamond:* +${randomDiamond}\n├⎆ 📦 *Uncommon:* +${randomUncommon}`;
}

function berkelanaKuilKuno(user) {
  const randomEris = Math.floor(Math.random() * (6000000 - 120 + 1)) + 120;
  const randomExp = Math.floor(Math.random() * (2500 - 60 + 1)) + 60;
  const randomDiamond = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  const randomUncommon = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  user.eris += randomEris;
  user.exp += randomExp;
  user.diamond += randomDiamond;
  user.uncommon += randomUncommon;
  user.sand += 1;
  user.lastbunga = new Date() * 1;
  return `├⎆ 🎉 Anda menjelajahi Kuil Kuno!\n├⎆ 💰 *Money:* +${randomEris}\n├⎆ ⭐ *EXP:* +${randomExp}\n├⎆ 💎 *Diamond:* +${randomDiamond}\n├⎆ 📦 *Uncommon:* +${randomUncommon}`;
}

function berkelanaReruntuhanAjaib(user) {
  const randomEris = Math.floor(Math.random() * (7000000 - 150 + 1)) + 150;
  const randomExp = Math.floor(Math.random() * (3000 - 70 + 1)) + 70;
  const randomDiamond = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  const randomUncommon = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  user.eris += randomEris;
  user.exp += randomExp;
  user.diamond += randomDiamond;
  user.uncommon += randomUncommon;
  user.sand += 1;
  user.lastbunga = new Date() * 1;
  return `├⎆ 🎉 Anda menemukan misteri di Reruntuhan Ajaib!\n├⎆ 💰 *Money:* +${randomEris}\n├⎆ ⭐ *EXP:* +${randomExp}\n├⎆ 💎 *Diamond:* +${randomDiamond}\n├⎆ 📦 *Uncommon:* +${randomUncommon}`;
}

function berkelanaHutanMistis(user) {
  const randomEris = Math.floor(Math.random() * (4500000 - 90 + 1)) + 90;
  const randomExp = Math.floor(Math.random() * (1800 - 45 + 1)) + 45;
  const randomDiamond = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  const randomUncommon = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  user.eris += randomEris;
  user.exp += randomExp;
  user.diamond += randomDiamond;
  user.uncommon += randomUncommon;
  user.sand += 1;
  user.lastbunga = new Date() * 1;
  return `├⎆ 🎉 Anda menjelajahi Hutan Mistis!\n├⎆ 💰 *Money:* +${randomEris}\n├⎆ ⭐ *EXP:* +${randomExp}\n├⎆ 💎 *Diamond:* +${randomDiamond}\n├⎆ 📦 *Uncommon:* +${randomUncommon}`;
}

function berkelanaKotaHilang(user) {
  const randomEris = Math.floor(Math.random() * (6000000 - 120 + 1)) + 120;
  const randomExp = Math.floor(Math.random() * (2500 - 60 + 1)) + 60;
  const randomDiamond = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  const randomUncommon = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  user.eris += randomEris;
  user.exp += randomExp;
  user.diamond += randomDiamond;
  user.uncommon += randomUncommon;
  user.sand += 1;
  user.lastbunga = new Date() * 1;
  return `├⎆ 🎉 Anda menemukan Kota Hilang!\n├⎆ 💰 *Money:* +${randomEris}\n├⎆ ⭐ *EXP:* +${randomExp}\n├⎆ 💎 *Diamond:* +${randomDiamond}\n├⎆ 📦 *Uncommon:* +${randomUncommon}`;
}

function berkelanaDanauBeku(user) {
  const randomEris = Math.floor(Math.random() * (5000000 - 100 + 1)) + 100;
  const randomExp = Math.floor(Math.random() * (2000 - 50 + 1)) + 50;
  const randomDiamond = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  const randomUncommon = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  user.eris += randomEris;
  user.exp += randomExp;
  user.diamond += randomDiamond;
  user.uncommon += randomUncommon;
  user.sand += 1;
  user.lastbunga = new Date() * 1;
  return `├⎆ 🎉 Anda menjelajahi Danau Beku!\n├⎆ 💰 *Money:* +${randomEris}\n├⎆ ⭐ *EXP:* +${randomExp}\n├⎆ 💎 *Diamond:* +${randomDiamond}\n├⎆ 📦 *Uncommon:* +${randomUncommon}`;
}

function berkelanaDataranGuntur(user) {
  const randomEris = Math.floor(Math.random() * (6500000 - 130 + 1)) + 130;
  const randomExp = Math.floor(Math.random() * (2700 - 60 + 1)) + 60;
  const randomDiamond = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  const randomUncommon = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  user.eris += randomEris;
  user.exp += randomExp;
  user.diamond += randomDiamond;
  user.uncommon += randomUncommon;
  user.sand += 1;
  user.lastbunga = new Date() * 1;
  return `├⎆ 🎉 Anda menjelajahi Dataran Guntur!\n├⎆ 💰 *Money:* +${randomEris}\n├⎆ ⭐ *EXP:* +${randomExp}\n├⎆ 💎 *Diamond:* +${randomDiamond}\n├⎆ 📦 *Uncommon:* +${randomUncommon}`;
}

function berkelanaGurunPasir(user) {
  const randomEris = Math.floor(Math.random() * (6000000 - 120 + 1)) + 120;
  const randomExp = Math.floor(Math.random() * (2500 - 60 + 1)) + 60;
  const randomDiamond = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  const randomUncommon = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  user.eris += randomEris;
  user.exp += randomExp;
  user.diamond += randomDiamond;
  user.uncommon += randomUncommon;
  user.sand += 1;
  user.lastbunga = new Date() * 1;
  return `├⎆ 🎉 Anda menjelajahi Gurun Pasir!\n├⎆ 💰 *Money:* +${randomEris}\n├⎆ ⭐ *EXP:* +${randomExp}\n├⎆ 💎 *Diamond:* +${randomDiamond}\n├⎆ 📦 *Uncommon:* +${randomUncommon}`;
}

function berkelanaBentengBatu(user) {
  const randomEris = Math.floor(Math.random() * (7000000 - 150 + 1)) + 150;
  const randomExp = Math.floor(Math.random() * (3000 - 70 + 1)) + 70;
  const randomDiamond = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  const randomUncommon = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  user.eris += randomEris;
  user.exp += randomExp;
  user.diamond += randomDiamond;
  user.uncommon += randomUncommon;
  user.sand += 1;
  user.lastbunga = new Date() * 1;
  return `├⎆ 🎉 Anda menaklukkan Benteng Batu!\n├⎆ 💰 *Money:* +${randomEris}\n├⎆ ⭐ *EXP:* +${randomExp}\n├⎆ 💎 *Diamond:* +${randomDiamond}\n├⎆ 📦 *Uncommon:* +${randomUncommon}`;
}

function berkelanaLembahMagis(user) {
  const randomEris = Math.floor(Math.random() * (8000000 - 200 + 1)) + 200;
  const randomExp = Math.floor(Math.random() * (4000 - 100 + 1)) + 100;
  const randomDiamond = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  const randomUncommon = Math.floor(Math.random() * (25 - 1 + 1)) + 5;
  user.eris += randomEris;
  user.exp += randomExp;
  user.diamond += randomDiamond;
  user.uncommon += randomUncommon;
  user.sand += 1;
  user.lastbunga = new Date() * 1;
  return `├⎆ 🎉 Anda menjelajahi Lembah Magis!\n├⎆ 💰 *Money:* +${randomEris}\n├⎆ ⭐ *EXP:* +${randomExp}\n├⎆ 💎 *Diamond:* +${randomDiamond}\n├⎆ 📦 *Uncommon:* +${randomUncommon}`;
}

function getContentType(message) {
  if (message.buttonsResponseMessage) return 'buttonsResponseMessage';
  if (message.templateButtonReplyMessage) return 'templateButtonReplyMessage';
  if (message.viewOnceMessage) return 'viewOnceMessage';
  return null;
}

function clockString(ms) {
  let d = Math.floor(ms / 86400000);
  let h = Math.floor(ms / 3600000) % 24;
  let m = Math.floor(ms / 60000) % 60;
  let s = Math.floor(ms / 1000) % 60;
  return ['\n' + d, ' *Hari* ', h, ' *Jam* ', m, ' *Menit* ', s, ' *Detik* '].map(v => v.toString().padStart(2, 0)).join('');
}

handler.help = ['berkelana'];
handler.tags = ['rpg'];
handler.command = /^(berkelana)$/i;
handler.register = true;
handler.group = true;
handler.limit = 2;

export default handler;