let handler = async (m, { conn, args, participants }) => {
    let users = Object.entries(global.db.data.users).map(([key, value]) => {
        return {...value, jid: key}
    });
    
    // Mengurutkan berdasarkan subscribers, viewers, dan likes
    let sortedSubscribers = users.map(toNumber('subscribers')).sort(sort('subscribers', true)); // Urutan menurun (dari besar ke kecil)
    let sortedViewers = users.map(toNumber('viewers')).sort(sort('viewers', true)); // Urutan menurun
    let sortedLikes = users.map(toNumber('like')).sort(sort('like', true)); // Urutan menurun
    
    // Mendapatkan urutan ID pengguna
    let usersSubscribers = sortedSubscribers.map(enumGetKey);
    let usersViewers = sortedViewers.map(enumGetKey);
    let usersLikes = sortedLikes.map(enumGetKey);
    
    let len = args[0] && args[0].length > 0 ? Math.min(15, Math.max(parseInt(args[0]), 15)) : Math.min(15, sortedSubscribers.length);
    
    // Teks untuk ditampilkan
    let text = `🌟 S O S I A L B L A D E 🌟\n\n🔹 Top 📈 Subscribers\n   • *Top ${len} Subscribers SosialBlade* •\n  ➡️ Kamu: *${usersSubscribers.indexOf(m.sender) + 1}* dari *${usersSubscribers.length}*\n\n`;
    text += sortedSubscribers.slice(0, len).map(({ jid, subscribers }, i) => `${i + 1}. ${participants.some(p => jid === p.jid) ? `(${conn.getName(jid)}) wa.me/` : '@'}${jid.split`@`[0]} *${formatNumber(subscribers)} Subscribers*`).join`\n`;
    text += `\n┗━━━━━━━━━━━━━━📈━━━━━━━━━━━━━━┛\n`;

    text += `🔹 Top 🎥 Viewers\n  • *Top ${len} Viewers SosialBlade* •\n  ➡️ Kamu: *${usersViewers.indexOf(m.sender) + 1}* dari *${usersViewers.length}*\n\n`;
    text += sortedViewers.slice(0, len).map(({ jid, viewers }, i) => `${i + 1}. ${participants.some(p => jid === p.jid) ? `(${conn.getName(jid)}) wa.me/` : '@'}${jid.split`@`[0]} *${formatNumber(viewers)} Viewers*`).join`\n`;
    text += `\n┗━━━━━━━━━━━━━━🎥━━━━━━━━━━━━━━┛\n`;

    text += `🔹 Top 👍 Likes\n  • *Top ${len} Likes SosialBlade* •\n  ➡️ Kamu: *${usersLikes.indexOf(m.sender) + 1}* dari *${usersLikes.length}*\n\n`;
    text += sortedLikes.slice(0, len).map(({ jid, like }, i) => `${i + 1}. ${participants.some(p => jid === p.jid) ? `(${conn.getName(jid)}) wa.me/` : '@'}${jid.split`@`[0]} *${formatNumber(like)} Likes*`).join`\n`;
    text += `\n┗━━━━━━━━━━━━━━👍━━━━━━━━━━━━━━┛\n`;
  
    text = text.trim();
    
    // Mengirim balasan dengan mention
    conn.reply(m.chat, text, m, {
        contextInfo: {
            mentionedJid: [...usersSubscribers.slice(0, len), ...usersViewers.slice(0, len), ...usersLikes.slice(0, len)]
                .filter(v => !participants.some(p => v === p.jid))
        }
    });
}

handler.help = ['sosialblade'];
handler.tags = ['main', 'rpg'];
handler.command = /^(sosialblade|sb)$/i;

handler.register = true;
handler.group = true;

export default handler;

// Fungsi pembantu untuk mengurutkan berdasarkan properti
function sort(property, ascending = true) {
    if (property) return (...args) => args[ascending & 1][property] - args[!ascending & 1][property];
    else return (...args) => args[ascending & 1] - args[!ascending & 1];
}

// Fungsi pembantu untuk mengonversi properti ke angka
function toNumber(property, _default = 0) {
    if (property) return (a, i, b) => {
        return {...b[i], [property]: a[property] === undefined ? _default : a[property]};
    }
    else return a => a === undefined ? _default : a;
}

// Fungsi pembantu untuk mendapatkan key (jid)
function enumGetKey(a) {
    return a.jid;
}

// Fungsi untuk memformat angka menjadi ribu, juta, miliar, dll.
function formatNumber(num) {
    if (num >= 1e12) return (num / 1e12).toFixed(2).replace(/\.00$/, '') + "triliun"; // Triliun
    if (num >= 1e9) return (num / 1e9).toFixed(2).replace(/\.00$/, '') + "milliar"; // Miliar
    if (num >= 1e6) return (num / 1e6).toFixed(2).replace(/\.00$/, '') + "juta"; // Juta
    if (num >= 1e3) return (num / 1e3).toFixed(2).replace(/\.00$/, '') + "ribu"; // Ribu
    return num.toString(); // Angka kecil tetap apa adanya
}