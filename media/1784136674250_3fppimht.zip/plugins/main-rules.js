import fs from 'fs'

let handler = async (m, { conn }) => {
	let rules = `_*Kebijakan Privasi, Syarat Ketentuan dan Peraturan Bot*_

*Kebijakan Privasi*
_1. Bot tidak akan menyebarkan nomor users._
_2. Bot tidak akan menyimpan media yang dikirimkan oleh users._
_3. Owner berhak melihat data riwayat chat users._
_4. Owner dapat melihat riwayat chat, dan media yang dikirimkan users._

*Peraturan Bot*
• No Bug / Virus / Virtex.
• No Sara / Rasis.
• No Spam Chat / Sticker.
• No Promote / Link Group.
• No Spam BOT / Call BOT.
• No Audio Chat.
• No Porn / Gore.

_Perlu kalian tahu bahwa kami menjaga privasi dari data-data anda!_

*────────────────────────*
`;
	conn.sendMessage(m.chat, {
text: rules, 
contextInfo: {
externalAdReply: {
title: "Rules Chisato",
body: 'Mohon DiPatuhi Biar Menghindar Dari Banned',
thumbnailUrl: 'https://telegra.ph/file/3aa1d699bde0c8702018b.jpg',
sourceUrl: "",
mediaType: 1,
renderLargerThumbnail: true
}
},rules: rules},{quoted: m })
}
handler.help = ['rules']
handler.tags = ['main']
handler.command = /^(rules|rule)$/i;

export default handler;