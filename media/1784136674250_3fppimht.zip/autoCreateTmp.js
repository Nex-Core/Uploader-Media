import fs from 'fs';
import path from 'path';
import chalk from 'chalk';

const currentDir = process.cwd();
const tmpDir = path.join(currentDir, 'tmp');
const clanFilePath = path.join(currentDir, 'clan.json'); // File clan.json berada di luar folder tmp
const spyDataFilePath = path.join(currentDir, 'spy_data.json'); // File spy_data.json juga di luar folder tmp

// Periksa apakah folder 'tmp' ada
if (!fs.existsSync(tmpDir)) {
    fs.mkdirSync(tmpDir, { recursive: true });
    console.log(chalk.green.bold('Folder TMP telah dibuat.'));
} else {
    console.log(chalk.yellow.bold('Folder TMP sudah ada.'));
}

// Periksa apakah file 'clan.json' ada, dan buat jika belum ada
if (!fs.existsSync(clanFilePath)) {
    const initialClanData = {
        "clans": {},
        "members": {}
    };

    fs.writeFileSync(clanFilePath, JSON.stringify(initialClanData, null, 2));
    console.log(chalk.green.bold('File clan.json telah dibuat dengan isi yang diinginkan.'));
} else {
    console.log(chalk.yellow.bold('File clan.json sudah ada.'));
}

// Periksa apakah file 'spy_data.json' ada, dan buat jika belum ada
if (!fs.existsSync(spyDataFilePath)) {
    const initialSpyData = {}; // Isi dengan objek kosong {}

    fs.writeFileSync(spyDataFilePath, JSON.stringify(initialSpyData, null, 2));
    console.log(chalk.green.bold('File spy_data.json telah dibuat dengan isi yang diinginkan.'));
} else {
    console.log(chalk.yellow.bold('File spy_data.json sudah ada.'));
}