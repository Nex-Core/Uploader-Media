import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'
import moment from 'moment-timezone'
import { group } from 'console'
import PhoneNumber from 'awesome-phonenumber'

/*============= WAKTU =============*/
let wibh = moment.tz('Asia/Jakarta').format('HH')
let wibm = moment.tz('Asia/Jakarta').format('mm')
let wibs = moment.tz('Asia/Jakarta').format('ss')
let wktuwib = `${wibh} H ${wibm} M ${wibs} S`

let d = new Date(new Date + 3600000)
let locale = 'id'
let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
let week = d.toLocaleDateString(locale, { weekday: 'long' })
let date = d.toLocaleDateString(locale, {
  day: 'numeric',
  month: 'long',
  year: 'numeric'
})
const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

global.owner = [
  ['6283854025278', 'Fearless', true],
  ['6283854025278', 'Fearless', true],
  ['6283854025278', 'Fearless', true],
]
global.mods = ['']
global.owner2 = ['']
global.prems = []
global.nomorbot = '6283854025278'
global.nomorown = '6283854025278'
global.pushowner = 'wa.me/6283854025278'
global.nameown1 = 'Fearless'
global.readMore = readMore
global.author = 'Fearless'
global.namebot = 'Nishi chisato'
global.wm = '© Nishi chisato'
global.watermark = wm
global.botdate = `Date: ${week} ${date}\nTime: ${wktuwib}`
global.bottime = `Time: ${wktuwib}`
global.titlebot = `Nishi chi`
global.stickpack = '｡･:*:･ﾟ★,｡･:*:･ﾟ☆ Nishi chi ☆ﾟ･:*:･｡,★ﾟ･:*:･｡\n\n'
global.stickauth = (m) => `\n\n\n\n୨୧ ${m.pushName} ୨୧`
global.week = `${week} ${date}`
global.wibb = `${wktuwib}`
global.pairing = 'NISHIIII'
global.thumb = 'https://files.catbox.moe/8zxawz.jpg'
global.thumb2 = 'https://files.catbox.moe/847iok.jpg'
global.registrasi = 'https://telegra.ph/file/2076e17c0b379228839ec.jpg'
global.leave = 'https://i.postimg.cc/yxvn10Ls/ssstik-io-1689170610318.jpg'
global.floc = {
    "key": {
        "participant": '0@s.whatsapp.net',
        "remoteJid": "status@broadcast",
        "fromMe": false,
        "id": "Halo",
    },
    "message": {
        "locationMessage": {
            "degreesLatitude": 37.7749,
            "degreesLongitude": -122.4194,
            "name": 'Nishikigi Chisato',
            "jpegThumbnail": ''
        }
    }
}
global.myweb = 'https://whatsapp.com/channel/0029Vaycl600AgW75pWI6M2C'
global.sig = 'https://www.instagram.com/arul_hx'
global.sgc = 'https://chat.whatsapp.com/Jp4y5xZEAP1JB5xXfeuDV4'
global.tt = 'arull_hx'

/*============== CREATE PANEL ==============*/
global.domain = 'https://nishi.chisato.alfaiz.xyz'
global.apikey = 'ptla_uvDJTfwgVRJBCVnEKoWycpISRFxBSr6nNedPbM90Nbz'
global.c_apikey = 'ptlc_wDm2vDAZc5GzJEG0ny1fNZDkH2eqvuZ1Mi6aMx3Di7z'
global.eggs = '15'
global.locs = '1'

global.lann = 'Btz-Pkisb'
global.lol = '6ee72fcd49621147c1956ae4'
global.termai = 'Fearless'
global.skizoweb = 'https://skizoasia.xyz'
global.termaiweb = 'https://aihub.xtermai.xyz'

global.APIKeys = {
  'https://skizo.tech': 'konekocyz',
  'https://api.betabotz.org': 'p8ADYJib', 
  'https://api.xyroinee.xyz': '3WIq7q3CWt'
}

global.eror = "_error coba lagi tahun depan:D_"
global.stiker_wait = '*⫹⫺ Sticker sedang dibuat...*'
global.chi = '*⫹⫺ Tunggu sebentar sedang memuat...*'
global.wait = '_Processing, Please Wait...._'
global.eror = '_error coba lagi tahun depan:D_'
global.mengetik = 50;
global.lopr = '(Ⓟ)' //LOGO PREMIUM ON MENU.JS
global.lolm = '' //LOGO LIMIT/FREE ON MENU.JS
global.multiplier = 69

/*============== VERSION ==============*/
global.version = '9'
global.hwaifu = ['https://pomf2.lain.la/f/rzylrrbh.jpg']

global.flaaa = [
  'https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=water-logo&script=water-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextColor=%23000&shadowGlowColor=%23000&backgroundColor=%23000&text=',
  'https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=crafts-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&text=',
  'https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=amped-logo&doScale=true&scaleWidth=800&scaleHeight=500&text=',
  'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text=',
  'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&fillColor1Color=%23f2aa4c&fillColor2Color=%23f2aa4c&fillColor3Color=%23f2aa4c&fillColor4Color=%23f2aa4c&fillColor5Color=%23f2aa4c&fillColor6Color=%23f2aa4c&fillColor7Color=%23f2aa4c&fillColor8Color=%23f2aa4c&fillColor9Color=%23f2aa4c&fillColor10Color=%23f2aa4c&fillOutlineColor=%23f2aa4c&fillOutline2Color=%23f2aa4c&backgroundColor=%23101820&text=']

global.rpg = {
  emoticon(string) {
    string = string.toLowerCase()
    let emot = {
      agility: '🤸‍♂️',
      arc: '🏹',
      damage: '💥',
      armor: '🥼',
      bank: '🏦',
      bibitanggur: '🍇',
      bibitapel: '🍎',
      bibitjeruk: '🍊',
      bibitmangga: '🥭',
      bibitpisang: '🍌',
      bow: '🏹',
      bull: '🐃',
      cat: '🐈',
      chicken: '🐓',
      common: '📦',
      cow: '🐄',
      crystal: '🔮',
      darkcrystal: '♠️',
      diamond: '💎',
      dog: '🐕',
      dragon: '🐉',
      elephant: '🐘',
      emerald: '💚',
      exp: '✉️',
      fishingrod: '🎣',
      fox: '🦊',
      gems: '🍀',
      giraffe: '🦒',
      gold: '👑',
      health: '❤️',
      horse: '🐎',
      intelligence: '🧠',
      iron: '⛓️',
      keygold: '🔑',
      keyiron: '🗝️',
      knife: '🔪',
      legendary: '🗃️',
      level: '🧬',
      limit: '🌌',
      lion: '🦁',
      magicwand: '⚕️',
      mana: '🪄',
      eris: '💵',
      mythic: '🗳️',
      pet: '🎁',
      petFood: '🍖',
      pickaxe: '⛏️',
      pointxp: '📧',
      potion: '🥤',
      rock: '🪨',
      snake: '🐍',
      stamina: '⚡',
      strength: '🦹‍♀️',
      string: '🕸️',
      superior: '💼',
      sword: '⚔️',
      tiger: '🐅',
      trash: '🗑',
      uncommon: '🎁',
      upgrader: '🧰',
      wood: '🪵'
    }
    let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
    if (!results.length) return ''
    else return emot[results[0][0]]
  }
}

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})