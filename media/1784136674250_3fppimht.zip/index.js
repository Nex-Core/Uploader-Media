import { createRequire } from "module";
import { fileURLToPath, URL } from "url";
import { join, dirname } from "path";
import { fork } from "child_process";
import { createInterface } from "readline";
import { watchFile, unwatchFile } from "fs";
import http from "http";
import yargs from "yargs";
import chalk from "chalk";

const __dirname = dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);

const { name, author } = require(join(__dirname, "./package.json"));

const nishiChisatoAscii = `
⡏⠉⠉⠉⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠙⠉⠉⠉⠹
⡇⢸⣿⡟⠛⢿⣷ ⢸⣿⡟⠛⢿⣷⡄⢸⣿⡇ ⢸⣿⡇⢸⣿⡇ ⢸⣿⡇ 
⡇⢸⣿⣧⣤⣾⠿ ⢸⣿⣇⣀⣸⡿⠃⢸⣿⡇ ⢸⣿⡇⢸⣿⣇⣀⣸⣿⡇ 
⡇⢸⣿⡏⠉⢹⣿⡆⢸⣿⡟⠛⢻⣷⡄⢸⣿⡇ ⢸⣿⡇⢸⣿⡏⠉⢹⣿⡇ 
⡇⢸⣿⣧⣤⣼⡿⠃⢸⣿⡇ ⢸⣿⡇⠸⣿⣧⣤⣼⡿⠁⢸⣿⡇ ⢸⣿⡇ 
⣇⣀⣀⣀⣀⣀⣀⣄⣀⣀⣀⣀⣀⣀⣀⣠⣀⡈⠉⣁⣀⣄⣀⣀⣀⣠⣀⣀⣀⣰
⣇⣿⠘⣿⣿⣿⡿⡿⣟⣟⢟⢟⢝⠵⡝⣿⡿⢂⣼⣿⣷⣌⠩⡫⡻⣝⠹⢿⣿⣷
⡆⣿⣆⠱⣝⡵⣝⢅⠙⣿⢕⢕⢕⢕⢝⣥⢒⠅⣿⣿⣿⡿⣳⣌⠪⡪⣡⢑⢝⣇
⡆⣿⣿⣦⠹⣳⣳⣕⢅⠈⢗⢕⢕⢕⢕⢕⢈⢆⠟⠋⠉⠁⠉⠉⠁⠈⠼⢐⢕⢽
⡗⢰⣶⣶⣦⣝⢝⢕⢕⠅⡆⢕⢕⢕⢕⢕⣴⠏⣠⡶⠛⡉⡉⡛⢶⣦⡀⠐⣕⢕
⡝⡄⢻⢟⣿⣿⣷⣕⣕⣅⣿⣔⣕⣵⣵⣿⣿⢠⣿⢠⣮⡈⣌⠨⠅⠹⣷⡀⢱⢕
⡝⡵⠟⠈⢀⣀⣀⡀⠉⢿⣿⣿⣿⣿⣿⣿⣿⣼⣿⢈⡋⠴⢿⡟⣡⡇⣿⡇⡀⢕
⡝⠁⣠⣾⠟⡉⡉⡉⠻⣦⣻⣿⣿⣿⣿⣿⣿⣿⣿⣧⠸⣿⣦⣥⣿⡇⡿⣰⢗⢄
⠁⢰⣿⡏⣴⣌⠈⣌⠡⠈⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣬⣉⣉⣁⣄⢖⢕⢕⢕
⡀⢻⣿⡇⢙⠁⠴⢿⡟⣡⡆⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣵⣵⣿
⡻⣄⣻⣿⣌⠘⢿⣷⣥⣿⠇⣿⣿⣿⣿⣿⣿⠛⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣷⢄⠻⣿⣟⠿⠦⠍⠉⣡⣾⣿⣿⣿⣿⣿⣿⢸⣿⣦⠙⣿⣿⣿⣿⣿⣿⣿⣿⠟
⡕⡑⣑⣈⣻⢗⢟⢞⢝⣻⣿⣿⣿⣿⣿⣿⣿⠸⣿⠿⠃⣿⣿⣿⣿⣿⣿⡿⠁⣠
⡝⡵⡈⢟⢕⢕⢕⢕⣵⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣶⣿⣿⣿⣿⣿⠿⠋⣀⣈⠙
⡝⡵⡕⡀⠑⠳⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠛⢉⡠⡲⡫⡪⡪⡣
`;

console.log(chalk.blueBright(nishiChisatoAscii));
console.log(chalk.cyan("Nishi chisato || Fearless."));

let isRunning = false;
let childProcess = null;

const readlineInterface = createInterface({
  input: process.stdin,
  output: process.stdout
});

function promptPassword() {
  readlineInterface.question(chalk.yellow("[ ! ]  Masukan Password: "), (password) => {
    if (password === "Fearless") {
      console.log(chalk.green("[ √ ]  Password Benar"));
      start("main.js");
    } else {
      console.log(chalk.red("[ x ]  Password Salah"));
      readlineInterface.close();
      process.exit(1);
    }
  });
}

function start(scriptPath) {
  if (isRunning) return;

  isRunning = true;
  const args = [join(__dirname, scriptPath), ...process.argv.slice(2)];

  const { say } = require("cfonts");
  say([process.argv[0], ...args].join(" "), {
    font: "console",
    align: "center",
    gradient: ["red", "magenta"]
  });

  childProcess = fork(args[0], args.slice(1));
  childProcess.on("message", handleMessage);
  childProcess.on("exit", (code) => handleExit(args, code));

  const parsedArgs = yargs(process.argv.slice(2)).exitProcess(false).parse();
  if (!parsedArgs.test) {
    readlineInterface.on("line", (line) => childProcess.send(line.trim()));
  }
}

function handleMessage(message) {
  console.log(chalk.green("[Success]"), chalk.magenta(message));
  switch (message) {
    case "reset":
      restart();
      break;
    case "uptime":
      childProcess.send(process.uptime());
      break;
  }
}

function handleExit(args, code) {
  isRunning = false;
  console.error(chalk.red("Child Process Exited with Code:"), chalk.red(code));

  if (code !== 0) {
    restart();
  } else {
    watchFile(args[0], () => {
      unwatchFile(args[0]);
      restart();
    });
  }
}

function restart() {
  if (childProcess) {
    childProcess.kill();
    childProcess = null;
  }
  console.log(chalk.cyan("[Info] Restarting process..."));
  start("main.js");
}

http.createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "text/plain" });
  res.end("Hello World!\n");
}).listen(3000, () => {
  console.log("\nFearless Development...");
});

promptPassword();